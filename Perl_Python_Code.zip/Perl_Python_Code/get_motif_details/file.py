##############################################################################################
## Laboratory of Functional Analysis in silico                                              ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo               ##
## Programmed by Yosvany Lopez Alvarez                                       February, 2014 ##
##############################################################################################

import pickle

class file:

    ## this function filters the whitespaces of a list 
    
    def remove_whitespaces (self, list):
        
        return (list != '')

    ## reading the JASPAR file and returning a motif dictionary

    def JASPAR_file_reader (self, file_name):

        input = open(file_name)

        motif_list = dict()
        motif_id = ''

        for line in input:

            line = line.strip()

            if (line.startswith(">")):
                motif_id = line.split(" ")[0]
                motif_id = motif_id[1:len(motif_id)]
                motif_list[motif_id] = []
            else:
                motif_list[motif_id].append(line.split("\t"))

        input.close()

        indices = motif_list.keys()
        
        for index in indices:
            motif_list[index] = zip(*motif_list[index])
            for i in range(0, len(motif_list[index])):
                motif_list[index][i] = map(int, list(motif_list[index][i]))
                
        return (motif_list)

    ## reading the TRANSFAC file and returning a motif dictionary
    
    def TRANSFAC_file_reader (self, file_name):
        
        input = open(file_name)

        motif_list = dict()
        motif_id  = ''
        organism = ''
        flag = 0

        for line in input:
            line = line.strip()
            if ((flag == 1) and line.startswith("XX")):
                flag = 0
                if not(organism == "OS  Insecta"):
                    del motif_list[motif_id]
            elif (line.startswith("AC")):
                motif_id = line.split(" ")[2]
            elif (line.startswith("OS")):
                organism = line
            elif (line.startswith("P0")):
                flag = 1
                motif_list[motif_id] = []
            elif (flag == 1):
                items = filter(self.remove_whitespaces, line.split(" "))
                items.pop()
                items.pop(0)
 
                if (organism == "OS  Insecta"):
                    motif_list[motif_id].append(map(int, items))
        
        input.close()

        return (motif_list)

        
    def Weeder_motif_reader (self, file_name):

        input = open(file_name)

        motif_info_list = []
        motif_list = []
        matched_genes = []
        sites = []

        gene_dictionary = dict ()
        
        gene_flag = 0
        site_flag = 0

        for line in input:

            line = line.strip()
            
            if (line.startswith("**** MY ADVICE ****")):
                gene_flag = 0
            elif (line.startswith("Your sequences:")):
                gene_flag = 1
            elif (line.startswith("Sequence") & (gene_flag == 1)) :
                items = line.split()
                last_item = items[3]
                subitems = last_item.split("|")
                gene_dictionary[items[1]] = subitems[1]

            elif (line.startswith("Best occurrences:")):
                site_flag = 1
                matched_genes = []
                sites = []
            elif ((line == "") & (site_flag == 1)):
                if (len(sites) > 0):
                    motif_list.append(sites)
                    motif_info_list.append(matched_genes)
                sites = []
                matched_genes = []
                site_flag = 0
            elif ((site_flag == 1) & ("Seq" not in line)):

                items = line.split()
                
                if ("[" not in items[2]):
                    bs_info = gene_dictionary[items[0]] + " " + items[1] + " " + items[3]
                    sequence = items[2]
                    sites.append(sequence)
                    matched_genes.append(bs_info)

        return (motif_info_list, motif_list)

    def MEME_motif_reader (self, file_name):

        input = open(file_name)
        
        motif_info_list = []
        motif_list = []

        matched_genes = []
        sites = []
        motif_index = 1
        stopper = 0

        for line in input:

            line = line.strip()
            checker = line.split('|')
            
            if ("sites sorted by position p-value" in line):
                matched_genes = []
                sites = []
                stopper = 1
                
            elif (line.startswith('I') or line.startswith('V') or line.startswith('X') or line.startswith('m')):  
                if (stopper == 1):
                    items = line.split( )
                    first_item = items[0]
                    subitems = first_item.split('|')
                    bs_info = subitems[1] + " " + items[1] + " " + items[2]

                    if ((items[1] == "+") or (items[1] == "-")):
                        sequence = items[5]
                    else:
                        sequence = items[4]
                
                    matched_genes.append(bs_info)
                    sites.append(sequence)

            elif (("Motif" in line) & (stopper == 1)): 
                motif_info_list.append(matched_genes)
                motif_list.append(sites) 
                stopper = 0
                motif_index += 1

        return (motif_info_list, motif_list)
  
    def BP_motif_reader (self, file_name):

        input = open(file_name)

        motif_info_list = []
        motif_list = []

        matched_genes = []
        sites = []
        
        for line in input:
            if (line.startswith("Motif")):
                if (len(sites) > 0):
                    motif_info_list.append(matched_genes)
                    motif_list.append(sites)
                    matched_genes = []
                    sites = []                    
            elif (line.startswith(">")):
                
                items = line.split()
                
                orientation = " "
                if (items[5] == "r"):
                    orientation = "-"
                else:
                    orientation = "+"

                first_item = items[0]
                subitems = first_item.split("|")

                line = input.next()
                site = line.strip()

                bs_info = subitems[1] + " " + orientation + " " + items[6]
                sequence = site

                matched_genes.append(bs_info)
                sites.append(sequence)

        motif_info_list.append(matched_genes)
        motif_list.append(sites)

        return (motif_info_list, motif_list)

    def SOMBRERO_motif_reader (self, file_name):

        input = open(file_name)

        gene_dictionary = dict()
        
        motif_info_list = []
        motif_list = []

        matched_genes = []
        sites = []  

        gene_flag = 0
        site_flag = 0

        for line in input:

            line = line.strip()

            if (line.startswith("*EndSequences")):
                gene_flag = 0
            elif (line.startswith("*Sequences")):
                gene_flag = 1
            elif (gene_flag == 1):
                items = line.split("\t") 
                first_item = items[2]
                subitems = first_item.split("|")
                gene_dictionary[items[0]] = subitems[1]   
            elif (line.startswith("*ListStart")):
                site_flag = 1
                matched_genes = []
                sites = []
            elif (line.startswith("*ListEnd")):
                if (len(sites) > 0):
                    motif_info_list.append(matched_genes)
                    motif_list.append(sites)
                    matched_genes = []
                    sites = []
                    site_flag = 0
            elif (site_flag == 1):
                items = line.split("\t")
               
                bs_info = gene_dictionary[items[2]] + " " + items[5] + " " + items[3]
                sequence = items[0]
                
                matched_genes.append(bs_info)
                sites.append(sequence)

        return (motif_info_list, motif_list)

    def MS_motif_reader (self, file_name):

        input = open(file_name)

        motif_info_list = []
        motif_list = []

        matched_genes = []
        sites = []

        for line in input:
            if (line.startswith("#id:")):
                if (len(sites) > 0):
                    motif_info_list.append(matched_genes)
                    motif_list.append(sites)
                    matched_genes = []
                    sites = []
            elif (not line.startswith("#INC")):
                items = line.split()
                
                first_item = items[0]
                subitems = first_item.split("|")
                
                last_item = items[11]
                site = last_item[1:len(last_item) - 2]
                
                bs_info = subitems[1] + " " + items[6] + " " + items[3]

                matched_genes.append(bs_info)
                sites.append(site)
                
        motif_info_list.append(matched_genes)
        motif_list.append(sites)

        return (motif_info_list, motif_list)

    ## mtfDiscoveryIndex = 0 - BioProspector 
    ## mtfDiscoveryIndex = 1 - Motif Sampler
    ## mtfDiscoveryIndex = 2 - MEME
    ## mtfDiscoveryIndex = 3 - Weeder
 
    def directory_reader (self, root_directory, directories):

        motif_info_dictionary = dict ()
        motif_dictionary = dict ()

        motif_index = 1
        
        for i in range(0, len(directories)):

            for j in range(0, len(directories[i])):
                
                motif_info = []
                motifs = []

                motif_file = root_directory + directories[i][j]

                if (i == 0):
                    (motif_info, motifs) = self.BP_motif_reader(motif_file)
                elif (i == 1) :                                                
                    (motif_info, motifs) = self.MS_motif_reader(motif_file)
                elif (i == 2):
                    (motif_info, motifs) = self.MEME_motif_reader(motif_file)
                elif (i == 3):                                                                                                                                                                                                (motif_info, motifs) = self.Weeder_motif_reader(motif_file)
                
                for k in range(0, len(motifs)):
                    motif_info_dictionary[motif_index] = motif_info[k]
                    motif_dictionary[motif_index] = motifs[k]
                
                    motif_index += 1             

        return (motif_info_dictionary, motif_dictionary)
        

    ## This function receives two parameters: (1) a dictionary whose "keys" and "values" are motifs'
    ## identifiers and frequency matrices, and (2) an external file name. As a result, each frequency 
    ## matrix is saved into the respective file.

    def save (self, frequencyMatrices, fileName):

        fileHandler = open(fileName, 'wb')
        pickle.dump(frequencyMatrices, fileHandler)
