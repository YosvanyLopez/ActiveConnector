#################################################################################################
## Laboratory of Functional Analysis in silico                                                 ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo                  ##
## Programmed by Yosvany Lopez Alvarez                                          February, 2014 ##
#################################################################################################

#!/usr/local/bin/python

from file import *
from frequency_matrices import *

#################################################################################################

## BioProspector -> MotifSampler -> MEME -> Weeder

root_directory = "./dmel_development/stage_01/motif_prediction"  ## the stage number is changed manually

predicted_motif_directory = [ ["/bioprospector_one_strand/binding_sites_6.txt",
                               "/bioprospector_one_strand/binding_sites_7.txt",
                               "/bioprospector_one_strand/binding_sites_8.txt",
                               "/bioprospector_one_strand/binding_sites_9.txt",
                               "/bioprospector_one_strand/binding_sites_10.txt",
                               "/bioprospector_one_strand/binding_sites_11.txt",
                               "/bioprospector_one_strand/binding_sites_12.txt",

                               "/bioprospector_both_strands/binding_sites_6.txt",
                               "/bioprospector_both_strands/binding_sites_7.txt",
                               "/bioprospector_both_strands/binding_sites_8.txt",
                               "/bioprospector_both_strands/binding_sites_9.txt",
                               "/bioprospector_both_strands/binding_sites_10.txt",
                               "/bioprospector_both_strands/binding_sites_11.txt",
                               "/bioprospector_both_strands/binding_sites_12.txt"],

                              ["/msampler_one_strand/binding_sites_6.txt",
                               "/msampler_one_strand/binding_sites_7.txt",
                               "/msampler_one_strand/binding_sites_8.txt",
                               "/msampler_one_strand/binding_sites_9.txt",
                               "/msampler_one_strand/binding_sites_10.txt",
                               "/msampler_one_strand/binding_sites_11.txt",
                               "/msampler_one_strand/binding_sites_12.txt",

                               "/msampler_both_strands/binding_sites_6.txt",
                               "/msampler_both_strands/binding_sites_7.txt",
                               "/msampler_both_strands/binding_sites_8.txt",
                               "/msampler_both_strands/binding_sites_9.txt",
                               "/msampler_both_strands/binding_sites_10.txt",
                               "/msampler_both_strands/binding_sites_11.txt",
                               "/msampler_both_strands/binding_sites_12.txt"],

                              ["/meme_one_strand/meme.txt",
                               "/meme_both_strands/meme.txt"],

                              ["/weeder_one_strand/motif_prediction_promoters.wee",
                               "/weeder_both_strands/motif_prediction_promoters.wee"]
]

JASPAR_file = "./JASPAR/JASPAR_pfm_insects.txt"

TRANSFAC_file = "./TRANSFAC/TRANSFAC_matrix.dat"

fmatrix_file = "./dmel_development/stage_01/motif_prediction/pfmatrices.info" ## the stage number is changed manually

#################################################################################################

file_object = file ()

(genes_per_motif, sites_per_motif) = file_object.directory_reader(root_directory, predicted_motif_directory)

fmatrix_object = frequency_matrices()
fmatrix_object.insertFrequencyMatrices(sites_per_motif)

frequency_matrices = fmatrix_object.getFrequencyMatrices()

JASPAR_motif_list = file_object.JASPAR_file_reader(JASPAR_file)

TRANSFAC_motif_list = file_object.TRANSFAC_file_reader(TRANSFAC_file) 

known_motif_list = dict(JASPAR_motif_list.items() + TRANSFAC_motif_list.items())

all_pfmatrices = dict(known_motif_list.items() + frequency_matrices.items())

file_object.save(all_pfmatrices, fmatrix_file)

#################################################################################################
