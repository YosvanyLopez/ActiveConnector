#########################################################################################
## Laboratory of Functional Analysis in silico                                         ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo          ##
## Programmed by Yosvany Lopez Alvarez                                  February, 2014 ##
#########################################################################################

class frequency_matrices:

    def __init__(self):
        
        self.FREQUENCY_MATRICES = dict ()
        self.MOTIF_INFO = dict()

    def setFrequencyMatrix (self, binding_sites):

        frequencyMatrix = []

        for index in range(len(binding_sites[0])):

            chrList = []
            for bs in binding_sites:
                chrList.append(bs[index])

            ntList = []
            ntList.append(chrList.count('A'))
            ntList.append(chrList.count('C'))
            ntList.append(chrList.count('G'))
            ntList.append(chrList.count('T'))

            frequencyMatrix.append(ntList)

        return (frequencyMatrix)
        
    def insertFrequencyMatrices (self, sequenceDictionary):

        motifIndices = sequenceDictionary.keys()

        for index in motifIndices:

            if (len(sequenceDictionary[index]) != 0):
                motif_id = 'DM_' + str(index)
                self.FREQUENCY_MATRICES[motif_id] = self.setFrequencyMatrix(sequenceDictionary[index])
            
    def getFrequencyMatrices (self):

        return (self.FREQUENCY_MATRICES)
