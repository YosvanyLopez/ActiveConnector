#################################################################################################
## This package called "Utils" contains several additional functions, which help us to avoid   ##
## the complexity of the code lines.                                                           ##
##                                                                                             ##
## Laboratory of Functional Analysis in silico                                                 ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo                  ##
## Programmed by Yosvany Lopez Alvarez                                          November, 2011 ##
#################################################################################################

package Utils;

use warnings;
use strict;


## This function receives two parameters: (1) a numerical value, and (2) an integer list. Afterwards, 
## by using the previous parameter each item within the list is fixed and returned inside another list. 

sub FixValues {

    my ($Fixer, @List) = @_;

    my @FixedValues = ();

    foreach my $Item (@List) {

	my $remainder = $Item % $Fixer;
	my $result = $Item / $Fixer;
	my $NewValue = ($result * 125) + $remainder;

	push (@FixedValues, $NewValue);
    }

    return (@FixedValues)
}


## This function receives a tab-separated string. Thereafter, such a string is split into different 
## substrings, which are returned within a list. 

sub SplitString {

    my ($String) = @_;

    my @List = split('\t', $String);
    
    return (@List);
}


## This function receives a tab-separated string. After getting a list composed of its individual 
## substrings, those items at positions '0', '1' & '3' are returned.

sub GetValues {

    my ($String) = @_;

    my @Values = SplitString($String);

    my $ItemPos0 = $Values[0];
    my $ItemPos1 = $Values[1];
    my $ItemPos2 = $Values[2];
    my $ItemPos3 = $Values[3];
    my $ItemPos4 = $Values[4];
    my $ItemPos5 = $Values[5];
    
    return ($ItemPos0, $ItemPos1, $ItemPos2, $ItemPos3, $ItemPos4, $ItemPos5)
}

## This function .....

sub GetBSCount {

    my ($PromoterNumber, %MotifDistribution) = @_;

    my @Indices = sort(keys(%MotifDistribution));

    my %BSPercentage = ();
	
    foreach my $Index (@Indices) {

	my $Percentage = ($MotifDistribution{$Index} / $PromoterNumber) * 100;
	
	$BSPercentage{$Index} = sprintf("%.2f", $Percentage);	
    }

    return (%BSPercentage)
}


## This function ....

sub GetBestIntervals {

    my ($DesiredValue, $ref_PatternHash, %Percentage) = @_;

    my %PatternHash = %{$ref_PatternHash};

    my @Indices = keys(%Percentage);

    my %FilteredIntervals = ();

    my $Count = 0;

    foreach my $Index (@Indices) {

	if ($Percentage{$Index} >= $DesiredValue) {

            $FilteredIntervals{$Count} = $PatternHash{$Index};
	    
	    $Count++
        }   
    }

    return (%FilteredIntervals)
}


## This function ....

sub trim {

	my ($string) = @_;

	$string =~ s/^\s+//;
	$string =~ s/\s+$//;
	
	return $string;
}


## This function ....

sub SortedBSites {

    my ($ref_BSites, %Positions) = @_;

    my %BSites = %{$ref_BSites};

    my @SortedBSites = ();
   
    foreach my $key (sort {$Positions{$a} <=> $Positions{$b}} keys %Positions) {
	push(@SortedBSites, $BSites{$key}) 
    }

    return (@SortedBSites)
}

## This function ....

sub CountChar {

    my ($char, $string) = @_;

    my $counter = 0;
    
    my $offset = 0;
    my $result = index($string, $char, $offset);

    while ($result != -1) {

	$counter++;

	$offset = $result + 1;
	$result = index($string, $char, $offset);
    }

    return ($counter)
}


## This function ….

sub changeReverseFeature {

    my ($string) = @_;

    my $strandCounter = CountChar("+", $string) + CountChar("-", $string);

    my $reverseString = $string;

    if ($strandCounter == 2) {
        my @List = split(":", $string);
	if (scalar(@List) == 6) {
	    $reverseString = $List[2] . ":" . $List[3] . ":" . $List[0] . ":" . $List[1] . ":" . $List[4] . ":" . $List[5];
	}
    }

    return ($reverseString)
}

1;
