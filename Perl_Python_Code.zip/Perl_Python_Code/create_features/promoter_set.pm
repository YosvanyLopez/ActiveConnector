################################################################################################
## This package contains the class "PromoterSet", which groups those methods focused          ##
## on handling a collection of promoters. In addition, several functions from the package     ##
## "Promoter" are called to create different instances and insert them into the promoter      ##
## collection.                                                                                ##
##                                                                                            ##
## Laboratory of Functional Analysis in silico                                                ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo                 ##
## Programmed by Yosvany Lopez Alvarez                                          October, 2012 ##
################################################################################################

package promoter_set;

use warnings;
use strict;
use promoter;
use List::Util qw(min max);

## This function represents the class' constructor.

sub new {

    my ($self) = {};

    $self -> {PROMOTERS} = undef;

    bless($self);

    return ($self)
}


## This function receives two parameters: (1) a gene name, and (2) an instance from the class "Promoter". 
## Soon after, such an object is inserted into the promoter collection represented by the attribute
## "PROMOTERS".

sub SetPromoterObject {

    my ($self, $GeneName, $PromoterObject) = @_;

    ${$self -> {PROMOTERS}}{$GeneName} = $PromoterObject;
}


## This function returns the promoter collection stored in the attribute "PROMOTERS".

sub GetPromoters {

    my ($self) = @_;
    
    return (%{$self -> {PROMOTERS}})
}


## This function ....

sub GetPromoterCount {
    
    my ($self) = @_;

    return (scalar(keys(%{$self -> {PROMOTERS}})))    
}


## This function receives a hash whose "keys" and "values" are each promoter's identifier as well as 
## a list of the TFBSs found within it. Consequently, objects "Promoter" are created and correctly 
## inserted into the promoter collection.

sub update_promoter_collection {

    my ($self, $type, $upstream, $downstream, %promoter_elements) = @_;

    # Type means "1" or "2"

    my %updated_promoters = ();  

    my @gene_names = keys(%promoter_elements);

    foreach my $gene_name (@gene_names) {

	my $promoter_object = new promoter();

	$promoter_object -> UpdateInfo($type, $upstream, $downstream, $promoter_elements{$gene_name});
	
	$updated_promoters{$gene_name} = $promoter_object
    }

    return (%updated_promoters)
}

## This function ....

sub GenerateWindowSizes {

    my ($self, $WindowSize, $PromoterLength) = @_;

    my @WindowInfo = ();

    my $MIN = 0;
    while ($MIN < $PromoterLength) {

        my $MAX = 0;

        if ($MIN == 0) { $MAX = $MIN + $WindowSize }
        else { $MAX = $MIN + $WindowSize - 1 }

        my $Size = $MIN . ":" . $MAX;
	push(@WindowInfo, $Size);

        $MIN = $MAX + 1
    }

    return (@WindowInfo)
}

## This function ....

sub CreateDifferentWindows {

    my ($self, $PromoterLength, @WindowSizes) = @_;

    my @AllWindows = ();

    foreach my $Window (@WindowSizes) {
	
	my @WSizes = $self -> GenerateWindowSizes($Window, $PromoterLength);

	@AllWindows = (@AllWindows, @WSizes)
    }

    return (@AllWindows)
}

## This function .....

sub RulesPerPromoter {

    my ($self, $ref_MotifNames, $ref_WindowSizes, %Promoters) = @_;

    my @WindowSizes = @{$ref_WindowSizes};

    my @GeneNames = keys(%Promoters);

    my %RulesPerPromoter = ();
    my %positioning_rules = ();
    

    foreach my $GeneName (@GeneNames) {

	my ($ref_RuleInfo, %RuleHints) = $Promoters{$GeneName} -> GeneratePresenceRules($ref_MotifNames, @WindowSizes);
	
	$RulesPerPromoter{$GeneName} = \%RuleHints;
	
	@positioning_rules {keys %RuleHints} = values %RuleHints;

    }

    return (\%RulesPerPromoter, keys(%positioning_rules))
}


## This function .....

sub HintsPerOneRule {

    my ($self, $RuleInfo, %RulesPerPromoter) = @_;
    
    my @GeneNames = keys(%RulesPerPromoter);
    
    my $RuleCounter = 0;

    foreach my $GeneName (@GeneNames) {
	
	my %RuleOnePromoter = %{$RulesPerPromoter{$GeneName}};
       
	if ($RuleOnePromoter{$RuleInfo} >= 1) { $RuleCounter++ }
    }

    return ($RuleCounter)
}


## This function ....

sub PercentagePromoterPerRule {

    my ($self, %RulesPerPromoter) = @_;

    my @GeneNames = keys(%RulesPerPromoter);
    my $PromoterAmount = scalar(@GeneNames);
    my @Rules = keys(%{$RulesPerPromoter{$GeneNames[0]}});
        
    my %Percentages = ();

    foreach my $Rule (@Rules) {

	my $PromoterWithRule = $self -> HintsPerOneRule($Rule, %RulesPerPromoter);
	
	$Percentages{$Rule} = sprintf "%2f", ($PromoterWithRule / $PromoterAmount)
    }

    return (%Percentages)
} 

## This function ....

sub GetInsignificantRules {

    my ($self, $Threshold, %Percentages) = @_;

    my @Rules = keys(%Percentages);
    
    my @RulesToBeRemoved = ();

    foreach my $Rule (@Rules) {
 
	if ($Percentages{$Rule} <= $Threshold) { push(@RulesToBeRemoved, $Rule) }
    }
    
    return (@RulesToBeRemoved)
}

## This function .....

sub RemoveInsignificantRules {

    my ($self, $ref_Rules, %RuleOnePromoter) = @_;

    my @Rules = @{$ref_Rules};
    
    foreach my $Rule (@Rules) { delete $RuleOnePromoter{$Rule} }
    
    return (\%RuleOnePromoter)
}  

## This function ....

sub RemoveRuleAllPromoters {

    my ($self, $ref_Rules, %RulesPerPromoter) = @_;

    my @GeneNames = keys(%RulesPerPromoter);
    
    foreach my $GeneName (@GeneNames) {

	my $ref_NewRules = $self -> RemoveInsignificantRules($ref_Rules, %{$RulesPerPromoter{$GeneName}});
	$RulesPerPromoter{$GeneName} = $ref_NewRules
    }

    return (%RulesPerPromoter)
}

## This function ....

sub distance_between_motifs {

    my ($self, $wsize, $downstream, $promoter_length, %promoters) = @_;

    my @gene_names = keys(%promoters);

    my %features_per_promoters = ();

    my %features = ();

    foreach my $gene_name (@gene_names) {
	
	my @sites = $promoters{$gene_name} -> SortOwnBSites();
	my %feature_subset = $promoters{$gene_name} -> DistanceBetweenMotifRules($downstream, $wsize, $promoter_length, @sites);

	$features_per_promoters{$gene_name} = \%feature_subset;
	
	@features{keys %feature_subset} = values %feature_subset
    }

    my @feature_description = keys(%features);
    my %alternative_features = (); 

    foreach (@feature_description) {

	my @items = split("#", $_);
        my @subitems = split(":", $items[2]);

        my $feature = $items[0] . '#'. $items[1] . '#'. $subitems[0] . ':' . $subitems[1] . ':' . $subitems[2] . ':' . $subitems[3] . ':' . $subitems[4] . ':' . $subitems[5];
        my $alternative_feature = $items[0] . '#'. $items[1] . '#'. $subitems[2] . ':' . $subitems[3] . ':' . $subitems[0] . ':' . $subitems[1] . ':' . $subitems[4] . ':' . $subitems[5];
	
	if ($feature ne $alternative_feature) {
            if (exists $features{$alternative_feature}) { if ((! exists $alternative_features{$feature}) && (! exists $alternative_features{$alternative_feature})) { $alternative_features{$alternative_feature} = 1 } }
	}
    }

    my @redundant_features = keys(%alternative_features);
    foreach (@redundant_features) { delete $features{$_} }     

    return (\%features_per_promoters, keys(%features))
}

## This function ....

sub GetOrderRulePerPromoters {

    my ($self, $downstream, %promoters) = @_;

    my @GeneNames = keys(%promoters);

    my %rules_per_promoter = ();
    my %order_rules = ();

    foreach my $GeneName (@GeneNames) {

	my ($ref_upstreamBS, @downstreamBS) = $promoters{$GeneName} -> splitBS_TSS($downstream);

	my %upstream_rules = $promoters{$GeneName} -> GetUpstreamOrientation('u', @{$ref_upstreamBS});
	my %downstream_rules = $promoters{$GeneName} -> GetUpstreamOrientation('d', reverse(@downstreamBS));

	my %rule_hits = ();
	@rule_hits{keys %upstream_rules} = values %upstream_rules;
	@rule_hits{keys %downstream_rules} = values %downstream_rules;    

	my @rule_keys = keys(%upstream_rules);

	foreach (@rule_keys) {

	    my $downstream_rule = $_;
	    $downstream_rule =~ tr/u/d/;

	    if (exists $downstream_rules{$downstream_rule}) {
		
		my @items = split(":", $_);
		my $last_item = pop @items;
		my $neutral_rule = join(":", @items);
		
		my @hits = ();
		push(@hits, $upstream_rules{$_});
		push(@hits, $downstream_rules{$downstream_rule});

		$rule_hits{$neutral_rule} = min(@hits)	
	    }
	}

	$rules_per_promoter{$GeneName} = \%rule_hits;
	@order_rules {keys %rule_hits} = values %rule_hits
    }

    return (\%rules_per_promoter, keys(%order_rules))
}

## This function ....

sub get_presence_rules {

    my ($self, $downstream, %promoters) = @_;

    my @gene_names = keys(%promoters);

    my %rules_per_promoter = ();
    my %presence_rules = ();

    foreach my $gene_name (@gene_names) {

        my ($ref_upstream_sites, @downstream_sites) = $promoters{$gene_name} -> splitBS_TSS($downstream);

	my %upstream_rules = $promoters{$gene_name} -> presence_rules('u', @{$ref_upstream_sites});
        my %downstream_rules = $promoters{$gene_name} -> presence_rules('d', @downstream_sites);

	my %rule_hits = ();
        @rule_hits{keys %upstream_rules} = values %upstream_rules;
        @rule_hits{keys %downstream_rules} = values %downstream_rules;

	my @rule_keys = keys(%upstream_rules);

	foreach (@rule_keys) {

	    my $downstream_rule = $_;
            $downstream_rule =~ tr/u/d/;

	    if (exists $downstream_rules{$downstream_rule}) {

                my @items = split(":", $_);
                my $last_item = pop @items;
                my $neutral_rule = join(":", @items);

                my @hits = ();
                push(@hits, $upstream_rules{$_});
                push(@hits, $downstream_rules{$downstream_rule});

                $rule_hits{$neutral_rule} = min(@hits)
            }
        }

        $rules_per_promoter{$gene_name} = \%rule_hits;
        @presence_rules{keys %rule_hits} = values %rule_hits
    }

    return (\%rules_per_promoter, keys(%presence_rules))
}

## This function ....                                                                                                                                                                                                                                                         
sub replace_redundant_features {

    my ($self, $ref_own_features, @features) = @_;

    my %own_features = %{$ref_own_features};

    foreach (@features) {

        my @items = split("#", $_);
        my @subitems = split(":", $items[2]);

        my $alternative_feature = $items[0] . '#'. $items[1] . '#'. $subitems[2] . ':' . $subitems[3] . ':' . $subitems[0] . ':' . $subitems[1] . ':' . $subitems[4] . ':' . $subitems[5];

        if ((exists $own_features{$alternative_feature}) && ($_ ne $alternative_feature)) {
            $own_features{$_} = $own_features{$alternative_feature};
            delete $own_features{$alternative_feature}
        }
    }

    return (%own_features)
}

## This function ....

sub replace_positioning_features {

   my ($self, $ref_feature_promoters, @features) = @_;

   my %feature_promoters = %{$ref_feature_promoters};

   my @gene_names = keys(%feature_promoters);

   my %updated_feature_promoters = ();

   foreach (@gene_names) {

       my %features_gene = $self -> replace_redundant_features($feature_promoters{$_}, @features);
       
       $updated_feature_promoters{$_} = \%features_gene; 
   }
   
   return (%updated_feature_promoters)
}

## This function ....

sub feature_hits {

    my ($self, $feature, %features_promoters) = @_;

    my @gene_list = sort(keys(%features_promoters));

    my @hits = ();

    for(my $i = 0; $i <= scalar(@gene_list) - 1; $i++) {
        my %feature_subset = %{$features_promoters{$gene_list[$i]}};
        if (exists $feature_subset{$feature}) { push(@hits, $feature_subset{$feature}) }
        else { push(@hits, 0) }
    }

    return (@hits)
}

## This function ....

sub hits_per_feature {

    my ($self, $output_file, $ref_features, %features_promoters) = @_;

    my @features = sort(keys(%{$ref_features}));
   
    my @gene_list = sort(keys(%features_promoters));

    my $gene_str = join("\t", @gene_list);
    $gene_str = "\t" . $gene_str;

    open(OUTPUT, ">$output_file");

    print(OUTPUT $gene_str);
    print OUTPUT "\n";

    foreach (@features) {

   	my @hits = $self -> feature_hits($_, %features_promoters);

	my $hit_str = $_ . "\t" . join("\t", @hits);
        $hit_str = Utils::trim($hit_str);

	print (OUTPUT $hit_str);
        print OUTPUT "\n"
    }

    close(OUTPUT);
}

## This function ....

sub merge_all_features {

    my ($self, $ref_position, $ref_order, $ref_presence, @pairwise_distance) = @_;

   my @feature_collection = (@{$ref_position}, @{$ref_order}, @{$ref_presence}, @pairwise_distance);

    my %feature_hash = map { $_ => 1 } @feature_collection;

    return (%feature_hash)
}

## This function ...

sub merge_features {

    my ($self, $ref_position, $ref_order, $ref_presence, %pairwise_distance) = @_;

    my %features = ();

    @features{keys %{$ref_position}} = values %{$ref_position};

    @features{keys %{$ref_order}} = values %{$ref_order};

    @features{keys %{$ref_presence}} = values %{$ref_presence};

    @features{keys %pairwise_distance} = values %pairwise_distance;

    return (%features)
}

## This function ...

sub merge_features_promoters {

    my ($self, $ref_position, $ref_order, $ref_presence, %pairwise_distance) = @_;

    my @gene_list = keys(%pairwise_distance);

    my %features_promoters = ();

    foreach (@gene_list) {

	my %feature_subset = $self -> merge_features(${$ref_position}{$_}, ${$ref_order}{$_}, ${$ref_presence}{$_}, %{$pairwise_distance{$_}}); 

        $features_promoters{$_} = \%feature_subset
    }

    return (%features_promoters)
}

## This function ....

sub standarizeFeature {

    my ($self, $ref_featureInfo, %definedFeatures) = @_;

    my %featureInfo = %{$ref_featureInfo};
    
    my @features = keys(%featureInfo);

    foreach my $feature (@features) {
	my $reverseFeature = Utils::changeReverseFeature($feature);

        if (exists $definedFeatures{$reverseFeature}) {
            delete $featureInfo{$feature};
            $featureInfo{$reverseFeature} = 1;
        }
    }

    return (%featureInfo)
}


## This function ....

sub standarizeFeaturePerPromoter {

    my ($self, $ref_rulePerPromoter, %definedFeatures) = @_;

    my %rulePerPromoter = %{$ref_rulePerPromoter};

    my @Promoters = keys(%rulePerPromoter);

    my %standarizedFeatures = ();

    foreach my $promoter (@Promoters) {

	my %newFeatures = $self -> standarizeFeature($rulePerPromoter{$promoter}, %definedFeatures);

	$standarizedFeatures{$promoter}	= \%newFeatures
    }

    return (%standarizedFeatures)
}

## This function ....

sub number_sites {

    my ($self, @sites) = @_;

    my $index = 1;

    my @new_sites = ();

    foreach my $site (@sites) {
        push(@new_sites, ($index . "\t" . $site));
        $index++
    }

    return (\@new_sites)
}

## This function ...

sub number_promoter_sites {

    my ($self, %promoters) = @_;

    my @genes = keys(%promoters);

    my %new_promoters = ();

    foreach (@genes) { $new_promoters{$_} = $self -> number_sites(@{$promoters{$_}}) }

    return (%new_promoters)
}

## This function ...

sub matching_feature_npromoters {

    my ($self, $ref_feature_promoters, %computed_features) = @_;

    my %feature_promoters = %{$ref_feature_promoters};

    my @promoters = keys(%feature_promoters);

    foreach my $promoter (@promoters) {
	
	my %feature_promoter = %{$feature_promoters{$promoter}};   
	my @features = keys(%feature_promoter);
	
	foreach (@features) {
	    if (!exists $computed_features{$_}) { delete $feature_promoter{$_} }
	}

	$feature_promoters{$promoter} = \%feature_promoter
    }

    return (%feature_promoters)
}

1;
