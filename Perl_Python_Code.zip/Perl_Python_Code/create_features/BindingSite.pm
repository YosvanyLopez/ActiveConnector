#################################################################################################
## Laboratory of Functional Analysis in silico                                                 ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo                  ##
## Programmed by Yosvany Lopez Alvarez                                          February, 2012 ##
#################################################################################################

package BindingSite;

use warnings;
use strict;

## This function represents the class' constructor.

sub new {

    my ($self) = {};

    $self -> {ID} = undef;
    $self -> {MOTIFNAME} = undef;
    $self -> {POSITION} = undef;
    $self -> {SEQUENCE} = undef;
    $self -> {ORIENTATION} = undef;
    $self -> {SCORE} = undef;

    bless($self);

    return ($self);
}


## This function ....

sub UpdateAttributes {
    
    my ($self, $Id, $Position, $Sequence, $Orientation, $Score) = @_;
    
    $self -> {ID} = $Id;
    $self -> {POSITION} = $Position;
    $self -> {SEQUENCE} = $Sequence;
    $self -> {ORIENTATION} = $Orientation;
    $self -> {SCORE} = $Score;
}

## This function ....

sub SetMotifName {

    my ($self, $MotifName) = @_;

    $self -> {MOTIFNAME} = $MotifName
}

## This function .....

sub GetMotifName {

    my ($self) = @_;

    return ($self -> {MOTIFNAME})
}

## This function ...

sub getId {

    my ($self) = @_;
   
    return ($self -> {ID})
}

## This function ....

sub GetPosition {

    my ($self) = @_;

    return ($self -> {POSITION})
}


## This function ...

sub GetSequence {

    my ($self) = @_;

    return ($self -> {SEQUENCE})
}


## This function ....

sub GetOrientation {

    my ($self) = @_;

    return ($self -> {ORIENTATION})
}


## This function ...

sub GetScore {

    my ($self) = @_;

    return ($self -> {SCORE})
}


1;
