#################################################################################################
## This package contains the class "Promoter", which groups important characteristics of each  ##
## Transcription Factor Binding Site (TFBS) found within a promoter region.                    ##
##                                                                                             ##
## Laboratory of Functional Analysis in silico                                                 ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo                  ##
## Programmed by Yosvany Lopez Alvarez                                          February, 2012 ##
#################################################################################################

package promoter;

use warnings;
use strict;
use Utils;
use BindingSite;
use POSIX;

## This function represents the class' constructor.

sub new {

    my ($self) = {};

    %{$self -> {MOTIFS}} = ();
    
    bless($self);

    return ($self);
}


## This function ...

sub SetMotif {

    my ($self, $Motif, $TFBS) = @_;

    push(@{${$self -> {MOTIFS}}{$Motif}}, $TFBS); 

}

## This function ....

sub GetMotifs {

    my ($self) = @_;

    return (%{$self -> {MOTIFS}})
}

## This function .....

sub GetMotifInfo {

    my ($self, $Identifier) = @_;

    my @BSites = ();

    if (exists ${$self -> {MOTIFS}}{$Identifier}) {

	@BSites = @{${$self -> {MOTIFS}}{$Identifier}};
    }

    return (@BSites)
}


## This function receives a hash whose "keys" and "values" are integer indices and strings containing 
## the information related to each TFBS found (for instance, TF ---> StartPosition ----> PutativeSite
## ---> Orientation ---> Score) .... 

sub UpdateInfo {

    my ($self, $type, $upstreamPromoter, $downstreamPromoter, $ref_BindingSites) = @_;

    my @BindingSites = @{$ref_BindingSites};
    
    foreach my $BindingSite (@BindingSites) {

	my ($index, $TF, $Position, $Sequence, $Orientation, $Score) = Utils::GetValues($BindingSite);

	if ($type == 1) {
	    if ($Orientation eq "+") {
		if ($Position < $upstreamPromoter) { $Position = $upstreamPromoter - ($Position + length($Sequence) - 1) }
		else { $Position = $Position - $upstreamPromoter}
	    } else {
		if ($Position < $downstreamPromoter) { $Position = $downstreamPromoter - ($Position + length($Sequence) - 1) }
		else { $Position = $Position - $downstreamPromoter }
	    }
	    
	} else {

	    my $promoterLength = $upstreamPromoter + $downstreamPromoter;

	    if ($Orientation eq "+") { $Position = $promoterLength - ($Position + length($Sequence) - 1) }
	    	    
	}
	
	my $BSObject = new BindingSite();
	$BSObject -> UpdateAttributes($index, $Position, $Sequence, $Orientation, $Score);

	if (not exists ${$self -> {MOTIFS}}{$TF}) {

	    my @BindingSites = ();
	    push(@BindingSites, $BSObject);
	    ${$self -> {MOTIFS}}{$TF} = \@BindingSites;

	} else {

	    $self -> SetMotif($TF, $BSObject);
        }    
    }
}

## This function ....

sub SiteOneWindow {   

    my ($self, $InitialWValue, $LastWValue, $MotifIdentifier) = @_;
    
    my @MotifSites = $self -> GetMotifInfo($MotifIdentifier);

    my @BSPlusStrand = ();
    my @BSMinusStrand = ();

    my @Window = ($InitialWValue..$LastWValue);
    my %WindowSet = map { $_ => 1 } @Window;

    foreach my $BSite (@MotifSites) {
	
	my $Orientation = $BSite -> GetOrientation();
	my $Position = $BSite -> GetPosition();

	if (exists $WindowSet{$Position} ) {

	    $BSite -> SetMotifName($MotifIdentifier);

	    if ($Orientation eq "+") { push(@BSPlusStrand, $BSite) }
	    else { push(@BSMinusStrand, $BSite) }
	}
    }

    return (\@BSPlusStrand, @BSMinusStrand)
}

## This function ....

sub AllSitesOneWindow {

    my ($self, $InitialWValue, $LastWValue) = @_;

    my %Motifs = $self -> GetMotifs();
    my @MotifIdentifiers = keys(%Motifs);

    my %BSPlusStrand = ();
    my %BSMinusStrand = ();

    foreach my $MotifIdentifier (@MotifIdentifiers) {

	my ($ref_PlusStrand, @MinusStrand) = $self -> SiteOneWindow($InitialWValue, $LastWValue, $MotifIdentifier);
	$BSPlusStrand{$MotifIdentifier} = $ref_PlusStrand;
	$BSMinusStrand{$MotifIdentifier} = \@MinusStrand
    }

    return (\%BSPlusStrand, \%BSMinusStrand)
}

## This function .....

sub RuleOneInterval {

    my ($self, $WindowInfo, $ref_BSPlusStrand, $ref_BSMinusStrand, @MotifNames) = @_;

    my %BSPlusStrand = %{$ref_BSPlusStrand};
    my %BSMinusStrand = %{$ref_BSMinusStrand};
    
    my %PresenceRules = ();
    my %PresenceHints = ();

    foreach my $MotifName (@MotifNames) {

	my $RuleInfo = $MotifName . ':+:' . $WindowInfo;

	my @Empty = ();
	$PresenceRules{$RuleInfo} = \@Empty;
	$PresenceHints{$RuleInfo} = 0;
	
	if (exists $BSPlusStrand{$MotifName}) {

	    $PresenceRules{$RuleInfo} = $BSPlusStrand{$MotifName};
	    $PresenceHints{$RuleInfo} = scalar(@{$BSPlusStrand{$MotifName}});
	}

	$RuleInfo = $MotifName . ':-:' . $WindowInfo;

	$PresenceRules{$RuleInfo} = \@Empty;
	$PresenceHints{$RuleInfo} = 0;
        
	if (exists $BSMinusStrand{$MotifName}) {
	    
	    $PresenceRules{$RuleInfo} = $BSMinusStrand{$MotifName};
	    $PresenceHints{$RuleInfo} = scalar(@{$BSMinusStrand{$MotifName}});
	}
    }

    return (\%PresenceRules, %PresenceHints)
}

## This function ....

sub GeneratePresenceRules {

    my ($self, $ref_MotifNames, @WindowSizes) = @_;

    my @MotifNames = @{$ref_MotifNames};

    my %PresenceRules = ();
    my %PresenceHints = ();

    foreach my $WSize (@WindowSizes) {
	
	my @WLimits = split(":", $WSize);

	my ($ref_BSPlusStrand, $ref_BSMinusStrand) = $self -> AllSitesOneWindow($WLimits[0], $WLimits[1]);
	my ($ref_SubPresenceRules, %SubPresenceHints) = $self -> RuleOneInterval($WSize, $ref_BSPlusStrand, $ref_BSMinusStrand, @MotifNames);

	@PresenceRules{keys %{$ref_SubPresenceRules}} = values %{$ref_SubPresenceRules};
	@PresenceHints{keys %SubPresenceHints} = values %SubPresenceHints
    }

    my ($ref_PresenceRules, %FilteredRules) = $self -> RemoveRules(\%PresenceRules, %PresenceHints);

    my %new_rules = $self -> regard_both_strands(%FilteredRules);

    @FilteredRules{keys %new_rules} = values %new_rules;

    return ($ref_PresenceRules, %FilteredRules)
}

## This function ....

sub regard_both_strands {

    my ($self, %rule_hash) = @_;
 
    my @rules = keys(%rule_hash);

    my %any_orientation = ();

    foreach (@rules) {

        my @items = split(":", $_);

        if ($items[1] eq "+") {

            $items[1] = "-";
            
	    if (exists $rule_hash{join(":", @items)}) {

                my $minus_count = $rule_hash{join(":", @items)};
                my $plus_count = $rule_hash{$_};

		$items[1] = "*";

                if ($plus_count >= $minus_count) { $any_orientation{join(":", @items)} = $minus_count } 
		else { $any_orientation{join(":", @items)} = $plus_count }
            }
        }
    }

    return (%any_orientation)
}

## This function ....

sub RemoveRules {

    my ($self, $ref_BSites, %RuleSet) = @_;
    
    my %BSites = %{$ref_BSites};

    my @Rules = keys(%RuleSet);
    
    foreach my $Rule (@Rules) { 
	if ($RuleSet{$Rule} == 0) { 
	    delete $RuleSet{$Rule};
	    delete $BSites{$Rule}
	} 
    }

    return (\%BSites, %RuleSet)
}

## This function ....

sub SortOwnBSites {

    my ($self) = @_;

    my %Motifs = $self -> GetMotifs();

    my @MotifIDs = keys(%Motifs);

    my @SortedBSInstances = ();

    if (scalar(@MotifIDs) != 0) {

	my %BSInstances = ();
	my %Positions = ();
	my $Counter = 0;

	foreach my $MotifID (@MotifIDs) {

	    my @BSites = @{$Motifs{$MotifID}};

	    foreach my $BSite (@BSites) {

		$BSite -> SetMotifName($MotifID);
		$BSInstances{$Counter} = $BSite;
		$Positions{$Counter} = $BSite -> GetPosition();
		$Counter++
	    }
	}

	@SortedBSInstances = Utils::SortedBSites(\%BSInstances, %Positions);
    }

    return (@SortedBSInstances)
}

## This function ...

sub GetDistanceBetweenMotifRule {

    my ($self, $downstream, $WSize, $MotifNumber, $FinalPosition, $ref_rules, @BSites) = @_;

    my $InitialValue = $BSites[$MotifNumber] -> GetPosition();
    my $LeftMotifName = $BSites[$MotifNumber] -> GetMotifName();
    my $LeftOrientation = $BSites[$MotifNumber] -> GetOrientation();

    my $auxiliar_initial_value = $BSites[$MotifNumber] -> GetPosition();
    
    my $Range = 1;
    my %rules = %{$ref_rules};

    while ($InitialValue <= $FinalPosition - 1) {

	my $FinalValue = $InitialValue + $WSize - 1; 
	my @Window = ($InitialValue..$FinalValue);
	my %WindowSet = map { $_ => 1 } @Window;
    
	my $i = $MotifNumber + 1;
	while ($i <= scalar(@BSites) - 1) {

	    my $Orientation = $BSites[$i] -> GetOrientation();
	    my $Position = $BSites[$i] -> GetPosition();

	    if (exists $WindowSet{$Position}) {
		
		my $Limit = $Range * $WSize;
		my $RightMotifName = $BSites[$i] -> GetMotifName();
		my $RightOrientation = $BSites[$i] -> GetOrientation();

		my $distanceTSS = '*';
		my $region = '';

		if (($auxiliar_initial_value < $downstream) && ($Position < $downstream)) {

		    $distanceTSS = ceil(($downstream - $Position)/100);

		    if ($distanceTSS == 0) { $distanceTSS = 100 }
		    else { $distanceTSS = $distanceTSS * 100 }

		    $region = 'd'

		} elsif (($auxiliar_initial_value > $downstream) && ($Position > $downstream)) {
    
		    $distanceTSS = ceil(($auxiliar_initial_value - $downstream)/100);
		    
		    if ($distanceTSS == 0) { $distanceTSS = 100 }
                    else { $distanceTSS = $distanceTSS * 100 }

		    $region = 'u'

	        } else { $region = 't' }  
			
		my $rule = $region . '#'. $distanceTSS . '#'. $LeftMotifName . ':' . $LeftOrientation . ':' . $RightMotifName . ':' . $RightOrientation . ':' . "0:" . $Limit;

		if (exists $rules{$rule}) { $rules{$rule} = $rules{$rule} + 1 } 
		else { $rules{$rule} = 1 }
	    }

	    $i++
	}
    
	$InitialValue = $FinalValue + 1;
	$Range++
    } 

    return (%rules)
}

## This function .....

sub DistanceBetweenMotifRules  {

    my ($self, $downstream, $wsize, $promoter_length, @sites) = @_;

    my %rules = ();

    my $i = 0;
    while ($i <= scalar(@sites) - 1) {

        %rules = $self -> GetDistanceBetweenMotifRule($downstream, $wsize, $i, $promoter_length, \%rules, @sites);

        $i++
    }

    my @rule_keys = keys(%rules);

    my %alternative_features = ();

    foreach (@rule_keys) {

	my @items = split("#", $_);
	my @subitems = split(":", $items[2]);

	my $feature = $items[0] . '#'. $items[1] . '#'. $subitems[0] . ':' . $subitems[1] . ':' . $subitems[2] . ':' . $subitems[3] . ':' . $subitems[4] . ':' . $subitems[5];
	my $alternative_feature = $items[0] . '#'. $items[1] . '#'. $subitems[2] . ':' . $subitems[3] . ':' . $subitems[0] . ':' . $subitems[1] . ':' . $subitems[4] . ':' . $subitems[5];

	if ($feature ne $alternative_feature) { 
	    if (exists $rules{$alternative_feature}) {
		$rules{$feature} = $rules{$feature} + $rules{$alternative_feature};
		if ((! exists $alternative_features{$feature}) && (! exists $alternative_features{$alternative_feature})) { $alternative_features{$alternative_feature} = 1 }
	    }
	}
    }

    my @redundant_features = keys(%alternative_features);
    foreach (@redundant_features) { delete $rules{$_} }

    return (%rules)
}

## This function ....

sub RemoveRuleOneMotif {

    my ($self, %Rules) = @_;

    my @RuleIDs = keys(%Rules);
   
    foreach my $RuleID (@RuleIDs) {
	my @Items = split(":", $RuleID);
	if (scalar(@Items) == 2) { delete $Rules{$RuleID} }
    }
    
    return (%Rules)
}

## This function ...

sub splitBS_TSS {

    my ($self, $downstream) = @_;

    my @BSites = $self -> SortOwnBSites();

    my @upstreamBS = ();
    my @downstreamBS = ();

    if (scalar(@BSites) != 0) {
	
	my $i = 0;
	while ($i <= scalar(@BSites) - 1) {
	    
	    my $Position = $BSites[$i] -> GetPosition();

	    if ($Position >= $downstream) { push (@upstreamBS, $BSites[$i]) }
	    else { push (@downstreamBS, $BSites[$i]) }

	    $i++
	}
    }

     return (\@upstreamBS, @downstreamBS)
}

## This function ...

sub GetUpstreamOrientation {

    my ($self, $region,  @upstreamBS) = @_;

    my %rules = ();
    
    if (scalar(@upstreamBS) != 0) {

	for (my $i = 0; $i <= scalar(@upstreamBS) - 2; $i++) {
	    
	    my $motif_order_1 = ($upstreamBS[$i] -> GetMotifName()) . ":" . ($upstreamBS[$i] -> GetOrientation()); 

	    for (my $j = $i + 1; $j <= scalar(@upstreamBS) - 1; $j++) {
		
		my $motif_order_2 = ($upstreamBS[$j] -> GetMotifName()) . ":" . ($upstreamBS[$j] -> GetOrientation());
		
		my $rule_2 = $motif_order_1 . ":" . $motif_order_2;

		my $auxiliar_rule_2 = $rule_2 . ":" . $region;
		
		if (exists $rules{$auxiliar_rule_2}) { $rules{$auxiliar_rule_2} = $rules{$auxiliar_rule_2} + 1 }
		else {$rules{$auxiliar_rule_2} = 1 }

		for (my $k = $j + 1; $k <= scalar(@upstreamBS) - 1; $k++) {

		    my $motif_order_3 = ($upstreamBS[$k] -> GetMotifName()) . ":" . ($upstreamBS[$k] -> GetOrientation());
		    
		    my $rule_3 = $rule_2 . ":" . $motif_order_3 . ":" . $region;

		    if (exists $rules{$rule_3}) { $rules{$rule_3} = $rules{$rule_3} + 1 }
                    else {$rules{$rule_3} = 1 }
		}
	    }
	}
    }

    return (%rules)
}

## This function ...

sub presence_rules {

    my ($self, $region, @sites) = @_;

    my %rules = ();

    if (scalar(@sites) != 0) {

	foreach (@sites) {
	    
	    my $rule = ($_ -> GetMotifName()) . ":" . ($_ -> GetOrientation()) . ":" . $region;
	    
	    if (exists $rules{$rule}) { $rules{$rule} = $rules{$rule} + 1 }
	    else { $rules{$rule} = 1 }
	}
    }

    return (%rules)
}

1;
