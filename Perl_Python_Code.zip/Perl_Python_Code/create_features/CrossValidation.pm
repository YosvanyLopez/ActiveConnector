################################################################################################
## Laboratory of Functional Analysis in silico                                                ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo                 ##
## Programmed by Yosvany Lopez Alvarez                                            April, 2013 ##
################################################################################################

package CrossValidation;

use warnings;
use strict;

sub new {

    my ($self) = {};

    bless($self);

    return ($self)
}

sub feature_promoter {

    my ($self, $feature, $ref_gene_names, %feature_promoters) = @_;

    my @gene_names = sort(@{$ref_gene_names}); 

    my @hints = ();

    for (my $i = 0; $i <= scalar(@gene_names) - 1; $i++) {

	my %features = %{$feature_promoters{$gene_names[$i]}};

	if (exists $features{$feature}) { push(@hints, $features{$feature}) }
        else { push(@hints, 0) }
    }

    my $str = $feature . "\t" . join("\t", @hints); 

    return ($str)
}

sub features_promoters {

    my ($self, $file_name, $ref_features, %feature_promoters) = @_;

    my %feature_hash = %{$ref_features};
    my @features = sort(keys(%feature_hash));
   
    my @gene_names = keys(%feature_promoters);

    open(OUTPUT, ">$file_name");

    for (my $i = 0; $i <= scalar(@features) - 1; $i++) {

	my $str = $self -> feature_promoter($features[$i], \@gene_names, %feature_promoters);

	print OUTPUT $str;
	print OUTPUT "\n"
    }

    close(OUTPUT)
}

sub CreateCrossValidationFolds {
 
    my ($self, $FoldNumber, %RulesPerPromoter) = @_;

    my %Folders = ();

    my @GeneNames = keys(%RulesPerPromoter);
    my $PromoterNumber = scalar(@GeneNames);

    my $PromoterOneFold;

    do {

	my $i = 1;
	while ($i <= $FoldNumber - 1) {
	
	    my $RandomNumber = int(rand($PromoterNumber));
    
	    my %Items;

	    if (exists($Folders{$i})) { %Items = %{$Folders{$i}} } 
	    else { %Items = () }

	    $Items{$GeneNames[$i]} = $RulesPerPromoter{$GeneNames[$i]};
	    $Folders{$i} = \%Items;
	    delete $RulesPerPromoter{$GeneNames[$i]};

	    $i++
	}

	@GeneNames = keys(%RulesPerPromoter);
	$PromoterNumber = scalar(@GeneNames);
	$PromoterOneFold = scalar(keys(%{$Folders{1}}));

    } until ($PromoterNumber <= $PromoterOneFold);

    $Folders{$FoldNumber} = \%RulesPerPromoter;

    return (%Folders)
}

sub GetTrainingTestSubfolders {

    my ($self, $foldNumber, %folders) = @_;

    my %testFold = %{$folders{$foldNumber}};
    delete $folders{$foldNumber};

    my @remainingFolds = keys(%folders);

    my %trainingFold = ();

    foreach my $fold (@remainingFolds) {
        my %auxiliar = %{$folders{$fold}};
        @trainingFold {keys %auxiliar} = values %auxiliar
    }

    return (\%trainingFold, %testFold)
}

sub get_training_test_folds {

    my ($self, $class, $fold_number, $directory, $ref_features, %folders) = @_;

    for (my $i = 1; $i <= $fold_number; $i++) {
	
	my ($ref_training_fold, %test_fold) = $self -> GetTrainingTestSubfolders($i, %folders);

	my ($training_file, $test_file);

	if ($class == 1) {
	    $training_file = $directory . "PTraining_" . $i . ".txt";
	    $test_file = $directory . "PTest_" . $i . ".txt";
	} else {
	    $training_file = $directory . "NTraining_" . $i . ".txt";
            $test_file = $directory . "NTest_" . $i . ".txt";
	}

	$self -> features_promoters ($training_file, $ref_features, %{$ref_training_fold});
	$self -> features_promoters ($test_file, $ref_features, %test_fold)
    }  
}

sub get_cv_runs {

    my ($self, $class, $run_times, $fold_number, $directory, $ref_features, %feature_promoters) = @_;

    my $i = 1;
    while ($i <= $run_times) {

	my %folders = $self -> CreateCrossValidationFolds($fold_number, %feature_promoters);

	my $new_directory = $directory . $i . "/";
        mkdir $new_directory;

	$self -> get_training_test_folds($class, $fold_number, $new_directory, $ref_features, %folders);
	
	$i++
    }
}

1;
