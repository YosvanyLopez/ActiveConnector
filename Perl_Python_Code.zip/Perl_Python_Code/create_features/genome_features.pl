###########################################################################################                                                   
## Laboratory of Functional Analysis in silico                                           ##                                                   
## Human Genome Center, Institute of Medical Science, The University of Tokyo            ##                                                   
## Programmed by Yosvany Lopez Alvarez                                       March, 2015 ##                                                   
###########################################################################################                                                  

#!/usr/local/bin/perl
                                                                                                                          
use warnings;
use strict;
use File;
use promoter_set;
use Utils;

###########################################################################################                                                  

my $upstream = 1500;

my $downstream = 500;
 
my $genome_file = './dmel_development/stage_' . $ARGV[0] .'/hash_genome.info';

my $motif_file = './dmel_development/stage_' . $ARGV[0] . '/model_build/pfmatrices.info';

my $feature_file = './dmel_development/stage_' . $ARGV[0] . '/model_build/optimal_features.txt';

my $feature_genome_file = './dmel_development/stage_' . $ARGV[0] . '/genome_info/feature_genome.info';

##########################################################################################

my $file_object = new File();
my %binding_sites = $file_object -> Recover($genome_file);

my %pfmatrices = $file_object -> Recover($motif_file);
my @motif_id = keys(%pfmatrices);

##########################################################################################                                        

my @wsizes = ('100');

## Type "1" organizes the BSs regarding orientation, whereas "2" doesn't consider strand restriction

my $promoter_instance = new promoter_set();
my %updated_promoters = $promoter_instance -> update_promoter_collection(1, $upstream, $downstream, %binding_sites);
my %unrestricted_promoters = $promoter_instance -> update_promoter_collection(2, $upstream, $downstream, %binding_sites);

##########################################################################################
# Position of motifs from start site on both strands                             
##########################################################################################                        

my @windows = $promoter_instance -> CreateDifferentWindows($upstream, @wsizes);
my ($ref_position_promoters, @position_features) = $promoter_instance -> RulesPerPromoter(\@motif_id, \@windows, %updated_promoters);

##########################################################################################
# Order of motifs                                                                                                                             
##########################################################################################                                                                                        

my ($ref_order_promoters, @order_features) = $promoter_instance -> GetOrderRulePerPromoters($downstream, %unrestricted_promoters);

#########################################################################################
# Presence of motifs
#########################################################################################

my ($ref_presence_promoters, @presence_features) = $promoter_instance -> get_presence_rules($downstream, %unrestricted_promoters);

##########################################################################################
# Distance between two motifs                             
##########################################################################################

my ($ref_positioning_promoters, @positioning_features) = $promoter_instance -> distance_between_motifs(100, $downstream, ($upstream + $downstream), %unrestricted_promoters);
my %updated_positioning_promoters = $promoter_instance -> replace_positioning_features($ref_positioning_promoters, @positioning_features);

##########################################################################################

my %features_per_promoters = $promoter_instance -> merge_features_promoters($ref_position_promoters, $ref_order_promoters, $ref_presence_promoters, %updated_positioning_promoters);

my %optimal_features = ();

open(INPUT, "$feature_file");
while (my $line = <INPUT>) {
    my @items = split("\t", Utils::trim($line));
    $optimal_features{$items[0]} = 1
}

my %unremoved_feature_promoters = $promoter_instance -> matching_feature_npromoters(\%features_per_promoters, %optimal_features);

$file_object -> Save($feature_genome_file, %unremoved_feature_promoters);

##########################################################################################
