###########################################################################################
## Laboratory of Functional Analysis in silico                                           ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo            ##                                                   
## Programmed by Yosvany Lopez Alvarez                                       March, 2015 ##                                                   
###########################################################################################                                                  

#!/usr/local/bin/perl
                                                                                                                          
use warnings;
use strict;
use File;
use CrossValidation;

###########################################################################################                                                  
 
my $feature_file = './dmel_development/stage_' . $ARGV[0] . '/feature_generation/FC_features.txt';

my $positive_file = './dmel_development/stage_' . $ARGV[0] . '/model_build/mbuild_features.info';

my $negative_file = './dmel_development/stage_' . $ARGV[0] . '/model_build/cmbuild_features.info';

my $output_directory = './dmel_development/stage_' . $ARGV[0] . '/model_build/cv/';

##########################################################################################

my $file_object = new File();

my %positive_features = $file_object -> Recover($positive_file);
my %negative_features = $file_object -> Recover($negative_file);

my @gene_names = keys(%negative_features);

my %reduced_negative = ();
my %random_list = ();

while (scalar(keys(%random_list)) < (scalar(keys(%positive_features)) ) ) {
    my $random_number = int(rand(scalar(@gene_names)));
    if (!exists $random_list{$random_number}) {
	$random_list{$random_number} = 1;
	$reduced_negative{$gene_names[$random_number]} = $negative_features{$gene_names[$random_number]}
    }   
}

my %computed_features = $file_object -> RuleFileReader($feature_file);

my $cv_object = new CrossValidation();

mkdir $output_directory;

$cv_object -> get_cv_runs(1, 1, 5, $output_directory, \%computed_features, %positive_features);
$cv_object -> get_cv_runs(0, 1, 5, $output_directory, \%computed_features, %reduced_negative);

##########################################################################################
