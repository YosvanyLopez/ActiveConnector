###########################################################################################                                                   
## Laboratory of Functional Analysis in silico                                           ##                                                   
## Human Genome Center, Institute of Medical Science, The University of Tokyo            ##                                                   
## Programmed by Yosvany Lopez Alvarez                                     January, 2015 ##                                                   
###########################################################################################                                                  

#!/usr/local/bin/perl
                                                                                                                          
use warnings;
use strict;
use File;
use promoter_set;

###########################################################################################                                                  

my $positive_file = ''; ## collection of positive promoters and features

my $control_file = ''; ## collection of negative promoters and features

my $feature_file = ''; ## collection of features - either as a text file or a saved variable

my $pos_binary_file = ''; ## file to save hits of each feature for the positive set

my $neg_binary_file = ''; ## file to save hits of each feature for the negative set

##########################################################################################

my $file_object = new File();

## my %feature_hash = $file_object -> Recover($feature_file); ## This line is commented as long as the input feature file is a text file

## The following lines are commented if the input feature file is a saved variable. In this case, the comment of the previous line is removed   

my %feature_hash = ();

open(IN, $feature_file);

while (<IN>) {

    $_ = Utils::trim($_);

    $feature_hash{$_} = 1
}

close(IN);

## until here

my %positive_features = $file_object -> Recover($positive_file);
my %control_features = $file_object -> Recover($control_file);

my $promoter_obj = new promoter_set();
$promoter_obj -> hits_per_feature($pos_binary_file, \%feature_hash, %positive_features);
$promoter_obj -> hits_per_feature($neg_binary_file, \%feature_hash, %control_features);

##########################################################################################
