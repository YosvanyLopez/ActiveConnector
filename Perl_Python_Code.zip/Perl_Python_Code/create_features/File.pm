##############################################################################################
## This package contains the class "File", which groups those functions performing          ##
## operations such as reading and writing of information from/into external data files.     ##
##                                                                                          ##
## Laboratory of Functional Analysis in silico                                              ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo               ##
## Programmed by Yosvany Lopez Alvarez                                       November, 2011 ##
##############################################################################################

package File;

use warnings;
use strict;
use Storable;
use Utils;

## This function stands for the class' constructor.

sub new {

    my $self = {};

    bless($self);
       
    return ($self)
}

## This function ....

sub RuleFileReader {

    my ($self, $FileName) = @_;

    open(INPUT, $FileName);

    my %DefinedRules = ();

    my $line = '';
    while ($line = <INPUT>) { $DefinedRules{Utils::trim($line)} = 1 }

    return (%DefinedRules)
}

## This function .....

sub Save {

    my ($self, $FileName, %Rules) = @_;

    store(\%Rules, $FileName)
}

## This function receives an external file, and returns the hash stored inside it.

sub Recover {

    my ($self, $ExternalFile) = @_;

    my $DataHash = retrieve($ExternalFile);

    return (%{$DataHash})
}


## This function receives three parameters: (1) handler of the file where the information
## will be written, (2) pattern's identifier, and (3) hash standing for the Position 
## Frequency Matrix (PFM) whose "keys" and "values" are DNA nucleotides ('A'-'C'-'G'-'T') 
## as well as lists composed of their respective amounts. Lastly, such a PFM is written 
## into an external file.

sub PositionMatrixWriter {

    my ($self, $FileHandler, $Index, %PositionMatrix) = @_;

    print($FileHandler "<" . $Index . ">");
    print($FileHandler "\n");
    print($FileHandler "<BEGIN>");
    print($FileHandler "\n");

    my @NucleotideList = sort(keys(%PositionMatrix));

    foreach my $Nucleotide (@NucleotideList) {

	my @ReversedRow = reverse(@{$PositionMatrix{$Nucleotide}});
	push(@ReversedRow, $Nucleotide);
	my $Sequence = join("\t", reverse(@ReversedRow));

	print ($FileHandler $Sequence);
	print ($FileHandler "\n");
    }

    print ($FileHandler "<END>");
    print ($FileHandler "\n");
    print ($FileHandler "\n");
}


## This function receives two parameters: (1) output file name, and (2) hash whose "keys"
## and "values" are pattern's identifiers as well as other hashes standing for PFMs. Finally, 
## such information is thoroughly written into the typed file.

sub WriterOfAll {

    my ($self, $OutputFile, %PatternData) = @_;

    my $Output;
    open($Output, ">$OutputFile");

    print ($Output '****** TRANSCRIPTION FACTORS *******' . "\n");
    print ($Output "\n");

    my @PatternIdentifiers = sort(keys(%PatternData));

    foreach my $PatternIdentifier (@PatternIdentifiers) {

	$self -> PositionMatrixWriter($Output, $PatternIdentifier, %{$PatternData{$PatternIdentifier}});
    }
    
    close ($Output);
}


## This function .....

sub WriteRuleInfo {

    my ($self, $OutputFile, $ref_GeneNames, %RulesPerPromoter)	= @_;

    open(OUTPUT, ">$OutputFile");

    my $GeneString = join("\t", @{$ref_GeneNames});
    $GeneString	= "\t" .  $GeneString;

    print(OUTPUT $GeneString);
    print OUTPUT "\n";

    my @Rules = keys(%RulesPerPromoter);

    foreach my $Rule (@Rules) {

	my $String = $Rule . "\t" . join("\t", @{$RulesPerPromoter{$Rule}});
	$String = Utils::trim($String);

	print OUTPUT $String;
	print OUTPUT "\n"
    }

    close (OUTPUT)
}

## This function ....

sub FoldSaver {

    my ($self, $Directory, $ref_PTraining, $ref_PTest, $ref_NTraining, %NTest) = @_;

    my %PTraining = %{$ref_PTraining};
    my %PTest = %{$ref_PTest};
    my %NTraining = %{$ref_NTraining};
    
    my @Folds = keys(%NTest);

    foreach my $Fold (@Folds) {

	my $PTaFile = $Directory . 'PTraining_' . $Fold . '.perl';
        my $PTeFile = $Directory . 'PTest_' . $Fold . '.perl';
	
	$self -> Save($PTaFile, %{$PTraining{$Fold}});
        $self -> Save($PTeFile, %{$PTest{$Fold}});
    
	my $NTaFile = $Directory . 'NTraining_' . $Fold . '.perl';
        my $NTeFile = $Directory . 'NTest_' . $Fold . '.perl';
	
	$self -> Save($NTaFile, %{$NTraining{$Fold}});
        $self -> Save($NTeFile, %{$NTest{$Fold}});
    }
}

## This function ....

sub FoldWriter {

    my ($self, $Directory, $ref_PTraining, $ref_PTest, $ref_NTraining, %NTest)= @_;

    my %PTraining = %{$ref_PTraining};
    my %PTest =%{$ref_PTest};
    my %NTraining = %{$ref_NTraining};

    my @RunTimes = keys(%NTest);

    foreach my $RunTime (@RunTimes) {

        my $CVName = $Directory . $RunTime . '/';
        mkdir $CVName;

        $self -> FoldSaver($CVName, $PTraining{$RunTime}, $PTest{$RunTime}, $NTraining{$RunTime}, %{$NTest{$RunTime}});
    }
}

1;
