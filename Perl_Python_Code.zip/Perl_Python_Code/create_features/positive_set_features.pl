###########################################################################################                                                   
## Laboratory of Functional Analysis in silico                                           ##                                                   
## Human Genome Center, Institute of Medical Science, The University of Tokyo            ##                                                   
## Programmed by Yosvany Lopez Alvarez                                     January, 2015 ##                                                   
###########################################################################################                                                  

#!/usr/local/bin/perl
                                                                                                                          
use warnings;
use strict;
use File;
use promoter_set;
use Utils;

###########################################################################################
                                                  
my $upstream = 1500;

my $downstream = 500;
 
my $BSiteFile = ''; ## collection of promoters and predicted binding sites

my $PFMatrixFile = ''; ## motif matrices

my $FeatureFile = ''; ## file to save all the features computed from the positive set

my $FeaturePromoterFile = ''; ## file to save the features computed per promoter

##########################################################################################

my $file_object = new File();
my %binding_sites = $file_object -> Recover($BSiteFile);

my %pfmatrices = $file_object -> Recover($PFMatrixFile);
my @motif_id = keys(%pfmatrices);

##########################################################################################                                        

my @wsizes = ('100');

## Type "1" organizes the BSs regarding orientation, whereas "2" doesn't consider strand restriction ....

my $promoter_instance = new promoter_set();
my %updated_promoters = $promoter_instance -> update_promoter_collection(1, $upstream, $downstream, %binding_sites);
my %unrestricted_promoters = $promoter_instance -> update_promoter_collection(2, $upstream, $downstream, %binding_sites);

##########################################################################################
# Position of motifs from start site on both strands                             
##########################################################################################                        

my @windows = $promoter_instance -> CreateDifferentWindows($upstream, @wsizes); 
my ($ref_position_promoters, @position_features) = $promoter_instance -> RulesPerPromoter(\@motif_id, \@windows, %updated_promoters);

##########################################################################################
# Order of motifs                                                                                                                             
##########################################################################################
                                                                                        
my ($ref_order_promoters, @order_features) = $promoter_instance -> GetOrderRulePerPromoters($downstream, %unrestricted_promoters);

#########################################################################################
# Presence of motifs
#########################################################################################

my ($ref_presence_promoters, @presence_features) = $promoter_instance -> get_presence_rules($downstream, %unrestricted_promoters); 

##########################################################################################
# Distance between two motifs                             
##########################################################################################

my ($ref_positioning_promoters, @positioning_features) = $promoter_instance -> distance_between_motifs(100, $downstream, ($upstream + $downstream), %unrestricted_promoters);
my %updated_positioning_promoters = $promoter_instance -> replace_positioning_features($ref_positioning_promoters, @positioning_features);

##########################################################################################

my %feature_collection = $promoter_instance -> merge_all_features(\@position_features, \@order_features, \@presence_features, @positioning_features);
my %features_per_promoters = $promoter_instance -> merge_features_promoters($ref_position_promoters, $ref_order_promoters, $ref_presence_promoters, %updated_positioning_promoters);

$file_object -> Save($FeatureFile, %feature_collection);

$file_object -> Save($FeaturePromoterFile, %features_per_promoters);

##########################################################################################
