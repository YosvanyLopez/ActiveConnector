##############################################################################################
## Laboratory of Functional Analysis in silico                                              ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo               ##
## Programmed by Yosvany Lopez Alvarez                                         January 2016 ##
##############################################################################################

#!/usr/local/bin/python

from handler import *

########################################################################################################

gene_fpkm_file = './dmel_development/validation_data/cuffnorm/genes.fpkm_table'

gene_attr_file = './dmel_development/validation_data/cuffnorm/genes.attr_table'

fpkm_file = "./dmel_development/validation_data/fpkm.info"

zscore_file = "./dmel_development/validation_data/zscores.info"

########################################################################################################

handler_obj = handler ()

gene_table = handler_obj.read_gene_table(gene_attr_file)

fpkm_values = handler_obj.read_fpkm_values(gene_fpkm_file, gene_table)

handler_obj.save_variable(fpkm_file, fpkm_values)

zscore_values = handler_obj.get_zscores(fpkm_values)

handler_obj.save_variable(zscore_file, zscore_values)

########################################################################################################
