##############################################################################################
## Laboratory of Functional Analysis in silico                                              ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo               ##
## Programmed by Yosvany Lopez Alvarez                                         January 2016 ##
##############################################################################################

#!/usr/local/bin/python

from handler import *
from sets import Set
import sys

##############################################################################################

transcript_file = "./dmel_development/all_genes.txt"

fpkm_file = "./dmel_development/validation_data/fpkm.info"

positive_gene_file = "./dmel_development/similarity_stages/stage_" + sys.argv[2] + "/stage_" + sys.argv[1] + "/positive_set.txt"

negative_gene_file = "./dmel_development/similarity_stages/stage_" + sys.argv[2] + "/stage_" + sys.argv[1] + "/negative_set.txt"

##############################################################################################

handler_obj = handler()

fpkm_values = handler_obj.load_variable(fpkm_file)

transcript_list = handler_obj.get_initial_gene_set(transcript_file)

expressed_stage1 = handler_obj.get_gene_collections(int(sys.argv[3]), 1, fpkm_values) ## index of one stage
expressed_stage2 = handler_obj.get_gene_collections(int(sys.argv[4]), 1, fpkm_values) ## index of another stage

expressed_stage1 = Set(expressed_stage1) & Set(transcript_list)
expressed_stage2 = Set(expressed_stage2) & Set(transcript_list)

positive_genes = expressed_stage1

negative_genes = Set(transcript_list) - positive_genes
negative_genes = negative_genes - expressed_stage2

handler_obj.write_genes(positive_gene_file, positive_genes)
handler_obj.write_genes(negative_gene_file, negative_genes)

###############################################################################################

