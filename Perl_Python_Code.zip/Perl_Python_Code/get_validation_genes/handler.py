##############################################################################################
## Laboratory of Functional Analysis in silico                                              ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo               ##
## Programmed by Yosvany Lopez Alvarez                                         January 2016 ##
##############################################################################################

from utils import *
import pickle

class handler:

    ## This function ....

    def read_gene_table (self, file_name):

        gene_table = dict()

        input = open(file_name, "r")

        for line in input:
            if (not line.startswith("tracking_id")):
                line = line.strip()
                items = line.split("\t")
                gene_table[items[0]] = items[4]

        input.close()

        return (gene_table)

    ## This function ....

    def read_fpkm_values (self, file_name, gene_table):

        fpkm_values = dict()

        input = open(file_name, "r")

        for line in input:
            if (not line.startswith("tracking_id")):
                line = line.strip()
                items = line.split("\t")

                loci = items[0]
                items.pop(0)

                items = string_to_float(items)

                genes = gene_table[loci].split(",")

                for gene in genes:
                    if gene in fpkm_values:
                        gene = gene + "/" + loci
                    fpkm_values[gene] = items

        input.close()
        
        return (fpkm_values)
   
    ## This function ...

    def get_zscores (self, gene_expressions):

        zscores = dict()

        for gene in (gene_expressions.keys()):
            zscores[gene] = compute_ZScore(gene_expressions[gene])
        
        return (zscores)

    ## This function ...

    def get_gene_collections (self, sample_idx, threshold, expression_values):

        expressed_genes = []

        for gene in (expression_values.keys()):
            expressions = expression_values[gene]
            if (expressions[sample_idx] > threshold):
                expressed_genes.append(gene.upper())
            
        return (expressed_genes)

    
    ## This function ...

    def average_gene_expression (self, sample_idx, gene_list, expression_values):

        expressed_genes = []

        for gene in (gene_list):
            gene = gene.replace("G", "g")
            gene = gene.replace("N", "n")
            if (gene in expression_values.keys()):
                expressions = expression_values[gene]
                expressed_genes.append(expressions[sample_idx])

        average = sum(expressed_genes)/len(expressed_genes)

        return (average)

    ## This function ...

    def get_gene_expressions (self, sample_idx, threshold, expression_values):

        expressed_genes = []
        nonexpressed_genes = []

        for gene in (expression_values.keys()):
            expressions = expression_values[gene]
            if (expressions[sample_idx] > threshold):
                expressed_genes.append(gene.upper()) 
            else:
                nonexpressed_genes.append(gene.upper())

        return (expressed_genes, nonexpressed_genes)

    ## This function ...

    def get_selected_genes (self, file_name):

        selected_genes = []

        input = open(file_name, "r")

        for line in (input.readlines()):
            line = line.strip()
            items = line.split("\t")
            selected_genes.append(items[1])

        input.close()

        return (selected_genes)

    ## This function ...

    def get_initial_gene_set (self, file_name):
        
        input = open(file_name, "r")

        lines = input.readlines()
        gene_line = lines[0].strip()
        gene_set = gene_line.split("\t")

        input.close()

        gene_set = map(lambda x: x.upper(), gene_set)

        return (gene_set)
   
    ## This function ...

    def save_variable (self, file_name, dictionary):
        
        file_handler = open(file_name, 'wb')
    
        pickle.dump(dictionary, file_handler)

    ## This function ...

    def load_variable (self, file_name):
        
        file_handler = open(file_name,'rb')
        dictionary = pickle.load(file_handler)

        return (dictionary)

    ## This function ...

    def write_genes (self, file_name, gene_list):

        output = file(file_name, "w")

        output.write("\n".join(gene_list))

        output.close()

    ## This function ...

    def write_gene_expressions (self, file_name, expression, nonexpression):

        output = file(file_name, "w")

        expressed_str = ",".join(map(str, expression))
        expressed_str = "expression," + expressed_str
        output.write(expressed_str)
        output.write("\n")
        
        nonexpressed_str = ",".join(map(str, nonexpression))
        nonexpressed_str = "nonexpression," + nonexpressed_str
        output.write(nonexpressed_str)
        
        output.close()
