##############################################################################################
## Laboratory of Functional Analysis in silico                                              ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo               ##
## Programmed by Yosvany Lopez Alvarez                                         January 2016 ##
##############################################################################################

#!/usr/local/bin/python

from handler import *
from sets import Set
import sys

##############################################################################################

transcript_file = "./dmel_development/all_genes.txt"

fpkm_file = "./dmel_development/validation_data/fpkm.info"

initial_gene_file = "./dmel_development/stage_" + sys.argv[1] +  "/initial_sets/initial_set.txt"

selected_gene_file = "./dmel_development/stage_" + sys.argv[1] + "/genome_info/selected_genes_100.txt"

final_gene_file = "./dmel_development/stage_" + sys.argv[1] + "/genome_info/overlapped_genes.txt"

##############################################################################################

handler_obj = handler ()

fpkm_values = handler_obj.load_variable(fpkm_file)

fpkm_gene_list = handler_obj.get_gene_collections(int(sys.argv[2]), 1, fpkm_values) ## index of the stage

expressed_genes = Set(fpkm_gene_list)

initial_gene_set = handler_obj.get_initial_gene_set(initial_gene_file)
 
transcript_list = handler_obj.get_initial_gene_set(transcript_file)

selected_gene_list = handler_obj.get_selected_genes(selected_gene_file)

expressed_genes = expressed_genes & Set(transcript_list)

selected_gene_list = Set(selected_gene_list) - Set(initial_gene_set)

final_gene_list = selected_gene_list & expressed_genes

handler_obj.write_genes(final_gene_file, final_gene_list)

#######################################################################################################

