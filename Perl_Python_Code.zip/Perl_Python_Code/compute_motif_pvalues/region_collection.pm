#########################################################################################
## Laboratory of Functional Analysis in silico                                         ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo          ##
## Programmed by Yosvany Lopez Alvarez                                  November, 2014 ##
#########################################################################################

package region_collection;

use warnings;
use strict;

## This function ....

sub new {

    my $self = {};

    bless($self);
    
    return ($self)
}

## This function ...

sub update_pattern_info {

    my ($self, @tfbs) = @_;

    my %patterns = ();

    foreach (@tfbs) {

        my @items = split('\t', Utils::Trim($_));

        my $motif_id = $items[1];

        if (not exists $patterns{$motif_id}) { $patterns{$motif_id} = 1 }
        else { $patterns{$motif_id} = $patterns{$motif_id} + 1 }
    }

    return (%patterns)
}

## This function ...

sub update_region_collection {

    my ($self, %tfbs_per_region) = @_;

    my @genes = keys(%tfbs_per_region);

    my %ref_gene = ();
    my %pattern_per_gene = ();

    my $index = 0;

    foreach (@genes) {

	my %auxiliar = $self -> update_pattern_info(@{$tfbs_per_region{$_}});

	$pattern_per_gene{$_} = \%auxiliar;
	$ref_gene{$index} = $_;
	
	$index++
    }

    return (\%ref_gene, %pattern_per_gene)
}

## This function ...

sub pattern_info {

    my ($self, $pattern, $ref_ref_gene, %pattern_per_gene) = @_;

    my %ref_gene = %{$ref_ref_gene};

    my @genes = keys(%pattern_per_gene);

    my @region_with_pattern = ();
    my @pattern_per_region = ();

    for (my $i = 0; $i <= scalar(@genes) - 1; $i++) {

	my %patterns = %{$pattern_per_gene{$ref_gene{$i}}};

	if (exists $patterns{$pattern}) {
	    push(@pattern_per_region, $patterns{$pattern}); 
	    push(@region_with_pattern, $ref_gene{$i})
	} else { push(@pattern_per_region, 0) }
    }

    return (\@pattern_per_region, @region_with_pattern)
}

## This function ...

sub pattern_collection_info {

    my ($self, $ref_gene, $ref_pattern_per_gene, %patterns) = @_;

    my %region_with_pattern = ();
    my %pattern_per_region = ();
 
    my @motifs = keys(%patterns);

    foreach (@motifs) {

	my ($aux_region_with_pattern, @aux_pattern_per_region) = $self -> pattern_info($_, $ref_gene, %{$ref_pattern_per_gene});

	$region_with_pattern{$_} = $aux_region_with_pattern; 
	$pattern_per_region{$_} = \@aux_pattern_per_region
    }
    
    return (\%region_with_pattern, %pattern_per_region)
}

1;
