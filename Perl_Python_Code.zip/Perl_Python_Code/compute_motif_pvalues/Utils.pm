########################################################################################
## This package contains simple functions whose aim is the treatment of strings to    ##
## reduce the complexity of the code lines.                                           ##
##                                                                                    ##
## Laboratory of Functional Analysis in silico                                        ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo         ##
## Programmed by Yosvany Lopez Alvarez                                 November, 2011 ##
########################################################################################     

package Utils;

use warnings;
use strict;

## This function receives a sequence and returns a new one without whitespaces in both extremes.

sub Trim {

    my ($Sequence) = @_;

    $Sequence =~ s/^\s+//;
    $Sequence =~ s/\s+$//;
   
    return ($Sequence)
}

## This function receives a sequence as parameter and returns this one in upper case.

sub upperCase {

    my ($Sequence) = @_;

    $Sequence =~ tr/a-z/A-Z/;

    return ($Sequence);
}

## This function ....

sub GetRandomGenes {

    my ($amount, %gene_hash) = @_;

    my @indices = keys(%gene_hash);

    my %random_genes = ();
    my %random_indices = ();

    my $length = 0;

    do {
        my $random_number = int(rand(scalar(@indices)));

	$random_indices{$indices[$random_number]} = 1;
	
	$random_genes{$gene_hash{$indices[$random_number]}} = 1;

        $length = scalar(keys(%random_genes));
    }
    until($length == $amount);

    my @auxiliar = keys(%random_indices);

    return (\@auxiliar, keys(%random_genes))
}

## This function ...

sub intersections {

    my ($ref_random_indices, $ref_random_genes, $ref_motif_pattern, $ref_motif_gene, %motif_set) = @_;

    my @random_indices = @{$ref_random_indices};
    my @random_genes = @{$ref_random_genes};
    my %motif_pattern = %{$ref_motif_pattern};
    my %motif_gene = %{$ref_motif_gene};

    my %subset_info = ();

    my @motifs = keys(%motif_set);

    foreach (@motifs) {

        my @hits = @{$motif_pattern{$_}};
        my @genes = @{$motif_gene{$_}};

        my $total_hits = 0;
        foreach (@random_indices) { $total_hits = $total_hits + $hits[$_] }
	
        my %random_gene_hash = map {$_ => 1} @random_genes;
        my %gene_hash = map {$_ => 1} @genes;

        my @intersection = grep { exists $random_gene_hash{$_} } keys %gene_hash;

	my @info = ();
	push(@info, scalar(@random_indices));   ## number of genes 
	push(@info, $total_hits);               ## number of motifs
	push(@info, scalar(@intersection));     ## number of genes that have at least one motif
	
	$subset_info{$_} = \@info
    }

    return (%subset_info)
}

## This function ...
                                                                                                                                                                          
sub integrate_ori_values {

    my ($ref_new_values, %current_values) = @_;

    my %new_values = %{$ref_new_values};

    my @motifs = keys(%current_values);

    foreach(@motifs) {
        my @values = @{$current_values{$_}};
	push(@values, $new_values{$_});
        $current_values{$_} = \@values
    }

    return (%current_values)
}

## This function ...

sub whole_integration {

    my ($ref_new_values, %current_values) = @_;

    my %new_values = %{$ref_new_values};

    my @motifs = keys(%current_values);

    foreach(@motifs) { 
	my @merger = (@{$current_values{$_}}, @{$new_values{$_}});
	$current_values{$_} = \@merger
    }

    return (%current_values)
}

## This function ...

sub calculate_pvalue {

    my ($value, @list) = @_;

    my $counter = 0;

    foreach (@list) { if ($_ > $value) { $counter++ } }

    my $pvalue = $counter / scalar(@list);

    return ($pvalue)
}

## This function ...

sub renumerate_motifs {

    my ($ref_thresholds, $ref_matrices, %pvalues) = @_;

    my %thresholds = %{$ref_thresholds};
    my %matrices = %{$ref_matrices};

    my @motifs = keys(%pvalues);

    my %new_threshold = ();
    my %new_matrix = ();
    my %new_pvalue = ();
    
    my $index = 1;
    my $nindex = '';

    foreach (@motifs) {
        if ($_ =~ /^M/) { $nindex = $_ }
	else {
	    my @parts = split('_', $_);
            $nindex = $parts[0] . '_' . $index;
            $index++;
         }

	print ($_ . "\t" . $nindex);
	print "\n";

	$new_threshold{$nindex} = $thresholds{$_};
	$new_matrix{$nindex} = $matrices{$_};
	$new_pvalue{$nindex} = $pvalues{$_} 
    }

    return (\%new_threshold, \%new_matrix, %new_pvalue)
}

1;
