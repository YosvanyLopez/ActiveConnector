##########################################################################################
## Laboratory of Functional Analysis in silico                                          ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo           ##
## Programmed by Yosvany Lopez Alvarez                                   November, 2014 ##
##########################################################################################

#!/usr/local/bin/perl

use warnings;
use strict;
use File;
use region_collection;

##########################################################################################

my $tfbs_file = ''; ## TFBS of all the promoters (this is to save time during the calculation of random ORIs)

my $motif_file = ''; ## motif matrices 

my $storage_file = ''; ## information related to motifs in promoter regions

##########################################################################################

my $file_object = new File (); 
my %tfbs = $file_object -> recover_variable($tfbs_file);

my %motif_set = $file_object -> recover_variable($motif_file);

my $region_set_object = new region_collection();
my ($ref_ref_gene, %pattern_per_region) = $region_set_object -> update_region_collection(%tfbs);
my ($ref_pattern_per_region, %region_with_pattern) = $region_set_object -> pattern_collection_info($ref_ref_gene, \%pattern_per_region, %motif_set);

my %storage_variable = ();
$storage_variable{'0'} = $ref_ref_gene;
$storage_variable{'1'} = $ref_pattern_per_region;
$storage_variable{'2'} = \%region_with_pattern;

$file_object -> save_variable($storage_file, %storage_variable)

################################################################################################
