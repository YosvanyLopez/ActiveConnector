#$ -cwd -S /bin/bash
#$ -l s_vmem=16G -l mem_req=16

set -xue

perl compute_pvalues.pl <file_number> <stage_number>

echo done