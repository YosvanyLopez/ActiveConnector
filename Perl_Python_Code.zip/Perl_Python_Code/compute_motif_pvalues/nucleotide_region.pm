#########################################################################################
## Laboratory of Functional Analysis in silico                                         ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo          ##
## Programmed by Yosvany Lopez Alvarez                                  February, 2011 ##
#########################################################################################

package nucleotide_region;

use strict;
use warnings;
use Utils;
use gene;
use chromosome;

## This function stands for this class' constructor.

sub new {

    my $self = {};

    bless($self);
       
    return ($self);
}

## This function receives four parameters: (1) the gene identifier, (2) and (3) the lengths of 
## the upstream and downstream regions to be extracted, and (4) a hash containing the karyotype
## whose "keys" and "values" are the chromosome identifier and instances of the "Chromosome" 
## class, respectively. Thereafter, two values: (1) a line with the gene information and 
## (2) the desired promoter region are returned.

sub promoter_regions {

    my ($self, $GeneID, $Upstream, $Downstream, %Karyotype) = @_;

    my $PromoterRegion = '';

    my @Information = $self -> gene_info($GeneID, %Karyotype);

    if (scalar(@Information) != 0) {

	my $Chromosome = $Information[0];
	my $InitialPos = $Information[2];
	my $FinalPos = $Information[3];
	my $Orientation = $Information[4];

	my $DNASequence = $Karyotype{$Chromosome} -> getSequence ();

	my ($UpstreamR, $DownstreamR, $NewInitial, $NewFinal); 
	
	if ($Orientation eq "+") {
	    $UpstreamR = substr ($DNASequence, ($InitialPos - $Upstream), $Upstream);
	    $DownstreamR = substr($DNASequence, $InitialPos, $Downstream);
	    $PromoterRegion = $UpstreamR . $DownstreamR;

	    $NewInitial = $InitialPos - $Upstream + 1;
	    $NewFinal = $InitialPos + $Downstream

	} elsif ($Orientation eq "-") {

	    $DNASequence = Utils::GetComplementSequence($DNASequence);
	    
	    $UpstreamR = substr ($DNASequence, $FinalPos - 1, $Upstream);
	    $DownstreamR = substr ($DNASequence, ($FinalPos - $Downstream) - 1, $Downstream);
	    $PromoterRegion = $DownstreamR . $UpstreamR;

	    $PromoterRegion = reverse($PromoterRegion);

	    $NewInitial = $FinalPos - $Downstream;
	    $NewFinal = $FinalPos + $Upstream - 1;
	}

	$Information[2] = $NewInitial;
	$Information[3] = $NewFinal;
	
    } else {
	print $GeneID;
	print "\n";
}
    
    return ($PromoterRegion)
}

## This function ....

sub gene_info {

    my ($self, $GeneID, %Karyotype) = @_;

    my @Chromosomes = keys(%Karyotype);

    my @Information = ();    

    foreach my $Chr (@Chromosomes) {

	my %Genes = $Karyotype{$Chr} -> getGeneHash();
	
	if (exists $Genes{$GeneID}) {

	    push(@Information, $Chr);
	    push(@Information, $GeneID);
		
	    my $InitialPos = $Genes{$GeneID} -> getInitialPosition();
	    push(@Information, $InitialPos);
	    my $FinalPos = $Genes{$GeneID} -> getFinalPosition();
	    push(@Information, $FinalPos);
	    my $Direction = $Genes{$GeneID} -> getDirection();
	    push(@Information, $Direction)
	}
    }
    
    return (@Information)
}

## This function ....

sub promoter_region_per_gene {

    my ($self, $Upstream, $Downstream, $ref_Genes, %Karyotype) = @_;

    my @Genes = @{$ref_Genes};

    my %PromoterRegions = ();
    
    my $i = 0;
    while ($i <= scalar(@Genes) - 1) {
	my ($PromoterRegion) = $self -> promoter_regions($Genes[$i], $Upstream, $Downstream, %Karyotype);
	if ($PromoterRegion ne '') { $PromoterRegions{$Genes[$i]} = $PromoterRegion }
	$i++
    }
    
    return (%PromoterRegions)
}

## This function ...

sub nonpromoter_regions {

    my ($self, $geneID, $lowerLimit, $upperLimit, %karyotype) = @_;

    my ($nonPromoterRegion, $newInitial, $newFinal);

    my @information = $self -> gene_info($geneID, %karyotype);

    my $chromosome = $information[0];
    my $initialPos = $information[2];
    my $finalPos = $information[3];
    my $orientation = $information[4];
    
    my $DNASequence = $karyotype{$chromosome} -> getSequence();

    if ($orientation eq "+") {
	    
	$nonPromoterRegion = substr($DNASequence, ($initialPos + $lowerLimit - 1), ($upperLimit - $lowerLimit));
	
	$newInitial = $initialPos + $lowerLimit;
	$newFinal = $initialPos + $upperLimit - 1; 
	    
    } elsif ($orientation eq "-") {

	$nonPromoterRegion = substr($DNASequence, ($finalPos - $upperLimit), ($upperLimit - $lowerLimit));
	
	$nonPromoterRegion = reverse(Utils::GetComplementSequence($nonPromoterRegion));
	
	$newInitial = $finalPos - ($upperLimit - 1);
	$newFinal = $finalPos - $lowerLimit;
    }

    $information[2] = $newInitial;
    $information[3] = $newFinal;

    return ($nonPromoterRegion)
}

## This function ...

sub nonpromoter_region_per_gene {

    my ($self, $lowerLimit, $upperLimit, $ref_genes, %karyotype) = @_;

    my @genes = @{$ref_genes};

    my %nonPromoters = ();
    
    my $i = 0;
    while ($i <= scalar(@genes) - 1) {

	my $nonPromoter = $self -> nonpromoter_regions($genes[$i], $lowerLimit, $upperLimit, %karyotype);
	
	if ($nonPromoter ne '') { $nonPromoters{$genes[$i]} = $nonPromoter }
	$i++
    }
    
    return (%nonPromoters)
}

1;
