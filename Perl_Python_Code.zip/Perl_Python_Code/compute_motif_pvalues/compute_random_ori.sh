#$ -cwd -S /bin/bash

set -xue

perl compute_random_ori.pl <stage_number>

echo done
