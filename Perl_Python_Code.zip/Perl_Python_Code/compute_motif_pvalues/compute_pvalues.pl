##########################################################################################
## Laboratory of Functional Analysis in silico                                          ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo           ##
## Programmed by Yosvany Lopez Alvarez                                   November, 2014 ##
##########################################################################################

#!/usr/local/bin/perl

use warnings;
use strict;
use File;

##########################################################################################

my $random_ori_file = './stage_' . $ARGV[1] . '/motif_prediction/compute_pvalues/random_ori/random_';

my $motif_file = './stage_' . $ARGV[1] . '/motif_prediction/motif_threshold/pfmatrices.info';

my $threshold_file = './stage_' . $ARGV[1] . '/motif_prediction/motif_threshold/thresholds.info';

my $cvariable_file = './stage_' . $ARGV[1] . '/motif_prediction/compute_pvalues/complex_variable.info';

my $nmotif_file = './stage_' . $ARGV[1] . '/threshold/best_motifs.txt';

my $JASPAR_file = './stage_' . $ARGV[1] . '/threshold/formatted_motifs.txt';

my $nthreshold_file = './stage_' . $ARGV[1] . '/threshold/thresholds.info';

##########################################################################################

my $file_object = new File(); 

my %motifs = $file_object -> recover_variable($motif_file);
my %thresholds = $file_object -> recover_variable($threshold_file);

my @empty = ();
my %random_ori_values = map { $_ => \@empty } keys(%motifs);

for (my $i = 1; $i <= $ARGV[0]; $i++) { ## number of files with random ORIs = 5 files of 200000 values

    my $file_name = $random_ori_file . $i . '.info';

    print $file_name;
    print "\n";

    my %auxiliar_ori = $file_object -> recover_variable($file_name);
    %random_ori_values = Utils::whole_integration(\%auxiliar_ori, %random_ori_values)
}

foreach (keys(%random_ori_values)) {
    print ($_ . "\t" . scalar(@{$random_ori_values{$_}}));
    print "\n"
}

my %storage_variable = $file_object -> recover_variable($cvariable_file);
my %original_ori = %{$storage_variable{'2'}};

my %pvalues = ();

foreach (keys(%motifs)) {
    
    my $pvalue = Utils::calculate_pvalue($original_ori{$_}, @{$random_ori_values{$_}});

    if ($pvalue < 0.01) { $pvalues{$_} = $pvalue }
}

my ($ref_nthreshold, $ref_nmotif, %npvalues) = Utils::renumerate_motifs(\%thresholds, \%motifs, %pvalues);    

my %nthreshold = %{$ref_nthreshold};
my %nmotif = %{$ref_nmotif};

$file_object -> save_variable($nthreshold_file, %nthreshold);
$file_object -> WriterOfAll($nmotif_file, %nmotif);
$file_object -> JASPARFormatWriter($JASPAR_file, %nmotif);

foreach (keys(%npvalues)) {
    print ($_ . "\t" . $npvalues{$_});
    print "\n"
}

################################################################################################
