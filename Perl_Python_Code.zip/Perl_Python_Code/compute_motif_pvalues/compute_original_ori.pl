##########################################################################################
## Laboratory of Functional Analysis in silico                                          ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo           ##
## Programmed by Yosvany Lopez Alvarez                                   November, 2014 ##
##########################################################################################

#!/usr/local/bin/perl

use warnings;
use strict;
use File;
use ORICalculator;

##########################################################################################

my $motif_prediction_file = './stage_' . $ARGV[0] . '/initial_sets/motif_prediction.txt';

my $feature_generation_file = './stage_' . $ARGV[0] . '/initial_sets/feature_generation.txt';

my $model_build_file = './stage_' . $ARGV[0] . '/initial_sets/model_build.txt';

my $storage_promoter_file = './stage_' . $ARGV[0] . '/motif_prediction/compute_pvalues/storage_promoters.info';

my $storage_nonpromoter_file = './stage_' . $ARGV[0] . '/motif_prediction/compute_pvalues/storage_nonpromoters.info';

my $motif_file = './stage_' . $ARGV[0] . '/motif_prediction/motif_threshold/pfmatrices.info';

my $original_info_file = './stage_' . $ARGV[0] . '/motif_prediction/compute_pvalues/complex_variable.info';

##########################################################################################

my $file_object = new File (); 
my @motif_prediction = $file_object -> gene_file_reader($motif_prediction_file);
my @feature_generation = $file_object -> gene_file_reader($feature_generation_file);
my @initial_gene_set = (@motif_prediction, @feature_generation);

my @model_build = $file_object -> gene_file_reader($model_build_file);
@initial_gene_set = (@initial_gene_set, @model_build);

my %storage_promoter = $file_object -> recover_variable($storage_promoter_file);
my %storage_nonpromoter = $file_object -> recover_variable($storage_nonpromoter_file);

my %ref_promoter = %{$storage_promoter{'0'}};
my %motif_pattern_promoter = %{$storage_promoter{'1'}};
my %motif_gene_promoter = %{$storage_promoter{'2'}};

my %ref_nonpromoter = %{$storage_nonpromoter{'0'}};
my %motif_pattern_nonpromoter = %{$storage_nonpromoter{'1'}};
my %motif_gene_nonpromoter = %{$storage_nonpromoter{'2'}};

my %motif_set = $file_object -> recover_variable($motif_file);

%ref_promoter = reverse %ref_promoter;
my @positive_indices = ();
foreach (@motif_prediction) { push(@positive_indices, $ref_promoter{$_}) }

my %auxiliar_nonpromoter = reverse %ref_nonpromoter;

foreach (@initial_gene_set) {
    delete $ref_promoter{$_};
    delete $auxiliar_nonpromoter{$_}
}

%ref_nonpromoter = reverse %auxiliar_nonpromoter;
 
my %positive_info = Utils::intersections(\@positive_indices, \@motif_prediction, \%motif_pattern_promoter, \%motif_gene_promoter, %motif_set);

my ($ref_random_indices, @random_genes) = Utils::GetRandomGenes((scalar(@motif_prediction) * 10), %ref_nonpromoter);

my %control_info = Utils::intersections($ref_random_indices, \@random_genes, \%motif_pattern_nonpromoter, \%motif_gene_nonpromoter, %motif_set);

my $ori_object = new ORICalculator();
my %ori_values = $ori_object -> compute_ori(2000, \%positive_info, %control_info); ## length of promoter region = 2000 bp

my %storage_variable = ();
$storage_variable{'0'} = \%ref_promoter;   ## information of promoter regions without initial set genes 
$storage_variable{'1'} = \%control_info;   ## information of control sample
$storage_variable{'2'} = \%ori_values;     ## original ori values

$file_object -> save_variable($original_info_file, %storage_variable)

################################################################################################
