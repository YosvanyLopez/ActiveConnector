##############################################################################################
## This package contains the class "File", which groups those functions related to the      ##
## reading and writing of information from/into external data files.                        ##
##                                                                                          ##
## Laboratory of Functional Analysis in silico                                              ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo               ##
## Programmed by Yosvany Lopez Alvarez                                       November, 2011 ##
##############################################################################################

package File;

use warnings;
use strict;
use Utils;
use Storable;
use Storable qw(dclone);

## This function stands for the class' constructor.

sub new {

    my $self = {};

    bless($self);
       
    return ($self);
}

## This function ....                                                                                                                                                     
                                                                                    
sub recover_variable {

    my ($self, $file_name) = @_;

    my $ref_hash = retrieve($file_name);

    return (%{$ref_hash})
}

## This function ...
                                                                                                                                                                   
sub gene_file_reader {

    my ($self, $file_name) = @_;

    open(IN, $file_name);
    my @lines = <IN>;
    my @genes = split("\t", Utils::Trim(Utils::upperCase($lines[0])));
    close(IN);

    return (@genes)
}

## This function ...

sub save_variable {

    my ($self, $file_name, %data) = @_;

    store(\%data, $file_name)
}

## This function ...

sub PositionMatrixWriter {

    my ($self, $FileHandler, $Index, %PositionMatrix) = @_;

    print($FileHandler $Index);
    print($FileHandler "\n");
    print($FileHandler "<BEGIN>");
    print($FileHandler "\n");

    my @NucleotideList = sort(keys(%PositionMatrix));

    foreach my $Nucleotide (@NucleotideList) {

        my @ReversedRow = reverse(@{$PositionMatrix{$Nucleotide}});
        push(@ReversedRow, $Nucleotide);
        my $Sequence = join("\t", reverse(@ReversedRow));

        print ($FileHandler $Sequence);
        print ($FileHandler "\n");
    }

    print ($FileHandler "<END>");
    print ($FileHandler "\n");
    print ($FileHandler "\n");
}

## This function ...

sub WriterOfAll {

    my ($self, $OutputFile, %PatternData) = @_;

    my $Output;
    open($Output, ">$OutputFile");

    print ($Output '****** MOTIFS *******' . "\n");
    print ($Output "\n");

    my @PatternIdentifiers = sort(keys(%PatternData));

    foreach my $PatternIdentifier (@PatternIdentifiers) {
	$self -> PositionMatrixWriter($Output, $PatternIdentifier, %{$PatternData{$PatternIdentifier}});
    }

    close ($Output)
}

## This function ...

sub JASPARFormatWriter {

    my ($self, $OutputFile, %PFMatrices) = @_;

    open(OUTPUT, ">$OutputFile");

    my @Motifs = sort(keys(%PFMatrices));

    my $MotifID = 1;

    foreach my $Motif (@Motifs) {

        my %PositionMatrix = %{$PFMatrices{$Motif}};

        print (OUTPUT ">" . $Motif);
        print (OUTPUT "\n");

        my @NucleotideList = sort(keys(%PositionMatrix));

        foreach my $Nucleotide (@NucleotideList) {

            my @ReversedRow = reverse(@{$PositionMatrix{$Nucleotide}});
            push(@ReversedRow, "[", $Nucleotide);
            @ReversedRow = reverse(@ReversedRow);
            push(@ReversedRow, "]");
            my $Sequence = join(" ", @ReversedRow);

            print (OUTPUT $Sequence);
            print (OUTPUT "\n");
        }

        $MotifID++
    }

    close (OUTPUT)
}

1;
