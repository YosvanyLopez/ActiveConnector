##########################################################################################                                                                               
## Laboratory of Functional Analysis in silico                                          ##                                                                         
## Human Genome Center, Institute of Medical Science, The University of Tokyo           ##                                                                                
## Programmed by Yosvany Lopez Alvarez                                   November, 2014 ##                                                                                
##########################################################################################                                                                                

#!/usr/local/bin/perl                                                                                                                                                     

use warnings;
use strict;
use File;
use ORICalculator;

##########################################################################################                                                                           

my $storage_variable_file = './stage_' . $ARGV[0] . '/motif_prediction/compute_pvalues/complex_variable.info';

my $storage_promoter_file = './stage_' . $ARGV[0] . '/motif_prediction/compute_pvalues/storage_promoters.info';

my $motif_file = './stage_' . $ARGV[0] . '/motif_prediction/motif_threshold/pfmatrices.info';

my $random_ori_file = './stage_' . $ARGV[0] . '/motif_prediction/compute_pvalues/random_ori/random_' . $ARGV[1] . '.info';

##########################################################################################                                                                                
                     
my $file_object = new File ();
my %complex_variable = $file_object -> recover_variable($storage_variable_file);

my %ref_promoter = %{$complex_variable{'0'}};
my %control_info = %{$complex_variable{'1'}};

my %motif_set = $file_object -> recover_variable($motif_file);

my %storage_promoter = $file_object -> recover_variable($storage_promoter_file);
my %motif_pattern_promoter = %{$storage_promoter{'1'}};
my %motif_gene_promoter = %{$storage_promoter{'2'}};

my @empty = ();
my %ori_values = map { $_ => \@empty } keys(%motif_set);

%ref_promoter = reverse %ref_promoter;

for (my $i = 0; $i < 20000; $i++) { ## number of iterations
    
    my ($ref_index_list, @gene_list) = Utils::GetRandomGenes(48, %ref_promoter);     ## number of genes in the motif prediction set    
                                                                                                                                       
    my %auxiliar_info = Utils::intersections($ref_index_list, \@gene_list, \%motif_pattern_promoter, \%motif_gene_promoter, %motif_set);

    my $ori_object = new ORICalculator();
    my %auxiliar_ori = $ori_object -> compute_ori(2000, \%auxiliar_info, %control_info); ## length of promoter region = 2000bp                                           
                                                                                               
    %ori_values = Utils::integrate_ori_values(\%auxiliar_ori, %ori_values);
}

$file_object -> save_variable($random_ori_file, %ori_values)

################################################################################################
