##########################################################################################
## This package contains the class "ORICalculator", which groups those methods focused  ##
## on computing the Over-Representation Indices(ORIs) of different patterns (discovered ##
## motifs).                                                                             ## 
##                                                                                      ## 
## Laboratory of Functional Analysis in silico                                          ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo           ##
## Programmed by Yosvany Lopez Alvarez                                   November, 2011 ##
##########################################################################################

package ORICalculator;

use warnings;
use strict;

## This function represents the class' constructor.

sub new {

    my $self = {};

    bless($self);
    
    return ($self)
}


## This function receives two parameters: (1) number of DNA regions where a specific 
## pattern is found, and (2) total number of DNA regions. Thereafter, the proportion 
## is computed and returned.

sub ComputeProportion {

    my ($self, $RegionWithPattern, $DNARegionAmount) = @_;

    my $Proportion =  ($RegionWithPattern / $DNARegionAmount);

    return ($Proportion)
}


## This function receives two parameters: (1) number of times a pattern appears within  
## DNA regions, and (2) total length of DNA regions. Afterwards, the density is computed 
## and returned.

sub ComputeDensity {

    my ($self, $PatternAmount, $TotalLength) = @_;

    my $Density = ($PatternAmount / $TotalLength);  

    return ($Density)
}

## This function receives four parameters: (1) length of a DNA region, (2) & (3) references 
## to two different hashes (DNA regions within promoter and non-promoter sets, respectively)
## whose "keys" and "values" are names of genes as well as lists composed of their Transcription
## Factor Binding Sites (TFBSs), and (4) another hash whose "keys" and "values" are pattern's 
## identifiers and Position Frequency Matrices (PFMs). Finally, it returns a hash whose "keys"
## and "values" are pattern's identifiers along with computed ORIs. 

sub compute_ori {

    my ($self, $region_length, $ref_promoter_info, %nonpromoter_info) = @_;

    my %promoter_info = %{$ref_promoter_info};
   
    my @motifs = keys(%promoter_info);

    my %ori_values = ();

    foreach (@motifs) {

	my @promoter_list = @{$promoter_info{$_}};

	my @nonpromoter_list = @{$nonpromoter_info{$_}};

	my $total_promoter_length = $promoter_list[0] * $region_length;
	my $promoter_density = $self -> ComputeDensity($promoter_list[1], $total_promoter_length);
	my $promoter_proportion = $self -> ComputeProportion($promoter_list[2], $promoter_list[0]); 

	my $total_nonpromoter_length = $nonpromoter_list[0] * $region_length; 
	my $nonpromoter_density = $self -> ComputeDensity($nonpromoter_list[1], $total_nonpromoter_length);
	my $nonpromoter_proportion = $self -> ComputeProportion($nonpromoter_list[2], $nonpromoter_list[0]);

	if (($nonpromoter_density == 0) || ($nonpromoter_proportion == 0)) { $ori_values{$_} = 0 }
	else {

	    my $ori = ($promoter_density * $promoter_proportion) / ($nonpromoter_density * $nonpromoter_proportion);
	    $ori = sprintf("%.3f", $ori);

	    $ori_values{$_} = $ori	
	}
    }

    return (%ori_values)
}

1;
