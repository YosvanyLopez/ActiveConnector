########################################################################################
## This package contains simple mathematical functions to compute matricial values,   ##
## and so to reduce the complexity of the code lines.                                 ##
##                                                                                    ##
## Laboratory of Functional Analysis in silico                                        ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo         ##
## Programmed by Yosvany Lopez Alvarez                                 November, 2011 ##
########################################################################################  

package Math;

use warnings;
use strict;

## This function receives two parameters: (1) an integer value, and (2) a numeric list.
## Consequently, it returns the reference to a list composed of the respective likelihoods 
## of each item within the initial array.

sub ComputeLogOddRatio {

    my ($Value, @List) = @_;

    my @LogOddRatios = ();

    foreach my $Item (@List) {
	
	my $Numerator = $Item + ($Value ** 0.5); 
	my $Denominator = 1/($Value + 4 * ($Value ** 0.5));	
        my $LogOddValue = sprintf("%.3f", log2(($Numerator * $Denominator)/0.25));

	push (@LogOddRatios, $LogOddValue);
    }

    return (\@LogOddRatios)
}


## This function receives two parameters: (1) an integer value, and (2) a hash whose "keys" and 
## "values" are the four DNA nucleotides ('A' - 'C' - 'G' - 'T') as well as their position frequency
## values. Thereafter, a similar hash whose "keys" are also the aforementioned nucleotides, but whose
## "values" are the position weight values ("log odd ratios") is returned.

sub ComputeLogOddRatioMatrix {

    my ($Value, %FrequencyMatrix) = @_;

    my %WeightMatrix = ();

    my @Nucleotides = keys(%FrequencyMatrix);

    foreach my $Nucleotide (@Nucleotides) {	

	$WeightMatrix{$Nucleotide} = ComputeLogOddRatio($Value, @{$FrequencyMatrix{$Nucleotide}});
    }
    
    return (%WeightMatrix)
}

## This function receives a number and returns its 2-base logarithm.                                                                                                   

sub log2 {

    my ($N) = @_;

    my $Log2 = log($N)/log(2);

   return ($Log2)
}

1;
