##########################################################################################
## This package contains the class "TranscriptionFactor" that comprises the properties  ##
## of one specific Transcription Factor (TF) such as its identifier, Position Frequency ##
## Matrix (PFM) and Position Weight Matrix (PWM). Additionally, it carries out other    ##
## functions related to the scanning of promoters for detecting potential Binding Sites ##
## (BSs).                                                                               ## 
##                                                                                      ## 
## Laboratory of Functional Analysis in silico                                          ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo           ##
## Programmed by Yosvany Lopez Alvarez                                   November, 2011 ##
##########################################################################################

package TranscriptionFactor;

use warnings;
use strict;
use Utils;
use Math;

## This function stands for the class' constructor. It has three attributes related to a 
## TF: (1) name or identifier, (2) PFM, and (3) PWM. Then, each created instance will be 
## composed of these fields. 

sub new {

    my $self = {};

    $self -> {NAME} = undef;    
    $self -> {FREQUENCYMATRIX} = undef;
    $self -> {WEIGHTMATRIX} = undef;
    bless($self);
       
    return ($self)
}


## This function receives a TF's name, and accordingly updates the attribute "NAME".

sub setName {

    my ($self, $Name) = @_;

    $self -> {NAME} = $Name
}


## This function returns the value stored in the attribute "NAME".

sub getName {

    my ($self) = @_;

    return ($self -> {NAME})
}


## This function receives two parameters: (1) a TF's name, and (2) a matrix. Afterwards,
## the attribute "FREQUENCYMATRIX" is updated, whereas the number of sites is returned.

sub setFrequencyMatrix {

    my ($self, $Name, @Matrix) = @_;

    $self -> setName($Name);

    my $SiteNumber = 0;

    my $i = 0;
    while ($i <= scalar(@Matrix) - 1) {

	my @Items = Utils::SplitString('\t', $Matrix[$i]);

	my $FirstItem = shift(@Items);

	${$self -> {FREQUENCYMATRIX}}{$FirstItem} = \@Items;

	$SiteNumber += ${$self -> {FREQUENCYMATRIX}}{$FirstItem}[0];

	$i++;
    }

    return ($SiteNumber)
}


## This function returns the PFM stored in the attribute "FREQUENCYMATRIX".

sub getFrequencyMatrix {

    my ($self) = @_;

    return (%{$self -> {FREQUENCYMATRIX}})
}


## This function receives a number of sites. Then, after computing the log-odd values the
## attribute "WEIGHTMATRIX" is updated.

sub setWeightMatrix {

    my ($self, $SiteNumber) = @_;

    %{$self -> {WEIGHTMATRIX}} = Math::ComputeLogOddRatioMatrix($SiteNumber, $self -> getFrequencyMatrix());
}


## This function returns the PWM stored in the attribute "WEIGHTMATRIX".

sub getWeightMatrix {

    my ($self) = @_;	

    return (%{$self -> {WEIGHTMATRIX}})
}


## This function receives two parameters: (1) a binding site, and (2) a PWM. Soon after, the 
## scoring of such a site is computed and duly returned.

sub ComputeBindingSiteScore {

    my ($self, $TFBS, %WeightMatrix) = @_;	

    my $Score = 0;

    my $i = 0;
    while ($i <= length($TFBS) - 1) {
	
	$Score += ${$WeightMatrix{substr($TFBS, $i, 1)}}[$i];
	
	$i++;
    }

    return ($Score)    
}


## This function receives four parameters: (1) a nucleotide sequence, (2) a direction (orientation
## of the sequence being scanned), (3) a threshold, and (4) a PWM. Afterwards, such a sequence is 
## scanned for BSs whose scores are greater than the cutoff previously mentioned, and then a list 
## composed of each discovered BS' information is returned.

sub ScanWithoutOrientation {
    
    my ($self, $Sequence, $orientation, $threshold, %WeightMatrix) = @_;

    my @PutativeSiteInfo = ();

    my $ProfileLength = scalar(@{$WeightMatrix{'A'}});

    my $TFName = $self -> getName();

    my $i = 0;
    while ($i <= (length($Sequence) - $ProfileLength)) {
	
	my $PutativeSite = substr($Sequence, $i, $ProfileLength);

	if (index($PutativeSite, 'N') == -1) {

	    my $Score = $self -> ComputeBindingSiteScore($PutativeSite, %WeightMatrix);

	    if ($Score >= $threshold) {
		my $SiteInfo = $TFName . "\t" . $i . "\t" . $PutativeSite . "\t" . $orientation . "\t" . $Score;
		push (@PutativeSiteInfo, $SiteInfo);
	    }
	}

	$i++
    }
    
    return (@PutativeSiteInfo)
}


## This function receives two parameters: (1) a sequence, and (2) a threshold. Thereafter, both strands of 
## the sequence are scanned to find out potential TFBSs. Those sites successfully found are inserted into
## a list, which is finally returned.

sub ScanProfile {

    my ($self, $Sequence, $threshold) = @_;

    my %WeightMatrix = $self -> getWeightMatrix();

    my @PutativeSites = ();

    push (@PutativeSites, $self -> ScanWithoutOrientation($Sequence, '+', $threshold, %WeightMatrix));

    my $ComplementSequence = Utils::GetComplementSequence($Sequence);

    push (@PutativeSites, $self -> ScanWithoutOrientation($ComplementSequence, '-', $threshold, %WeightMatrix));

    return (@PutativeSites)
}

1;
