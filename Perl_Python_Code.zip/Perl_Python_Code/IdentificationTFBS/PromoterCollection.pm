#########################################################################################
## This package contains the class "PromoterCollection", which collects those          ##
## promoters under analysis. In addition, it updates their data and conducts the       ##
## search for the presence of putative Transcription Factors Binding Sites (TFBSs)     ##
## within each regulatory region.                                                      ## 
##                                                                                     ## 
## Laboratory of Functional Analysis in silico                                         ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo          ##
## Programmed by Yosvany Lopez Alvarez                                  November, 2011 ##
#########################################################################################

package PromoterCollection; 

use warnings;
use strict;
use Promoter;

## This function represents the class' constructor. It contains an attribute that is  
## a hash whose "keys" and "values" are integer indices as well as instances from the
## class "Promoter". Each new object will have this collection of regulatory regions.

sub new {

    my $self = {};

    %{$self -> {PROMOTERS}} = ();

    bless($self);
    
    return ($self);
}


## This function receives two parameters: (1) an integer index, and (2) an object "Promoter". 
## Then, such an instance is inserted into the promoter list, updating the attribute "PROMOTERS".

sub setPromoterObject {

    my ($self, $Index, $PromoterObject) = @_;

    ${$self -> {PROMOTERS}}{$Index} = $PromoterObject;
}


## This function returns the promoter list stored in the attribute "PROMOTERS".

sub getPromoters {

    my ($self) = @_;

    return (%{$self -> {PROMOTERS}})
}


## This function receives two parameters: (1) the reference to a hash whose "keys" and "values"
## are integer indices and gene names, and (2) a hash whose "keys" are also integer indices, but 
## whose "values" are promoter sequences, respectively. Consequently, each "Promoter" object is 
## created and inserted into the promoter collection.

sub UpdatePromoterList {

    my ($self, $ref_GeneNames, %PromoterSequences) = @_;

    my %GeneNames = %{$ref_GeneNames};

    my @PromoterIndices = keys(%GeneNames);

    foreach my $PromoterIndex (@PromoterIndices) {

	my $PromoterObject = new Promoter();
	$PromoterObject -> setGeneName($GeneNames{$PromoterIndex});
	$PromoterObject -> setSequence($PromoterSequences{$PromoterIndex});

	$self -> setPromoterObject($PromoterIndex, $PromoterObject);
    }
}


## This function receives two parameters: (1) a threshold, and (2) an object "TFCollection".
## Afterwards, each promoter is scanned and those TFBSs whose scores are greater than the 
## previous cutoff are chosen and returned within another hash whose "keys" and "values" are
## the name of gene each regulatory region belongs to as well as the discovered TFBSs.

sub ScanPromotersForTFBS {

    my ($self, $TFObject, %thresholds) = @_;

    my %PromoterObjects = $self -> getPromoters();
    
    my @PromoterIndices = keys(%PromoterObjects);

    my %TFBSPerPromoter = ();

    foreach my $PromoterIndex (@PromoterIndices) {
	
	my $GeneName = $PromoterObjects{$PromoterIndex} -> getGeneName();

	$TFBSPerPromoter{$GeneName} = $PromoterObjects{$PromoterIndex} -> DetectTFBSs($TFObject, %thresholds);
    }
    
    return (%TFBSPerPromoter);
}


1;
