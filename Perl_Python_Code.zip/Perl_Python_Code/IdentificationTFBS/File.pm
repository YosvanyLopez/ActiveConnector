##############################################################################################
## This package contains the class "File", which groups those functions related to the      ##
## reading and writing of information from/into external data files.                        ##
##                                                                                          ##
## Laboratory of Functional Analysis in silico                                              ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo               ##
## Programmed by Yosvany Lopez Alvarez                                       November, 2011 ##
##############################################################################################

package File;

use warnings;
use strict;
use Utils;
use Storable;
use Storable qw(dclone);

## This function stands for the class' constructor.

sub new {

    my $self = {};

    bless($self);
       
    return ($self);
}


## This function receives the name of a file containing all the Transcription Factors (TFs) be
## used for scanning the promoter regions. Lastly, it returns a hash whose "keys" and "values" 
## are integer indices and string lists composed of each TF's Position Frequency Matrix (PFM).

sub TFFileReader {

    my ($self, $FileName) = @_;

    my $Line = '';

    my @Rows;
    my %FrequencyMatrices = ();    
    my $Flag = 0;
    my $motif_identifier;

    open(INPUT, $FileName);

    while ($Line = <INPUT>) {

	$Line = Utils::Trim($Line);

	if (($Line =~ /^M/) || ($Line =~ /^D/)) {

	    $motif_identifier = $Line;
	}

	if ($Line =~ m/<BEGIN>/) {
	    $Flag = 1;
	    @Rows = ();
	} elsif ($Line =~ m/<END>/) {
	    $Flag = 0;
	    $FrequencyMatrices{$motif_identifier} = dclone(\@Rows);
	} elsif ($Flag) {
	    push (@Rows, Utils::Trim($Line));
	}
    }

    close(INPUT);	

    return (%FrequencyMatrices)
}


## This function receives the name of a file containing all the promoter sequences to be scanned 
## in FASTA format. Thereafter, it returns two parameters: (1) the reference to a list comprising 
## the file lines, and (2) a list composed of the indices of each FASTA sequence's header within
## the line list.

sub PromoterFileReader {

    my ($self, $FileName) = @_;

    open(INPUT, $FileName);

    my @Lines = <INPUT>;

    my @Indices = ();

    my $i = 0;
    while ($i <= scalar(@Lines) - 1) {

	if ($Lines[$i] =~ /^>/) {
	    push (@Indices, $i);
	}

	$i++;
    }
    
    push (@Indices, scalar(@Lines));

    close (INPUT);

    return (\@Lines, @Indices)
}


## This function receives the name of a file containing all the promoter sequences to be scanned
## in FASTA format. Finally, two parameters: (1) the reference to a hash whose "keys" and "values"
## are integer indices as well as the name of the gene each promoter region belongs to, and 
## (2) another hash whose "keys" are also integer indices, but whose "values" are different promoter
## sequences are returned.

sub GetPromoterInfo {
    
    my ($self, $FileName) = @_;

    my ($ref_Lines, @Indices) = $self -> PromoterFileReader($FileName);
    
    my @Lines = @{$ref_Lines};

    my (%GeneNameHash, %PromoterHash) = ();

    my $i = 0;
    while ($i <= scalar(@Indices) - 2) {

	my @Values = Utils::SplitString('\|', $Lines[$Indices[$i]]);
	$GeneNameHash{$i + 1} = $Values[1];	
	$PromoterHash{$i + 1} = Utils::GetSequenceFromList($Indices[$i], $Indices[$i + 1], @Lines);

	$i++;
    }

    return (\%GeneNameHash, %PromoterHash);
}


## This function receives two parameters: (1) an output file name, and (2) a hash whose "keys" 
## and "values" are gene names as well as respective lists composed of those potential binding
## sites detected. Consequently, the aforementioned information is written into the external 
## file previously typed.

sub PutativeTFBSsWriter {

    my ($self, $OutputFile, %TFBSPerPromoter) = @_;

    open(OUTPUT, ">$OutputFile");
    
    my @GeneNames = keys(%TFBSPerPromoter);

    foreach my $GeneName (@GeneNames) {

	print (OUTPUT "\n******************************************************\n");
	print (OUTPUT $GeneName);
	print (OUTPUT "\n");
	print (OUTPUT "******************************************************\n\n");	

	my @TFBSs = @{$TFBSPerPromoter{$GeneName}};

	foreach my $TFBS (@TFBSs) {	
	    print (OUTPUT $TFBS);
	    print (OUTPUT "\n");
	}	
    }

    close (OUTPUT);
}


## This function receives two parameters: (1) a file name, and (2) any hash. Afterwards, the hash 
## as well as all its information is written into the external file.

sub Save {

    my ($self, $FileName, %Data) = @_;

    store(\%Data, $FileName);
}

## This function ....

sub recover_variable {

    my ($self, $file_name) = @_;

    my $ref_hash = retrieve($file_name);

    return (%{$ref_hash})
}


1;
