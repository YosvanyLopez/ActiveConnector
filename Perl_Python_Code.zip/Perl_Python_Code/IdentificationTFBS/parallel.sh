#$ -cwd -S /bin/bash
#$ -l s_vmem=8G -l mem_req=8G

set -xue

perl ScanPromoters.pl

echo done
