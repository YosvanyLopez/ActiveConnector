#########################################################################################
## This package contains the class "Promoter", which groups those properties related   ##
## to a promoter region such as the name of the gene it belongs to and its sequence.   ##
## Likewise, it detects all the Transcription Factor Binding Sites (TFBSs) within this ##
## genomic region.                                                                     ## 
##                                                                                     ## 
## Laboratory of Functional Analysis in silico                                         ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo          ##
## Programmed by Yosvany Lopez Alvarez                                  November, 2011 ##
#########################################################################################

package Promoter;

use warnings;
use strict;
use TFCollection;

## This function represents the class' constructor. It contains two attributes: (1) the name
## of the gene the promoter region belongs to, and (2) its DNA sequence. Once it is called,
## an instance containing both properties is created.

sub new {

    my $self = {};

    $self -> {GENENAME} = undef;
    $self -> {SEQUENCE} = undef;
	
    bless($self);
    
    return ($self);
}


## This function receives a gene name, and updates the attribute "GENENAME" with its information.

sub setGeneName {

    my ($self, $GeneName) = @_;

    $self -> {GENENAME} = $GeneName;
}


## This function returns the value stored in the attribute "GENENAME".

sub getGeneName {

    my ($self) = @_;

    return ($self -> {GENENAME})
}


## This function receives a DNA sequence, and updates the attribute "SEQUENCE" with its content.

sub setSequence {

    my ($self, $Sequence) = @_;
    
    $self -> {SEQUENCE} = $Sequence;
}


## This function returns the value stored in the attribute "SEQUENCE".

sub getSequence {

    my ($self) = @_;
    
    return ($self -> {SEQUENCE})
}


## This function receives two parameters: (1) a threshold to choose those TFBSs whose 
## scores are greater than it, and (2) an object "TFCollection", which contains the TFs
## to be detected within the promoter region. Afterwards, it returns the reference to 
## a list of TFBSs successfully uncovered.

sub DetectTFBSs {

    my ($self, $TFObject, %thresholds) = @_;

    my $Sequence = $self -> getSequence();

    my @TFBSs = $TFObject -> GetPotentialTFBSs($Sequence, %thresholds);

    return (\@TFBSs);
}


1;
