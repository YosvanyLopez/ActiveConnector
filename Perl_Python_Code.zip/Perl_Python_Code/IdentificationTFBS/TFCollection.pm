##########################################################################################
## This package contains the class "TFCollection", which collects those Transcription   ##
## Factors (TFs) being used to scan the promoters regions.                              ## 
##                                                                                      ## 
## Laboratory of Functional Analysis in silico                                          ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo           ##
## Programmed by Yosvany Lopez Alvarez                                   November, 2011 ##
##########################################################################################

package TFCollection; 

use warnings;
use strict;
use TranscriptionFactor;

## This function represents the class' constructor. It contains a hash whose "keys" and 
## "values" are TF's identifiers and objects "TranscriptionFactor", respectively. Each 
## new instance will have the same information. 

sub new {

    my $self = {};

    %{$self -> {TRANSCRIPTIONFACTORS}} = ();
	
    bless($self);
    
    return ($self);
}


## This function receives a hash whose "keys" and "values" are TF's identifiers and string 
## lists that contain the Position Frequency Matrix (PFM) of every TF. Afterwards, each 
## object "TranscriptionFactor" is created and inserted into the collection of TFs stored 
## in the attribute "TRANSCRIPTIONFACTORS".

sub UpdateTFCollection {

    my ($self, %TFInformation) = @_;

    my @TFIndices = keys(%TFInformation);

    foreach my $TFIndex (@TFIndices) {

	my $TFObject = new TranscriptionFactor();
	my $SiteNumber = $TFObject -> setFrequencyMatrix($TFIndex, @{$TFInformation{$TFIndex}});
	$TFObject -> setWeightMatrix($SiteNumber);

	${$self -> {TRANSCRIPTIONFACTORS}}{$TFIndex} = $TFObject;
    }
}


## This function returns the collection of TFs stored in the attribute "TRANSCRIPTIONFACTORS".

sub getTFCollection {
 
    my ($self) = @_;
    
    return (%{$self -> {TRANSCRIPTIONFACTORS}})
}


## This function receives two parameters: (1) a nucleotide sequence, and (2) a threshold. Soon 
## after, the sequence is scanned by the collection of TFs and a list composed of those potential
## binding sites is returned.

sub GetPotentialTFBSs {

    my ($self, $Sequence, %thresholds) = @_;

    my %TFCollection = $self -> getTFCollection();

    my @TFNames = sort(keys(%TFCollection));

    my @PutativeSites = ();   

    foreach my $TFName (@TFNames) {

	push (@PutativeSites, $TFCollection{$TFName} -> ScanProfile($Sequence, $thresholds{$TFName}));
    }  

    for(my $i = 0; $i <= scalar(@PutativeSites) - 1; $i++) { $PutativeSites[$i] = $i . "\t" . $PutativeSites[$i] }

    return (@PutativeSites)
}

## This function returns a hash whose "keys" and "values" are TF's identifiers as well as their
## respective PFMs.

sub GatherTFCollection {

    my ($self) = @_;

    my %FixedTFCollection = ();

    my %TFCollection = $self -> getTFCollection();

    my @Indices = sort(keys(%TFCollection));

    foreach my $Index (@Indices) {

	my $Identifier = $TFCollection{$Index} -> getName();
	my %PositionMatrix = $TFCollection{$Index} -> getFrequencyMatrix(); 

	$FixedTFCollection{$Identifier} = \%PositionMatrix;
    }

    return (%FixedTFCollection)   
}


1;
