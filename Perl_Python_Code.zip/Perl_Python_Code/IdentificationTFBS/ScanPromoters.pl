#################################################################################################
## This script calls distinct functions from three different packages: "PromoterCollection",   ##
## "File" and "TFCollection". Consequently, it scans all the promoter regions for potential    ##
## Transcription Factor Binding Sites (TFBSs).                                                 ##
## Its programming was based on the following reference:                                       ##
## "Wasserman W. & Sandelin A., Applied bioinformatics for the identification of regulatory    ##
## elements, Nature Reviews Genetics (2004), 5, 276-287".                                      ##
##                                                                                             ##
## Laboratory of Functional Analysis in silico                                                 ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo                  ##
## Programmed by Yosvany Lopez Alvarez                                          November, 2011 ##
#################################################################################################

#!/usr/local/bin/perl

use warnings;
use strict;
use File;
use TFCollection;
use PromoterCollection;

##################################################################################################

my $TFFile = '';  ## file of PFMs
 
my $PromoterFile = ''; ## file of promoter sequences in fasta format

my $threshold_file = ''; ## file of motif thresholds

my $TFMatrixFile = ''; ## file to save motif matrices

my $TFBSHashFile = ''; ## file to save the binding sites of each promoter

#################################################################################################

my $FileObject = new File();
my %FrequencyMatrices = $FileObject -> TFFileReader($TFFile);
my ($ref_GeneNames, %Promoters) = $FileObject -> GetPromoterInfo($PromoterFile);

my $TFCollectionObject = new TFCollection();
$TFCollectionObject -> UpdateTFCollection(%FrequencyMatrices);

my $PromoterCollectionObject = new PromoterCollection();
$PromoterCollectionObject -> UpdatePromoterList($ref_GeneNames, %Promoters);

my %thresholds = $FileObject -> recover_variable($threshold_file);

my %TFBSPerPromoter = $PromoterCollectionObject -> ScanPromotersForTFBS($TFCollectionObject, %thresholds);

$FileObject -> Save($TFMatrixFile, $TFCollectionObject -> GatherTFCollection());

$FileObject -> Save($TFBSHashFile, %TFBSPerPromoter);

#################################################################################################
