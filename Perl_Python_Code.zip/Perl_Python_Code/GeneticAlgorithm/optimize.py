##########################################################################################
## Laboratory of Functional Analysis in silico                                          ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo           ##
## Programmed by Yosvany Lopez Alvarez                                      March, 2015 ##
##########################################################################################

#!/usr/local/bin/python

from File import *
from GeneticAlgorithm import *
import pickle 
from sets import Set 
import sys 

###########################################################################################

cv_directory = './dmel_development/stage_' + str(sys.argv[1]) + '/model_build/cv/'

weight_file = './dmel_development/stage_' + str(sys.argv[1]) + '/feature_generation/feature_weights.python'
 
chromosome_file = './dmel_development/stage_' + str(sys.argv[1]) + '/model_build/chromosomes.info'

###########################################################################################

chromosome_set = dict()

fold = 1

while (fold <= 5):    ## number of cross-validated folds ....
    
    positive_file = cv_directory + 'PTraining_' + str(fold) + '.txt'
    negative_file = cv_directory + 'NTraining_' + str(fold) + '.txt'
        
    file_obj = File()
    SpecificSet_Str = file_obj.FileReader(positive_file)
    NonSpecificSet_Str = file_obj.FileReader(negative_file)
    
    (Rules, positive) = file_obj.ValuePerFeature(SpecificSet_Str)
    (Rules, negative) = file_obj.ValuePerFeature(NonSpecificSet_Str)
    
    weights = file_obj.Retrieve(weight_file)
    feature_weights = array(file_obj.DefineWeights(Rules, weights))

    TrainingSet = positive + negative
        
    gaObject = GeneticAlgorithm(len(TrainingSet[0]), len(TrainingSet), 0.05, 'un', 4, True)

    fittest_individual = gaObject.run_ga(0.8, 0.5, feature_weights, positive, negative)

    chromosome_set[fold] = fittest_individual

    fold += 1

output = open(chromosome_file, 'wb')
pickle.dump(chromosome_set, output)

#############################################################################################
