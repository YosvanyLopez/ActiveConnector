
input_file = "uncorrected_pvalues.txt"
output_file = "corrected_pvalues.txt"

dataset = read.table(input_file, head=FALSE, sep="\t")

model_list = dataset[,1:1]
f_score_list = dataset[,2:2]
p_value_list = dataset[,3:3]

p_value_list = as.vector(p_value_list)

fdr_values <- p.adjust(p_value_list, method = "fdr", n = length(p_value_list))

header = paste("model", "f-score", "uncorrected_pvalue", "corrected_pvalue", sep="\t")
cat(header, file=output_file, append=TRUE)
cat("\n", file=output_file, append=TRUE)

for (i in 1:length(fdr_values)) {
	oline = paste(model_list[i], f_score_list[i], format(p_value_list[i], scientific=TRUE), format(fdr_values[i], scientific=TRUE), sep="\t")
	cat(oline, file=output_file, append=TRUE)
	cat("\n", file=output_file, append=TRUE)
}