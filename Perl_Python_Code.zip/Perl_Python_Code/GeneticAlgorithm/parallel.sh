#$ -cwd -S /bin/bash

set -xue

python optimize.py <stage_number>

echo done