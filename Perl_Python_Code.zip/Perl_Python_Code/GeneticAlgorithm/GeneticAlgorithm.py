##########################################################################################
## This package contains the class "GeneticAlgorithm" which is a modified version of    ##
## the script attached to chapter "Evolutionary Learning" of the book                   ##
## "Machine Learning" by Stephen Marsland                                               ## 
##                                                                                      ## 
## Laboratory of Functional Analysis in silico                                          ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo           ##
## Programmed by Yosvany Lopez Alvarez                                      April, 2013 ##
##########################################################################################

from numpy import *
import numpy as np

class GeneticAlgorithm:
	
	## This function is the class' constructor.

	def __init__(self, stringLength, populationSize=6, mutationProb=-1, crossover='un', nElite=4, tournament=True):

		self.STRINGLENGTH = stringLength

		## Population size should be even
		if (mod(populationSize,2) == 0):
			self.POPULATIONSIZE = populationSize
		else:
			self.POPULATIONSIZE = populationSize + 1
			
		if (mutationProb < 0):
			self.MUTATIONPROB = 1/stringLength
		else:
			self.MUTATIONPROB = mutationProb
	   
		self.CROSSOVER = crossover
		self.ELITE = nElite
		self.TOURNAMENT = tournament

		self.POPULATION = random.rand(self.POPULATIONSIZE, self.STRINGLENGTH)
		self.POPULATION = where(self.POPULATION<0.5, 0, 1)
		
        def run_ga (self, threshold, cutoff, feature_weights, tr_positive, tr_negative):

		fittest_individual = []

                f_score = 0
                proportion = 0
 
                epoch = 0

                while ((epoch < 10000) and ((f_score < threshold) and (proportion <= cutoff))): 
               
                        # Compute fitness of the population
                        fitness = self.ComputeFitness(self.POPULATION, feature_weights) 
			
                        # Pick parents
			newPopulation = self.Selection(self.POPULATION, fitness)

			# Apply the genetic operators
			if (self.CROSSOVER == 'sp'):
                                newPopulation = self.spCrossover(newPopulation)
			elif (self.CROSSOVER == 'un'):
				newPopulation = self.uniformCrossover(newPopulation)
                        newPopulation = self.mutate(newPopulation)
                                
			# Apply elitism and tournaments
			if (self.ELITE > 0):
				newPopulation = self.elitism(self.POPULATION, newPopulation, fitness)
	
			if (self.TOURNAMENT):
				newPopulation = self.tournament(self.POPULATION, newPopulation, feature_weights, fitness)
	
			self.POPULATION = newPopulation

                        (f_score, scored_ppromoters, fittest_individual) = self.get_fittest_individual(tr_positive, tr_negative, feature_weights)

			proportion = scored_ppromoters/float(len(tr_positive))

			epoch += 1

                return (fittest_individual)

	def ComputeFitness(self, chromosomes, weights):

		Fitness = []

		i = 0
		while (i <= len(chromosomes) - 1):
			FitnessIndividual = sum(x * y for x, y in zip(chromosomes[i], weights))
			Fitness.append(FitnessIndividual)
			
			i += 1

		return (Fitness)

	
	def get_fittest_individual (self, positive, negative, feature_weights):
                
                chromosomes = self.POPULATION

                score_list = []
                positive_amount = []

                for i in range(0, len(chromosomes)):

                        (f_score, scored_promoters) = self.get_chromosome_info(chromosomes[i], positive, negative, feature_weights)

                        score_list.append(f_score)
                        positive_amount.append(scored_promoters)

                max_score = max(score_list)
                best_idx = score_list.index(max_score)

                ppromoter_amount = positive_amount[best_idx]
                fittest_individual = chromosomes[best_idx]

                fittest_individual = fittest_individual.tolist()                
  
                return (max_score, ppromoter_amount, fittest_individual)

        def get_chromosome_info (self, chromosome, positive, negative, feature_weights):

                weighed_chr = chromosome * feature_weights

                positive_scores = []
                for pvector in positive:
                        positive_scores.append(sum(list(pvector * weighed_chr)))

                negative_scores = []
                for nvector in negative:
                        negative_scores.append(sum(list(nvector * weighed_chr)))
                        
                fn = positive_scores.count(0)
                tn = negative_scores.count(0)
                
                tp = len(positive_scores) - fn
                fp = len(negative_scores) - tn

                denominator_r = tp + fn
                denominator_p = tp + fp
                
		if (denominator_r == 0):
			denominator_r = 1
					
		if (denominator_p == 0):
                        denominator_p = 1

                recall = tp / float(denominator_r)
                precision = tp / float(denominator_p)

		f_score = 0

                if ((recall == 0) & (precision == 0)):
                        f_score = 0
                else:
                        f_score = 2 * ((precision * recall) / (precision + recall))

                sorted_negative_scores = sorted(negative_scores)
                threshold = sorted_negative_scores[int(len(negative_scores) * 0.9) - 1]

                scored_promoters = 0
                for score in positive_scores:
                        if (score > threshold):
                                scored_promoters += 1

                accuracy = (tp + tn) / float(tp + tn + fp + fn)
                sens = tp / float(tp + fn)
                spec = tn / float(tn + fp)
                     
                return (f_score, scored_promoters)  ## accuracy, sensitivity and specificity are also computed 

	def Selection (self, population, fitness):

		# Scale fitness by total fitness
		fitness = fitness/sum(fitness)
		fitness = (10 * fitness)/fitness.max()

		# Place repeated copies of each string in according to fitness
		# Deal with strings with very low fitness
		j = 0
		while (round(fitness[j]) < 1):
			j += 1

		newPopulation = kron(ones((round(fitness[j]), 1)), population[j, :])
			
		# Add multiple copies of strings into the newPopulation
		for i in range(j + 1, self.POPULATIONSIZE):
			if (round(fitness[i]) >= 1):
				newPopulation = concatenate((newPopulation, kron(ones((round(fitness[i]), 1)), population[i,:])), axis=0)

		# Shuffle the order
		indices = range(shape(newPopulation)[0])
		random.shuffle(indices)
		newPopulation = newPopulation[indices[:self.POPULATIONSIZE], :]
		
		return (newPopulation)

	def spCrossover (self, population):

		# Single point crossover
		newPopulation = zeros(shape(population))
		crossoverPoint = random.randint(0, self.STRINGLENGTH, self.POPULATIONSIZE)
		
		for i in range(0, self.POPULATIONSIZE, 2):
			newPopulation[i,:crossoverPoint[i]] = population[i,:crossoverPoint[i]]
			newPopulation[i+1,:crossoverPoint[i]] = population[i+1,:crossoverPoint[i]]
			newPopulation[i,crossoverPoint[i]:] = population[i+1,crossoverPoint[i]:]
			newPopulation[i+1,crossoverPoint[i]:] = population[i,crossoverPoint[i]:]
		
		return (newPopulation)

	def uniformCrossover (self, population):

		# Uniform crossover
		newPopulation = zeros(shape(population))
		which = random.rand(self.POPULATIONSIZE, self.STRINGLENGTH)

		which1 = (which >= 0.5)
		for i in range(0, self.POPULATIONSIZE, 2):
			newPopulation[i,:] = population[i,:] * which1[i,:] + population[i+1,:] * (1-which1[i,:])
			newPopulation[i+1,:] = population[i,:] * (1-which1[i,:]) + population[i+1,:] * which1[i,:]
		
		return (newPopulation)

	def mutate (self, population):
		
		# Mutation
		whereMutate = random.rand(shape(population)[0], shape(population)[1])
		population[where(whereMutate < self.MUTATIONPROB)] = 1 - population[where(whereMutate < self.MUTATIONPROB)]
		
		return (population)

	def elitism (self, oldPopulation, population, fitness):

		best = argsort(fitness)
		best = squeeze(oldPopulation[best[-self.ELITE:],:])
		indices = range(shape(population)[0])
		random.shuffle(indices)
		population = population[indices,:]
		population[0:self.ELITE,:] = best
		
		return (population)

	def tournament (self, oldPopulation, population, featureWeights, fitness):
		
		newFitness = self.ComputeFitness(population, featureWeights)

		for i in range(0, shape(population)[0], 2):
			f = concatenate((fitness[i:i+2], newFitness[i:i+2]), axis=0.99)
			indices = argsort(f)
			if ((indices[-1] < 2) and (indices[-2] < 2)):
				population[i,:] = oldPopulation[i,:]
				population[i+1,:] = oldPopulation[i+1,:]
			elif (indices[-1] < 2):
				if (indices[0] >= 2):
					population[i + indices[0] - 2,:] = oldPopulation[i + indices[-1]]
				else:
					population[i + indices[1] - 2,:] = oldPopulation[i + indices[-1]]
			elif (indices[-2] < 2):
				if (indices[0] >= 2):
					population[i + indices[0] - 2,:] = oldPopulation[i + indices[-2]]
				else:
					population[i + indices[1] - 2,:] = oldPopulation[i + indices[-2]]
		return (population)
