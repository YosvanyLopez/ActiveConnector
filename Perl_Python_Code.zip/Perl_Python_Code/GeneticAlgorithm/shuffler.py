##############################################################################################
## Laboratory of Functional Analysis in silico                                              ##                                                                                    
## Human Genome Center, Institute of Medical Science, The University of Tokyo               ##                                                                                    
## Programmed by Yosvany Lopez Alvarez                                          March, 2015 ##                                                                                    
##############################################################################################                                                                                     

import random
from sets import Set

class shuffler:

    def fix_class (self, class_id, string_list):

        object_matrix = []

        object_number = 0

        for i in range(0, len(string_list)):
            string = string_list[i].strip()
            (items) = string.split("\t")
            object_number = len(items) - 1
            object_matrix.append(items)

        class_list = ['class']
        binary_list = [class_id] * object_number
        class_list = class_list + binary_list

        object_matrix.append(class_list)

        object_matrix = zip(*object_matrix)
        
        feature_list = object_matrix.pop(0)

        feature_hash = dict ()
        for j in range(0, len(feature_list) - 1):
            feature_hash[j] = feature_list[j]

        return (feature_hash, object_matrix)

    def get_random_promoters (self, opposite_class, random_amount, promoter_set):

        random_promoters = []
        random_indices = []

        nclass = (str(opposite_class),)

        while (len(random_indices) < random_amount):
            random_number = random.randint(0, len(promoter_set) - 1)
            if (random_number not in Set(random_indices)):
                random_indices.append(random_number)
                random_promoter = promoter_set[random_number]
                promoter_set.remove(random_promoter)
                random_promoter = random_promoter[:len(random_promoter) - 1] + nclass
                random_promoters.append(random_promoter)
            
        return (random_promoters, promoter_set)

    def reorganize_matrix (self, tuple_matrix):

        positive_matrix = []

        for i in range(0, len(tuple_matrix)):
            nlist = list(tuple_matrix[i])
            nlist.pop()
            positive_matrix.append(map(int, nlist))
        
        return (positive_matrix)
