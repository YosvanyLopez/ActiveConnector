##########################################################################################
## Laboratory of Functional Analysis in silico                                          ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo           ##
## Programmed by Yosvany Lopez Alvarez                                   November, 2016 ##
##########################################################################################

#!/usr/local/bin/python

from File import *
from shuffler import *
from GeneticAlgorithm import *
from decimal import Decimal

###########################################################################################

model_list = [1, 2, 3, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 24, 25]

directory = '../dmel_development/'

###########################################################################################

output_file = directory + 'uncorrected_pvalues.txt'

output = open(output_file, 'w')

for model in model_list:

    cv_directory = directory + 'stage_' + str(model) + '/model_build/cv/'
    weight_file = directory + 'stage_' + str(model) + '/feature_generation/feature_weights.python'
    chromosome_file = directory + 'stage_' + str(model) + '/model_build/chromosomes.info'
    f_score_file = directory + 'stage_' + str(model) + '/model_build/noisy_score_list.info'

    file_object = File ()
    chromosomes = file_object.Retrieve(chromosome_file)

    avg_f_score = 0

    for i in range(1,6):

        positive_test_file = cv_directory + 'PTest_' + str(i) + '.txt'
        negative_test_file = cv_directory + 'NTest_' + str(i) + '.txt'

        positive_str = file_object.FileReader(positive_test_file)
        negative_str = file_object.FileReader(negative_test_file)

        shuffler_obj = shuffler ()
        (features, positive_set) = shuffler_obj.fix_class('1', positive_str)
        (features, negative_set) = shuffler_obj.fix_class('0', negative_str)

        positive_matrix = shuffler_obj.reorganize_matrix(positive_set)
        negative_matrix = shuffler_obj.reorganize_matrix(negative_set)

        weights = file_object.Retrieve(weight_file)
        feature_weights = array(file_object.DefineWeights(features, weights))

        ga_object = GeneticAlgorithm(1, 1, -1, 'un', 4, True)   ## just creating the genetic algorithm instance

        (f_score, npromoters) = ga_object.get_chromosome_info(chromosomes[i], positive_matrix, negative_matrix, feature_weights)

        avg_f_score += f_score

    avg_f_score = avg_f_score/float(5)
    avg_f_score = round(avg_f_score, 3)

    f_score_list = file_object.Retrieve(f_score_file)

    counter = 0
    for item in f_score_list:
        if (item > avg_f_score):
            counter += 1

    p_value = counter/float(len(f_score_list))
    p_value =  '%.2e' % Decimal(str(p_value))

    output.write('stage_' + str(model) + "\t" + str(avg_f_score) + "\t" + p_value)
    output.write("\n")

output.close()

#############################################################################################
