##############################################################################################
## Laboratory of Functional Analysis in silico                                              ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo               ##
## Programmed by Yosvany Lopez Alvarez                                          April, 2013 ##
##############################################################################################

import pickle

class File:

    ## This function receives a file name
                                                                                                                           
    def FileReader (self, fileName):

        Input = open(fileName, "r")
        Lines = Input.readlines()
        GeneNameString = Lines.pop(0)
        Input.close()

        return (Lines)


    def ValuePerFeature (self, StringList):
        
        Rules = dict()
        Matrix = []
        
        i = 0
        while (i <= len(StringList) - 1):
            (Rule, Items) = self.SplitString ('\t', StringList[i])
            BinaryNumbers = self.StringToInteger(Items)

            Rules[i] = Rule.strip()
            Matrix.append(BinaryNumbers)       

            i += 1
            
        Transpose = zip(*Matrix)
        ChromosomeMatrix = [list(Item) for Item in Transpose]
        
        return (Rules, ChromosomeMatrix)

    ## This function receives two parameters: (1) a character to be used as splitter, and 
    ## (2) a string. Thereafter, the string is cut into small substrings. 

    def SplitString (self, character, string):

        List = []
        List = string.rsplit(character)
        GeneName = List.pop(0)

        return (GeneName, List)

    ## This function receives a list of string values and returns a new list composed of 
    ## their respective integer values.

    def StringToInteger (self, stringList):

        intList = map(int, stringList)

        return (intList)

    def Retrieve (self, fileName):

        Dictionary = pickle.load(open(fileName, "rb"))
        
        return (Dictionary)
                                                                                                                                                                            
    def Save (self, fileName, dictionary):

        output = open(fileName, 'wb')
        pickle.dump(dictionary, output)

    def DefineWeights (self, ruleDict, weightDict):

        ruleIndices = ruleDict.keys()

        weights = []

        for i in range(0, len(ruleIndices)):
            weights.append(weightDict[ruleDict[ruleIndices[i]]])
         
        return (weights)

    def get_optimal_features (self, threshold, chromosome_list, features, weights):

        feature_info = zip(*chromosome_list)

        optimal_features = dict()

        for i in range(0, len(feature_info)):
            items = list(feature_info[i])
            counter = items.count(1)
            proportion = counter/float(len(items))

            if (proportion >= threshold):
                optimal_features[features[i]] = weights[i]
                
        return (optimal_features)

    def feature_writer (self, output_file, optimal_features):

        output = open(output_file, 'w')

        features = optimal_features.keys()

        for feature in features:
            output.write(feature + '\t' + str(optimal_features[feature]))
            output.write('\n')

        output.close()
