##########################################################################################
## Laboratory of Functional Analysis in silico                                          ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo           ##
## Programmed by Yosvany Lopez Alvarez                                      March, 2015 ##
##########################################################################################

#!/usr/local/bin/python

from File import *
from shuffler import *
from GeneticAlgorithm import *
import sys

###########################################################################################

cv_directory = './dmel_development/stage_' + str(sys.argv[1]) + '/model_build/cv/'

weight_file = './dmel_development/stage_' + str(sys.argv[1]) + '/feature_generation/feature_weights.python'

chromosome_file = './dmel_development/stage_' + str(sys.argv[1]) + '/model_build/chromosomes.info'

f_score_file = './dmel_development/stage_' + str(sys.argv[1]) + '/model_build/noisy_score_list.info'

############################################################################################

percentage = 40

file_object = File ()
chromosomes = file_object.Retrieve(chromosome_file)

f_score_list = []

for j in range(0, 1000000):
    
    f_score_sum = 0

    for i in range(1,6):
    
        positive_test_file = cv_directory + 'PTest_' + str(i) + '.txt'
        negative_test_file = cv_directory + 'NTest_' + str(i) + '.txt'
    
        positive_str = file_object.FileReader(positive_test_file)
        negative_str = file_object.FileReader(negative_test_file)
        
        shuffler_obj = shuffler ()
        (features, positive_set) = shuffler_obj.fix_class('1', positive_str)
        (features, negative_set) = shuffler_obj.fix_class('0', negative_str)

        random_percentage = (len(positive_set) * percentage)/100
    
        (random_positive, positive_remainder) = shuffler_obj.get_random_promoters('n', random_percentage, positive_set)
        (random_negative, negative_remainder) = shuffler_obj.get_random_promoters('p', random_percentage, negative_set)

        shuffled_positive = positive_remainder + random_negative
        shuffled_negative = negative_remainder + random_positive

        positive_nmatrix = shuffler_obj.reorganize_matrix(shuffled_positive)
        negative_nmatrix = shuffler_obj.reorganize_matrix(shuffled_negative)
    
        weights = file_object.Retrieve(weight_file)
        feature_weights = array(file_object.DefineWeights(features, weights))  

        ga_object = GeneticAlgorithm(1, 1, -1, 'sp', 4, True)   ## just creating the genetic algorithm instance
        (f_score, npromoters) = ga_object.get_chromosome_info(chromosomes[i], positive_nmatrix, negative_nmatrix, feature_weights)

        f_score_sum += f_score

    avg_f_score = f_score_sum/float(5)

    f_score_list.append(avg_f_score)

file_object.Save(f_score_file, f_score_list)

#############################################################################################
