##########################################################################################
## Laboratory of Functional Analysis in silico                                          ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo           ##
## Programmed by Yosvany Lopez Alvarez                                      March, 2015 ##
##########################################################################################

#!/usr/local/bin/python

from File import *
from GeneticAlgorithm import *
import sys

###########################################################################################

cv_directory = './dmel_development/stage_' + str(sys.argv[1]) + '/model_build/cv/'

chromosome_file = './dmel_development/stage_' + str(sys.argv[1]) + '/model_build/chromosomes.info'

weight_file = './dmel_development/stage_' + str(sys.argv[1]) + '/feature_generation/feature_weights.python'

optimal_feature_file = './dmel_development/stage_' + str(sys.argv[1]) + '/model_build/optimal_features.txt'

###########################################################################################

file_object = File ()
chromosomes = file_object.Retrieve(chromosome_file)

folds = chromosomes.keys()

features = []
feature_weights = []
chromosome_list = []

f_score_sum = 0

for fold in folds:

	fittest_chromosome = chromosomes[fold]
	chromosome_list.append(fittest_chromosome)

	positive_test_file = cv_directory + 'PTest_' + str(fold) + '.txt'
	negative_test_file = cv_directory + 'NTest_' + str(fold) + '.txt'

	positive_str = file_object.FileReader(positive_test_file)
	negative_str = file_object.FileReader(negative_test_file)

	(features, positive_set) = file_object.ValuePerFeature(positive_str)
	(features, negative_set) = file_object.ValuePerFeature(negative_str)

	weights = file_object.Retrieve(weight_file)
	feature_weights = array(file_object.DefineWeights(features, weights))  

	ga_object = GeneticAlgorithm(1, 1, -1, 'un', 4, True) ## just creating the genetic algorithm instance
	(f_score, npromoters) = ga_object.get_chromosome_info(fittest_chromosome, positive_set, negative_set, feature_weights)

	f_score_sum += f_score
                        
avg_f_score = f_score_sum/float(len(folds))

print avg_f_score

optimal_features = file_object.get_optimal_features(0.8, chromosome_list, features, feature_weights.tolist())

file_object.feature_writer(optimal_feature_file, optimal_features)

#############################################################################################
