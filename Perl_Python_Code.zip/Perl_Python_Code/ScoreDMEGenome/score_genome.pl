###########################################################################################
## Laboratory of Functional Analysis in silico                                           ##                                                   
## Human Genome Center, Institute of Medical Science, The University of Tokyo            ##                                                   
## Programmed by Yosvany Lopez Alvarez                                       March, 2015 ##                                                   
###########################################################################################                                                  

#!/usr/local/bin/perl
                                                                                                                          
use warnings;
use strict;
use File;
use PromoterSet;

###########################################################################################                                                  

my $feature_genome = "./stage_" . $ARGV[0] . "/genome_info/feature_genome.info";

my $initial_gene_set = "./stage_" . $ARGV[0] . "/initial_sets/initial_control_sets.txt";

my $weight_feature_file = "./stage_" . $ARGV[0] . "/model_build/optimal_features.txt";

my $selection_file = "./stage_" . $ARGV[0] . "/genome_info/selected_genes_100.txt";

my $storage_file = "./stage_" . $ARGV[0] . "/genome_info/selected_genes_100.info";

##########################################################################################                                                    

my $file_object = new File();
my %optimal_features = $file_object -> RuleFileReader($weight_feature_file);
my %feature_promoters = $file_object -> Recover($feature_genome);

open(INPUT, $initial_gene_set);
my @lines = <INPUT>;
my $gene_str = (uc Utils::trim($lines[0]));
my @genes = split("\t", $gene_str);
close(INPUT);

foreach (@genes) { delete $feature_promoters{$_} }

my $promoter_obj = new PromoterSet();
my %scored_promoters = $promoter_obj -> score_promoter_set(\%optimal_features, %feature_promoters);

$file_object -> select_promoters(100, $selection_file, $storage_file, %scored_promoters); ## number of highly scoring promoters = 100

###########################################################################################
