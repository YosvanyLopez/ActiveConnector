###########################################################################################
## Laboratory of Functional Analysis in silico                                           ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo            ##
## Programmed by Yosvany Lopez Alvarez                                       April, 2016 ##
###########################################################################################
                                                  
#!/usr/local/bin/perl
                                                                                                                          
use warnings;
use strict;
use File;
use PromoterSet;

###########################################################################################
                                                  
my $feature_genome = './similarity_stages/stage_' . $ARGV[1] . '/feature_genome.info';

my $positive_file = './similarity_stages/stage_' . $ARGV[1] . '/stage_' . $ARGV[0] . '/positive_set.txt';

my $negative_file = './similarity_stages/stage_' . $ARGV[1] . '/stage_' . $ARGV[0] . '/negative_set.txt'; 

my $weight_feature_file = './stage_' . $ARGV[1] . '/model_build/optimal_features.txt';

my $output_file = './similarity_stages/stage_' . $ARGV[1] . '/stage_' . $ARGV[0] . '/scores.txt'; 

##########################################################################################

sub gene_reader {

    my ($file_name) = @_;

    my %list = ();

    open(INPUT, $file_name);

    while (<INPUT>) {
	$_ = Utils::trim($_);
	$list{$_} = 1
    }

    close(INPUT);
    
    return (%list)
}

##########################################################################################

my $file_obj = new File();
my %feature_promoters = $file_obj -> Recover($feature_genome);
my %optimal_features = $file_obj -> RuleFileReader($weight_feature_file);

my $promoter_obj = new PromoterSet();
my %scored_promoters = $promoter_obj -> score_promoter_set(\%optimal_features, %feature_promoters);

my %positive_set = gene_reader($positive_file);
my %negative_set = gene_reader($negative_file); 

my @positive_scores = ();
my @negative_scores = ();

foreach (keys(%scored_promoters)) {

    my @items = split("\t", $scored_promoters{$_});

    if (exists $positive_set{$items[0]}) { push(@positive_scores, $items[1]) }
    elsif (exists $negative_set{$items[0]}) { push(@negative_scores, $items[1]) } 
}

open(OUTPUT, ">$output_file");

print OUTPUT ('positive,' . join(",", @positive_scores));
print OUTPUT "\n";
print OUTPUT ('negative,' . join(",", @negative_scores));

close(OUTPUT)

###########################################################################################       
