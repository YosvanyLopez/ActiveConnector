##############################################################################################
## Laboratory of Functional Analysis in silico                                              ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo               ##
## Programmed by Yosvany Lopez Alvarez                                            May, 2013 ##
##############################################################################################

package File;

use warnings;
use strict;
use Utils;
use Storable;

## This function stands for the class' constructor.

sub new {

    my $self = {};

    bless($self);
       
    return ($self)
}

## This function ....

sub geneFileReader {

    my ($self, $fileName) = @_;

    open(INPUT, $fileName);
    my @Lines = <INPUT>;
    close (INPUT);
    
    my @Genes = Utils::SplitString($Lines[0]);

    my %geneNames = map {$_ => 1} @Genes;

    return (%geneNames)
}

## This function ....

sub RuleFileReader {

    my ($self, $fileName) = @_;

    open(INPUT, $fileName);

    my %definedRules = ();

    my $line = '';
    while ($line = <INPUT>) { 
	my @items = Utils::SplitString($line);
	$definedRules{Utils::trim($items[0])} = Utils::trim($items[1]) 
    }

    close (INPUT);

    return (%definedRules)
}

## This function .....

sub Save {

    my ($self, $fileName, %rules) = @_;

    store(\%rules, $fileName)
}

## This function receives an external file ....

sub Recover {

    my ($self, $externalFile) = @_;

    my $dataHash = retrieve($externalFile);

    return (%{$dataHash})
}

## This function receives two parameters: (1) the file name  .....

sub geneNameWriter {

    my ($self, $outputFile, @geneNames) = @_;

    open(OUTPUT, ">$outputFile");

    foreach my $geneName (@geneNames) {
	print OUTPUT Utils::trim($geneName);
	print OUTPUT "\n";
    }
    
    close (OUTPUT)
}

## This function ...

sub select_promoters {

    my ($self, $threshold, $output_file, $list_file, %scored_promoters) = @_;

    open(OUTPUT, ">$output_file");

    my @selected_genes = ();

    my $i = 0;
    while ($i <= $threshold - 1) {

	my @items = split("\t", $scored_promoters{$i});
	push(@selected_genes, $items[0]);

        print OUTPUT ($i . "\t" . $scored_promoters{$i});
        print OUTPUT "\n";

        $i++
    }

    close(OUTPUT);

    store(\@selected_genes, $list_file)
}

1;
