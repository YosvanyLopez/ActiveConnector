#################################################################################################
## Laboratory of Functional Analysis in silico                                                 ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo                  ##
## Programmed by Yosvany Lopez Alvarez                                               May, 2013 ##
#################################################################################################

package Promoter;

use warnings;
use strict;

## This function represents the class' constructor.

sub new {

    my ($self) = {};
    
    bless($self);

    return ($self);
}

## This function ....

sub scorePromoter {

    my ($self, $ref_PresentRules, %definedRules) = @_;

    my %presentRules = %{$ref_PresentRules};

    my $score = 0;

    my @rules = keys(%presentRules);

    foreach my $rule (@rules) {
        if (exists $definedRules{$rule}) { $score += $definedRules{$rule} }
        else { delete $presentRules{$rule} }
    }

    return ($score, %presentRules)
}

## This function ....

sub getMotifInfo {

    my ($self, $rule) = @_;

    my @items = split(':', $rule);

    my @motifInfo = ();

    for (my $i = 0; $i <= scalar(@items) - 1; $i++) {
        if (($items[$i] eq '+') || ($items[$i] eq '-')) {
            my $pair = $items[$i - 1] . ':' . $items[$i];
            push (@motifInfo, $pair)
        }
    }

    return (@motifInfo)
}

## This function ....

sub getAllMotifInfo {

    my ($self, %optimalRules)= @_;

    my @rules = keys(%optimalRules);

    my %allMotifs = ();

    foreach my $rule (@rules) {

        my @motifInfo = $self -> getMotifInfo($rule);
	my %auxiliar = map { $_ => 1 } @motifInfo;

        @allMotifs {keys %auxiliar} = values %auxiliar
    }

    return (%allMotifs)
}

## This function ....

sub filterBSites {

    my ($self, $ref_BSites, %optimalRules) = @_;

    my @bSites = @{$ref_BSites};

    my %allMotifs = $self -> getAllMotifInfo(%optimalRules);

    my @newBSites = ();

    foreach my $bSite (@bSites) {

        my @items = split('\t', $bSite);
        my $motifInfo = $items[0] . ':' . $items[3];

        if (exists $allMotifs{$motifInfo}) { push(@newBSites, $bSite)}
    }

    return (@newBSites)
}

## This function ....

sub checkRules {

    my ($self, $ref_ruleInfo, %optimalRules) = @_;

    my %ruleInfo = %{$ref_ruleInfo};
    my @rules = keys(%ruleInfo);

    my $flag = 0;

    foreach my $rule (@rules) {
        if (exists $optimalRules{$rule}) { $flag = 1 }
    }

    return ($flag)
}

## This function

sub correctFeatures {

    my ($self, $ref_features, %featurePromoter) = @_;

    my %features = %{$ref_features};
    my @featureIndex = keys(%features);

    foreach my $feature (@featureIndex) {

	my @items = split(':', $feature);

	if (scalar(@items) == 6) {

	    my $alternativeFeature = $items[2] . ":" . $items[3] . ":" . $items[0] . ":" . $items[1] . ":0:" . $items[5];

	    if (exists $featurePromoter{$alternativeFeature}) {

		my $auxiliar = $featurePromoter{$alternativeFeature};

		delete $featurePromoter{$alternativeFeature};

		$featurePromoter{$feature} = $auxiliar
	    }
	}
    }

    return (%featurePromoter)
}

1;
