################################################################################################
## Laboratory of Functional Analysis in silico                                                ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo                 ##
## Programmed by Yosvany Lopez Alvarez                                              May, 2013 ##
################################################################################################

package PromoterSet;

use warnings;
use strict;
use Promoter;
use List::Util qw(min max);

## This function represents the class' constructor. 

sub new {

    my ($self) = {};

    bless($self);

    return ($self)
}

## This function .....

sub correctPromoterSet {

    my ($self, $ref_features, %promoters) = @_;

    my %updatedPromoters = ();
    
    my @genes = keys(%promoters);
    
    foreach my $gene (@genes) {

	my $promoterObject = new Promoter();
	my %auxiliar = $promoterObject -> correctFeatures ($ref_features, %{$promoters{$gene}});
	
	$updatedPromoters{$gene} = \%auxiliar
    }

    return (%updatedPromoters)
}

## This function ...

sub score_promoter {

    my ($self, $ref_optimal_features, %feature_hash) = @_;

    my %optimal_features = %{$ref_optimal_features};

    my @feature_list = keys(%feature_hash);

    my $score = 0;
   
    if (scalar(@feature_list) != 0) {
        foreach (@feature_list) { $score += $feature_hash{$_} * $optimal_features{$_} }
    }

    return ($score)
}

## This function ... 

sub score_promoter_set {

    my ($self, $ref_optimal_features, %feature_promoters) = @_;

    my @promoter_set = keys(%feature_promoters);

    my %scored_promoters = ();

    my $counter = 0;

    foreach (@promoter_set) {
	my $score = $self -> score_promoter($ref_optimal_features, %{$feature_promoters{$_}});
	$scored_promoters{$_} = $score;
	if ($score != 0) { $counter++ }    
    }

    my %sorted_promoters = ();
    
    my $index = 0;
    foreach my $gene_name (sort { ($scored_promoters{$b} cmp $scored_promoters{$a}) || ($b cmp $a) } keys %scored_promoters) {
	$sorted_promoters{$index} = $gene_name . "\t" . $scored_promoters{$gene_name};
	$index ++
    }

    return (%sorted_promoters)
}

## This function ...

sub bestScoredPromoters {

    my ($self, $bestScored, %scoredPromoters) = @_;

    my $counter = 0;
    my %sortedByScores = ();

    foreach (sort { ($scoredPromoters{$b} cmp $scoredPromoters{$a}) || ($b cmp $a) } keys %scoredPromoters) {
        $sortedByScores{$counter} = $_;
        $counter++
    }

    my %bestScoredPromoters = ();

    my $i = 0;
    while ($i <= $bestScored - 1) {

        my $geneName = $sortedByScores{$i};
        my $score = $scoredPromoters{$geneName};

        $bestScoredPromoters{$geneName} = $score;

        $i++
    }

    return (%bestScoredPromoters)
}

## This function ....

sub bSitePerPromoter {

    my ($self, $ref_promoters, $ref_BSPerPromoter, %rulesPerPromoter) = @_;

    my @promoters = @{$ref_promoters};
    my %bSPerPromoter = %{$ref_BSPerPromoter};

    my %newBSPerPromoter = ();

    foreach my $promoter (@promoters) {

        my @bsites = @{$bSPerPromoter{$promoter}};
        my %rules = %{$rulesPerPromoter{$promoter}};

        my $promoterInstance = new Promoter ();
        my @newBSites = $promoterInstance -> filterBSites(\@bsites, %rules);

        $newBSPerPromoter{$promoter} = \@newBSites
    }

    return (%newBSPerPromoter)
}

## This function .....

sub requiredPromoterInfo {

    my ($self, $ref_rulePerPromoter, $ref_bSPerPromoter, %requiredRules) =  @_;

    my %rulePerPromoter= %{$ref_rulePerPromoter};
    my %bSPerPromoter =%{$ref_bSPerPromoter};

    my %requiredPromoters = ();

    my @promoters = keys(%bSPerPromoter);

    foreach my $promoter (@promoters) {

        my $promoterInstance = new Promoter();
	my $flag = $promoterInstance -> checkRules($rulePerPromoter{$promoter}, %requiredRules);
	
        if ($flag == 1) { $requiredPromoters{$promoter} = $bSPerPromoter{$promoter} }
    }   

    return (%requiredPromoters)
}

1;
