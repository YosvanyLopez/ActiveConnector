##############################################################################################
## Laboratory of Functional Analysis in silico                                              ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo               ##
## Programmed by Yosvany Lopez Alvarez                                       November, 2014 ##
##############################################################################################

from utils import *
import pickle

class handler:

    ## This function ....

    def extract_gene_id (self, file_name):
        
        input = open(file_name, "r")

        gene_list = dict ()

        for line in input:
            line = line.strip()
            
            if (not line.startswith("#")):
                items = line.split("\t")

                if (items[2] == "gene"):
                    subitems = items[8].split(";")
                    gene_id = subitems[0]
                    gene_id = gene_id[gene_id.find('"') + 1:len(gene_id) - 1]

                    gene_list[gene_id] = []

        input.close()

        return (gene_list)

    ## This function ...

    def get_gene_expression (self, gene_list, gene_expression_files):

        for i in range(0, len(gene_expression_files)):
        
            input = open(gene_expression_files[i], "r")

            for line in input:
                if (not line.startswith("tracking_id")):
                    line = line.strip()
                    items = line.split("\t")
                    
                    if (len(gene_list[items[0]]) == (i + 1)):
                        expressions = gene_list[items[0]]
                        if (expressions[i] < float(items[9])):
                            expressions[i] = float(items[9]) 
                            gene_list[items[0]] = expressions
                    else:
                        gene_list[items[0]].append(float(items[9]))

            input.close()

        return (gene_list)
        
    ## This function ...

    def get_zscores (self, gene_expressions):

        ZScores = dict ()

        for gene in (gene_expressions.keys()):
            ZScores[gene] = compute_ZScore(gene_expressions[gene])
        
        return (ZScores)

    ## This function ...

    def write_expression (self, file_name, developmental_stages, gene_expressions):

        output = file(file_name, "w")

        header = "\t".join(developmental_stages)
        header = "\t" + header
        
        output.write(header)
        output.write("\n")

        for gene in (gene_expressions.keys()):

            if (len(gene_expressions[gene]) != 0):
                gene_expression = "\t".join(float_to_string(gene_expressions[gene]))
                gene_expression = gene + "\t" + gene_expression
                output.write(gene_expression)
                output.write("\n")
            else:
                del gene_expressions[gene]
        
        output.close()
        
        return (gene_expressions)

    ## This function ...

    def get_gene_collections (self, sample_index, upper_threshold, lower_threshold, expression_values):

        positive_genes = []
        negative_genes = []

        for gene in (expression_values.keys()):
            expressions = expression_values[gene]
            if (expressions[sample_index] > upper_threshold):
                positive_genes.append(gene)
            if (expressions[sample_index] <= lower_threshold):
                negative_genes.append(gene)

        return (positive_genes, negative_genes)

    
    ## This function ...

    def save_variable (self, file_name, dictionary):
        
        file_handler = open(file_name, 'wb')
    
        pickle.dump(dictionary, file_handler)

    ## This function ...

    def load_variable (self, file_name):
        
        file_handler = open(file_name,'rb')
        dictionary = pickle.load(file_handler)

        return (dictionary)

    ## This function ...

    def write_genes (self, file_name, gene_list):

        output = file(file_name, "w")

        gene_string = "\t".join(gene_list)
    
        output.write(gene_string)
        
        output.close()
