##############################################################################################
## Laboratory of Functional Analysis in silico                                              ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo               ##
## Programmed by Yosvany Lopez Alvarez                                       November, 2014 ##
##############################################################################################

#!/usr/local/bin/python

from handler import *

########################################################################################################

GTF_file = ""  ## GTF file of Drosophila melanogaster (just to extract gene ids)

developmental_stages = [] ## list containing a short description of each developmental stage

gene_expression_files = ["./stage_01/cufflinks/genes.fpkm_tracking",
                         "./stage_02/cufflinks/genes.fpkm_tracking",
                         "./stage_03/cufflinks/genes.fpkm_tracking",
                         "./stage_04/cufflinks/genes.fpkm_tracking",
                         "./stage_05/cufflinks/genes.fpkm_tracking",
                         "./stage_06/cufflinks/genes.fpkm_tracking",
                         "./stage_07/cufflinks/genes.fpkm_tracking",
                         "./stage_08/cufflinks/genes.fpkm_tracking",
                         "./stage_09/cufflinks/genes.fpkm_tracking",
                         "./stage_10/cufflinks/genes.fpkm_tracking",
                         "./stage_11/cufflinks/genes.fpkm_tracking",
                         "./stage_12/cufflinks/genes.fpkm_tracking",
                         "./stage_13/cufflinks/genes.fpkm_tracking",
                         "./stage_14/cufflinks/genes.fpkm_tracking",
                         "./stage_15/cufflinks/genes.fpkm_tracking",
                         "./stage_16/cufflinks/genes.fpkm_tracking",
                         "./stage_17/cufflinks/genes.fpkm_tracking",
                         "./stage_18/cufflinks/genes.fpkm_tracking",
                         "./stage_19/cufflinks/genes.fpkm_tracking",
                         "./stage_20/cufflinks/genes.fpkm_tracking",
                         "./stage_21/cufflinks/genes.fpkm_tracking",
                         "./stage_22/cufflinks/genes.fpkm_tracking",
                         "./stage_23/cufflinks/genes.fpkm_tracking",
                         "./stage_24/cufflinks/genes.fpkm_tracking",
                         "./stage_25/cufflinks/genes.fpkm_tracking"]

FPKM_file = "./dmel_development/fpkm.txt"

FPKM_saved_file = "./dmel_development/fpkm.info"

########################################################################################################

handler_object = handler ()   

gene_list = handler_object.extract_gene_id(GTF_file)
 
fpkm_values = handler_object.get_gene_expression(gene_list, gene_expression_files)
fpkm_values = handler_object.write_expression(FPKM_file, developmental_stages, fpkm_values)
handler_object.save_variable(FPKM_saved_file, fpkm_values)

########################################################################################################
