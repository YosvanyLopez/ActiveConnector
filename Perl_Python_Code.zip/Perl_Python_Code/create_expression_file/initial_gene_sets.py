##############################################################################################
## Laboratory of Functional Analysis in silico                                              ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo               ##
## Programmed by Yosvany Lopez Alvarez                                       November, 2014 ##
##############################################################################################

#!/usr/local/bin/python

from handler import *
from sets import Set

##############################################################################################

transcript_file = "./dmel_development/all_genes.txt"

FPKM_saved_file = "./dmel_development/fpkm.info"

positive_gene_file = "./dmel_development/stage_01/initial_set.txt" ## number of the stage is changed manually

negative_gene_file = "./dmel_development/stage_01/control_set.txt" ## number of the stage is changed manually

##############################################################################################

handler_object = handler ()

fpkm_values = handler_object.load_variable(FPKM_saved_file)

(fpkm_positive, fpkm_negative) = handler_object.get_gene_collections(0, 1, 0, fpkm_values) ## index of the stage is changed manually 

Input = open(transcript_file, "r")
lines = Input.readlines()
gene_line = lines[0].strip()
transcripts = Set(gene_line.split("\t"))
Input.close()

expressed_genes = Set(fpkm_positive)
expressed_genes = list(expressed_genes & transcripts)

nonexpressed_genes = Set(fpkm_negative)
nonexpressed_genes = list(nonexpressed_genes & transcripts)

handler_object.write_genes(positive_gene_file, expressed_genes)
handler_object.write_genes(negative_gene_file, nonexpressed_genes)

#######################################################################################################

