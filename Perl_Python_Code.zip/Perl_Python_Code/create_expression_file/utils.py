######################################################################################
## Laboratory of Functional Analysis in silico                                      ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo       ##
## Programmed by Yosvany Lopez Alvarez                               November, 2014 ##
######################################################################################

## This function computes the average of a numeric list.

def average (List):

    AVG = sum(List)/len(List)
    
    return (AVG)

## This function computes the standard deviation of a numeric list.

def stdeviation (List):

    nList = []

    AVG = average(List)

    for item in List:
        nList.append(pow((item - AVG),2))

    STD = pow((sum(nList)/(len(nList) - 1)), 0.5)

    return (STD)

## This function ....

def compute_ZScore (List):

    ZScores = []

    AVG = average(List)
    STD = stdeviation(List)

    for i in range(0, len(List)):
        zscore = 0
        if (STD != 0):
            zscore = (List[i] - AVG)/STD
        ZScores.append(zscore)
            
    return (ZScores)

## This function ....
                                                                                                                                                                       
def string_to_float (List):

    new_list = map(float, List)

    return (new_list)
    
## This function ....
    
def float_to_string (List):

    new_list = map(str, List)

    return (new_list)
