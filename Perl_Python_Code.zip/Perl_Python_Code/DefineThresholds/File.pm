##############################################################################################
## This package contains the class "File", which groups those functions related to the      ##
## reading and writing of information from/into external data files.                        ##
##                                                                                          ##
## Laboratory of Functional Analysis in silico                                              ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo               ##
## Programmed by Yosvany Lopez Alvarez                                       November, 2011 ##
##############################################################################################

package File;

use warnings;
use strict;
use Utils;
use Storable;
use Storable qw(dclone);

## This function stands for the class' constructor.

sub new {

    my $self = {};

    bless($self);
       
    return ($self);
}


## This function receives the name of a file containing all the Transcription Factors (TFs) be
## used for scanning the promoter regions. Lastly, it returns a hash whose "keys" and "values" 
## are integer indices and string lists composed of each TF's Position Frequency Matrix (PFM).

sub MotifFileReader {

    my ($self, $FileName) = @_;

    my $Line = '';

    my @Rows;
    my %FrequencyMatrices = ();    
    my $Flag = 0;
    my $Count = 1;
    
    my $motif_identifier = '';

    open(INPUT, $FileName);

    while ($Line = <INPUT>) {

	$Line = Utils::Trim($Line);

	if (($Line =~ /^D/) || ($Line =~ /^M/))  {

	    $motif_identifier = $Line;

	}

	if ($Line =~ m/<BEGIN>/) {
	    $Flag = 1;
	    @Rows = ();
	} elsif ($Line =~ m/<END>/) {
	    $Flag = 0;
	    $FrequencyMatrices{$motif_identifier} = dclone(\@Rows);
	    $Count++;	  
	} elsif ($Flag) {
	    push (@Rows, $Line);
	}
    }

    close(INPUT);	

    return (%FrequencyMatrices)
}


## This function receives the name of a file containing all the promoter sequences to be scanned 
## in FASTA format. Thereafter, it returns two parameters: (1) the reference to a list comprising 
## the file lines, and (2) a list composed of the indices of each FASTA sequence's header within
## the line list.

sub PromoterFileReader {

    my ($self, $FileName) = @_;

    open(INPUT, $FileName);

    my @Lines = <INPUT>;

    my @Indices = ();

    my $i = 0;
    while ($i <= scalar(@Lines) - 1) {

	if ($Lines[$i] =~ /^>/) {
	    push (@Indices, $i);
	}

	$i++;
    }
    
    push (@Indices, scalar(@Lines));

    close (INPUT);

    return (\@Lines, @Indices)
}


## This function receives the name of a file containing all the promoter sequences to be scanned
## in FASTA format. Finally, two parameters: (1) the reference to a hash whose "keys" and "values"
## are integer indices as well as the name of the gene each promoter region belongs to, and 
## (2) another hash whose "keys" are also integer indices, but whose "values" are different promoter
## sequences are returned.

sub GetPromoterInfo {
    
    my ($self, $FileName) = @_;

    my ($ref_Lines, @Indices) = $self -> PromoterFileReader($FileName);
    
    my @Lines = @{$ref_Lines};

    my (%GeneNameHash, %PromoterHash) = ();

    my $i = 0;
    while ($i <= scalar(@Indices) - 2) {

	my @Values = Utils::SplitString('\|', $Lines[$Indices[$i]]);
	$GeneNameHash{$i + 1} = $Values[1];	
	$PromoterHash{$i + 1} = Utils::GetSequenceFromList($Indices[$i], $Indices[$i + 1], @Lines);

	$i++;
    }

    return (\%GeneNameHash, %PromoterHash);
}

## This function receives two parameters: (1) a file name, and (2) any hash. Afterwards, the hash 
## as well as all its information is written into the external file.

sub Save {

    my ($self, $FileName, %Data) = @_;

    store(\%Data, $FileName);
}


## This function receives an external file, and returns the hash stored inside it.

sub Recover {

    my ($self, $ExternalFile) = @_;

    my $DataHash = retrieve($ExternalFile);

    return (%{$DataHash})
}


## This function receives three parameters: (1) handler of the file where the information
## will be written, (2) pattern's identifier, and (3) hash standing for the Position 
## Frequency Matrix (PFM) whose "keys" and "values" are DNA nucleotides ('A'-'C'-'G'-'T') 
## as well as lists composed of their respective amounts. Lastly, such a PFM is written 
## into an external file.

sub PositionMatrixWriter {

    my ($self, $FileHandler, $Index, %PositionMatrix) = @_;

    print($FileHandler "Motif_" . $Index);
    print($FileHandler "\n");
    print($FileHandler "<BEGIN>");
    print($FileHandler "\n");

    my @NucleotideList = sort(keys(%PositionMatrix));

    foreach my $Nucleotide (@NucleotideList) {

	my @ReversedRow = reverse(@{$PositionMatrix{$Nucleotide}});
	push(@ReversedRow, $Nucleotide);
	my $Sequence = join("\t", reverse(@ReversedRow));

	print ($FileHandler $Sequence);
	print ($FileHandler "\n");
    }

    print ($FileHandler "<END>");
    print ($FileHandler "\n");
    print ($FileHandler "\n");
}


## This function receives two parameters: (1) output file name, and (2) hash whose "keys"
## and "values" are pattern's identifiers as well as other hashes standing for PFMs. Finally, 
## such information is thoroughly written into the typed file.

sub WriterOfAll {

    my ($self, $OutputFile, %PatternData) = @_;

    my $Output;
    open($Output, ">$OutputFile");

    print ($Output '****** TRANSCRIPTION FACTORS *******' . "\n");
    print ($Output "\n");

    my @PatternIdentifiers = sort(keys(%PatternData));

    foreach my $PatternIdentifier (@PatternIdentifiers) {

	$self -> PositionMatrixWriter($Output, $PatternIdentifier, %{$PatternData{$PatternIdentifier}});
    }
    
    close ($Output);
}


1;
