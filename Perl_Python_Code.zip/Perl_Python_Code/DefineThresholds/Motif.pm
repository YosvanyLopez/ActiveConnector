##########################################################################################
## This package contains the class "Motif" that comprises the properties of one specific##
## motif such as its identifier, Position Frequency Matrix (PFM) and Position Weight    ##
## Matrix (PWM). Additionally, it carries out other functions related to the scanning   ##
## of promoters for detecting potential binding sites (BSs).                            ## 
##                                                                                      ## 
## Laboratory of Functional Analysis in silico                                          ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo           ##
## Programmed by Yosvany Lopez Alvarez                                   November, 2011 ##
##########################################################################################

package Motif;

use warnings;
use strict;
use Utils;
use Math;

## This function stands for the class' constructor. It has three attributes related to a 
## TF: (1) name or identifier, (2) PFM, and (3) PWM. Then, each created instance will be 
## composed of these fields. 

sub new {

    my $self = {};

    $self -> {NAME} = undef;    
    $self -> {FREQUENCYMATRIX} = undef;
    $self -> {WEIGHTMATRIX} = undef;
    bless($self);
       
    return ($self)
}


## This function receives a TF's name, and accordingly updates the attribute "NAME".

sub setName {

    my ($self, $Name) = @_;

    $self -> {NAME} = $Name
}


## This function returns the value stored in the attribute "NAME".

sub getName {

    my ($self) = @_;

    return ($self -> {NAME})
}


## This function receives two parameters: (1) a TF's name, and (2) a matrix. Afterwards,
## the attribute "FREQUENCYMATRIX" is updated, whereas the number of sites is returned.

sub setFrequencyMatrix {

    my ($self, $Name, @Matrix) = @_;

    $self -> setName($Name);

    my $SiteNumber = 0;

    my $i = 0;
    while ($i <= scalar(@Matrix) - 1) {

	my @Items = split("\t", Utils::Trim($Matrix[$i]));
	my $FirstItem = shift(@Items);	
	
	${$self -> {FREQUENCYMATRIX}}{$FirstItem} = \@Items;
	$SiteNumber += ${$self -> {FREQUENCYMATRIX}}{$FirstItem}[0];

	$i++;
    }

    return ($SiteNumber)
}


## This function returns the PFM stored in the attribute "FREQUENCYMATRIX".

sub getFrequencyMatrix {

    my ($self) = @_;

    return (%{$self -> {FREQUENCYMATRIX}})
}


## This function receives a number of sites. Then, after computing the log-odd values the
## attribute "WEIGHTMATRIX" is updated.

sub setWeightMatrix {

    my ($self, $SiteNumber) = @_;

    %{$self -> {WEIGHTMATRIX}} = Math::ComputeLogOddRatioMatrix($SiteNumber, $self -> getFrequencyMatrix());
}


## This function returns the PWM stored in the attribute "WEIGHTMATRIX".

sub getWeightMatrix {

    my ($self) = @_;	

    return (%{$self -> {WEIGHTMATRIX}})
}


## This function receives two parameters: (1) a binding site, and (2) a PWM. Soon after, the 
## scoring of such a site is computed and duly returned.

sub ComputeBindingSiteScore {

    my ($self, $TFBS, %WeightMatrix) = @_;	

    my $Score = 0;

    my $i = 0;
    while ($i <= length($TFBS) - 1) {

	my $Base = substr($TFBS, $i, 1);

	if ($Base ne "N") {
	    my @MatrixRow = @{$WeightMatrix{$Base}};
	    $Score = $Score + $MatrixRow[$i]
	}

	$i++
    }

    return ($Score)    
}

## This function receives four parameters: (1) a nucleotide sequence, (2) a direction (orientation
## of the sequence being scanned), (3) a threshold, and (4) a PWM. Afterwards, such a sequence is 
## scanned for BSs whose scores are greater than the cutoff previously mentioned, and then a list 
## composed of each discovered BS' information is returned.

sub ScanWithoutOrientation {
    
    my ($self, $Sequence, %WeightMatrix) = @_;

    my @Scores = ();

    my $ProfileLength = scalar(@{$WeightMatrix{'A'}});

    my $i = 0;
    while ($i <= (length($Sequence) - $ProfileLength)) {
	
	my $PutativeSite = substr($Sequence, $i, $ProfileLength);
	my $Score = $self -> ComputeBindingSiteScore($PutativeSite, %WeightMatrix);
	push(@Scores, $Score);

	$i++
    }

    return (@Scores)
}


## This function receives two parameters: (1) a sequence, and (2) a threshold. Thereafter, both strands of 
## the sequence are scanned to find out potential TFBSs. Those sites successfully found are inserted into
## a list, which is finally returned.

sub ScanPromoter {

    my ($self, $Sequence) = @_;

    my %WeightMatrix = $self -> getWeightMatrix();
    
    my @Scores = ();

    my @ScoreSubsetPlus =  $self -> ScanWithoutOrientation($Sequence, %WeightMatrix);
    my $ComplementSequence = Utils::GetComplementSequence($Sequence);
    my @ScoreSubsetMinus = $self -> ScanWithoutOrientation($ComplementSequence, %WeightMatrix);

    @Scores = (@ScoreSubsetPlus, @ScoreSubsetMinus);

    return (@Scores)
}

## This function receives two parameters: (1) an object "TFCollection".                                                                                         
## Afterwards, each promoter is scanned and those TFBSs whose scores are greater than the                                                                              
## previous cutoff are chosen and returned within another hash whose "keys" and "values" are                                                                    
## the name of gene each regulatory region belongs to as well as the discovered TFBSs.                                                                                 

sub ScanPromoters {

    my ($self, %Promoters) = @_;

    my @PromoterIndices = keys(%Promoters);

    my @Scores = ();

    foreach my $PromoterIndex (@PromoterIndices) {
	
	my $Sequence = $Promoters{$PromoterIndex};
	my @ScoreOnePromoter = $self -> ScanPromoter($Sequence);
	
	@Scores = (@Scores, @ScoreOnePromoter)
    }
    
    @Scores = reverse(sort(@Scores));

    return (@Scores)
}

## This function sets the threshold ....
## Distance means 1 hit per distance ....

sub PlaceCutOff {

    my ($self, $Distance, @Scores) = @_;

    my $TotalDistance = $Distance * 2;    ## "2" stands for both DNA strands .... 

    my $SiteNumber = scalar(@Scores)/$TotalDistance;

    $SiteNumber = int($SiteNumber + 0.5);

    my $Threshold = $Scores[$SiteNumber - 1];

    return ($Threshold)
}

1;
