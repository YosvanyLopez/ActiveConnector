##########################################################################################
## This package contains the class "TFCollection", which collects those Transcription   ##
## Factors (TFs) being used to scan the promoters regions.                              ## 
##                                                                                      ## 
## Laboratory of Functional Analysis in silico                                          ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo           ##
## Programmed by Yosvany Lopez Alvarez                                   November, 2011 ##
##########################################################################################

package MotifCollection; 

use warnings;
use strict;
use Motif;

## This function represents the class' constructor. It contains a hash whose "keys" and 
## "values" are TF's identifiers and objects "TranscriptionFactor", respectively. Each 
## new instance will have the same information. 

sub new {

    my $self = {};

    %{$self -> {MOTIFS}} = ();
	
    bless($self);
    
    return ($self)
}

## This function receives a hash whose "keys" and "values" are TF's identifiers and string 
## lists that contain the Position Frequency Matrix (PFM) of every TF. Afterwards, each 
## object "TranscriptionFactor" is created and inserted into the collection of TFs stored 
## in the attribute "TRANSCRIPTIONFACTORS".

sub UpdateMotifCollection {

    my ($self, %MotifInformation) = @_;

    my @MotifIndices = keys(%MotifInformation);

    foreach my $MotifIndex (@MotifIndices) {

	my $MotifObject = new Motif ();

	my $SiteNumber = $MotifObject -> setFrequencyMatrix($MotifIndex, @{$MotifInformation{$MotifIndex}});

	$MotifObject -> setWeightMatrix($SiteNumber);

	${$self -> {MOTIFS}}{$MotifIndex} = $MotifObject
    }
}

## This function returns the collection of motifs stored in the attribute "MOTIFS".

sub getMotifCollection {
 
    my ($self) = @_;
    
    return (%{$self -> {MOTIFS}})
}

## This function ....

sub GetThresholdPerMotif {
    
    my ($self, $Distance, %Promoters) = @_;

    my %MotifCollection = $self -> getMotifCollection();

    my @MotifNames = keys(%MotifCollection);
    
    my %Thresholds = ();

    foreach my $Motif (@MotifNames) {
	
	my @Scores = $MotifCollection{$Motif} -> ScanPromoters(%Promoters);
	my $Threshold = $MotifCollection{$Motif} -> PlaceCutOff($Distance, @Scores);
	$Thresholds{$Motif} = $Threshold
    }

    return (%Thresholds)
}

## This function returns a hash whose "keys" and "values" are motif's identifiers as well as their
## respective PFMs.

sub GetPFMatrices {

    my ($self) = @_;

    my %PFMatrices = ();

    my %MotifCollection = $self -> getMotifCollection();

    my @Indices = sort(keys(%MotifCollection));

    foreach my $Index (@Indices) {

	my $Identifier = $MotifCollection{$Index} -> getName();
	my %PositionMatrix = $MotifCollection{$Index} -> getFrequencyMatrix(); 

	$PFMatrices{$Identifier} = \%PositionMatrix;
    }

    return (%PFMatrices)   
}

1;
