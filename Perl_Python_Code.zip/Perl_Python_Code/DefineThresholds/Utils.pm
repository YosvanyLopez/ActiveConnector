########################################################################################
## This package contains simple functions whose aim is the treatment of strings to    ##
## reduce the complexity of the code lines.                                           ##
##                                                                                    ##
## Laboratory of Functional Analysis in silico                                        ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo         ##
## Programmed by Yosvany Lopez Alvarez                                 November, 2011 ##
########################################################################################     

package Utils;

use warnings;
use strict;

## This function receives two parameters: (1) a character to be used as splitter, and 
## (2) a string. Afterwards, a list composed of small substrings is returned.

sub SplitString {

    my ($Character, $String) = @_;

    my @List = split($Character, $String);

    return (@List)
}


## This function receives a DNA sequence (5'end ------------> 3'end) and returns its  
## complement sequence in the same direction (5'end ------------> 3'end).

sub GetComplementSequence {

   my ($Sequence) = @_;

   ($Sequence =~ tr/AGCTURYKMSWBVDHN/TCGAAYRMKSWVBHDN/);
   ($Sequence =~ tr/agcturykmswbvdhn/tcgaayrmkswvbhdn/);
   ($Sequence =~ tr/\-//);
   
   my $Complement = reverse($Sequence);
   
   return ($Complement)
}


## This function receives three parameters: (1) & (2) are two different indices, and 
## (3) a list of strings. Lastly, those strings from the first index plus 1 to the second 
## index minus 1 are copied from the string list and returned as a single sequence.

sub GetSequenceFromList {
    
    my ($Start, $End, @List) = @_;
    
    my @Strings = ();

    my $i = $Start + 1;
    while ($i <= $End - 1) {
	push(@Strings, $List[$i]);	
	$i++;
    }

    return (Concatenate(@Strings))
}


## This function receives a list of strings and returns their concatenation as a single
## sequence.

sub Concatenate {

    my (@List) = @_;

    my $Sequence = '';

    foreach my $String (@List) {
	$Sequence .= Trim($String);
    }

    return ($Sequence)
}


## This function receives a sequence and returns a new one without whitespaces in both extremes.

sub Trim {

    my ($Sequence) = @_;

    $Sequence =~ s/^\s+//;
    $Sequence =~ s/\s+$//;
   
    return ($Sequence)
}


1;
