#################################################################################################
## This script calls distinct functions from three different packages: "PromoterCollection",   ##
## "File" and "MotifCollection".                                                               ##
## Its programming was based on the following reference:                                       ##
## "Wasserman W. & Sandelin A., Applied bioinformatics for the identification of regulatory    ##
## elements, Nature Reviews Genetics (2004), 5, 276-287".                                      ##
##                                                                                             ##
## Laboratory of Functional Analysis in silico                                                 ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo                  ##
## Programmed by Yosvany Lopez Alvarez                                          November, 2011 ##
#################################################################################################

#!/usr/local/bin/perl

use warnings;
use strict;
use File;
use MotifCollection;

##################################################################################################
## This script receives a distance to determine how many putative sites will be regarded for a   #
## good threshold per motif                                                                      #
##################################################################################################

my $MotifFile = ''; ## file of motif matrices

my $PromoterFile = ''; ## file of random promoter sequences in fasta format

my $NFMatrixFile = ''; ## file to save motif matrices

my $ThresholdFile = ''; ## threshold file where thresholds will be saved

#################################################################################################

my $FileObject = new File ();
my %FrequencyMatrices = $FileObject -> MotifFileReader($MotifFile);

my ($ref_GeneNames, %Promoters) = $FileObject -> GetPromoterInfo($PromoterFile);

my $MotifCollectionObject = new MotifCollection ();
$MotifCollectionObject -> UpdateMotifCollection(%FrequencyMatrices);
my %Thresholds = $MotifCollectionObject -> GetThresholdPerMotif($ARGV[0], %Promoters);
my %PFMatrices = $MotifCollectionObject -> GetPFMatrices();

$FileObject -> Save($NFMatrixFile, %PFMatrices);
$FileObject -> Save($ThresholdFile, %Thresholds);

#################################################################################################
