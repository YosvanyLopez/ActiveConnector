########################################################################################
## Laboratory of Functional Analysis in silico                                        ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo         ##
## Programmed by Yosvany Lopez Alvarez                                September, 2011 ##
########################################################################################

import pickle
from sets import Set

class File:

    def FileReader (self, FileName):

        Input = open(FileName, "r")

        MatchingList = Input.readlines()
        
        Head = MatchingList.pop(0)
           
        Input.closed

        return (MatchingList)
    
    def RetrieveNFM (self, FileName):

        NFMatrices = pickle.load(open(FileName, 'r'))
        
        return (NFMatrices)

    def PositionMatrixWriter (self, FileHandler, Index, PositionMatrix):

        FileHandler.write(str(Index))
        FileHandler.write("\n")
        FileHandler.write("<BEGIN>")
        FileHandler.write("\n")
        
        NucleotideList = ['A', 'C', 'G', 'T']

        ReversedNFMatrix = zip(*PositionMatrix)
        
        i = 0
        while (i <= len(NucleotideList) - 1):
            
            Sequence = NucleotideList[i] + "\t" + "\t".join(self.IntegerToString(list(ReversedNFMatrix[i])))
            FileHandler.write(Sequence)                                                                                                                                                                                                                                      
            FileHandler.write("\n")  
                        
            i += 1
            
        FileHandler.write("<END>")
        FileHandler.write("\n")
        FileHandler.write("\n")

    def WriterOfAll (self, OutputFile, PatternData):
      
        Output = file(OutputFile, "w")
        
        Output.write('****** TRANSCRIPTION FACTORS *******' + "\n")
        Output.write("\n")

        PatternIdentifiers = PatternData.keys()

        PatternIdentifiers.sort()
        
        for PatternIdentifier in PatternIdentifiers:

            self.PositionMatrixWriter(Output, PatternIdentifier, PatternData[PatternIdentifier])
        
        Output.close()

    def IntegerToString (self, List):

        NewList = map(str, List)

        return (NewList)
