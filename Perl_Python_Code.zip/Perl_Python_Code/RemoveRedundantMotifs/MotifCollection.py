#########################################################################################
## Laboratory of Functional Analysis in silico                                         ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo          ##
## Programmed by Yosvany Lopez Alvarez                                 September, 2012 ##
#########################################################################################

class MotifCollection:

    def SelectPoorMotifs (self, Threshold, List, IContentList):
    
        PoorMotifs = dict ()
    
        for Comparison in List:
            Comparison = Comparison.strip()
            Items = Comparison.split("\t")
            Motif1 = Items[0]        
            Motif2 = Items[1]
            PValue = Items[3]

            if ((float(PValue) <= Threshold) & (Motif1 != Motif2)):

                if ((Motif1.startswith('D') & Motif2.startswith('D')) | (Motif1.startswith('M') & Motif2.startswith('M'))):
                    ICMotif1 = IContentList[Motif1]
                    ICMotif2 = IContentList[Motif2]

                    if (ICMotif1 < ICMotif2):
                        PoorMotifs[Motif1] = 1
                    else:
                        PoorMotifs[Motif2] = 1

                elif (Motif1.startswith('M') & Motif2.startswith('D')):
                    PoorMotifs[Motif2] = 1
                elif (Motif1.startswith('D') & Motif2.startswith('M')):
                    PoorMotifs[Motif1] = 1
        
        return (PoorMotifs)

    def GetBestMotifs (self, BestMotifs, PoorMotifs):

        MotifIDs = PoorMotifs.keys()
    
        for MotifID in MotifIDs:
            del(BestMotifs[MotifID])

        return (BestMotifs)
