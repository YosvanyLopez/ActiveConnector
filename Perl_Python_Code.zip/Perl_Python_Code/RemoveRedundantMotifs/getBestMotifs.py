#################################################################################################
## Laboratory of Functional Analysis in silico                                                 ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo                  ##
## Programmed by Yosvany Lopez Alvarez                                           October, 2012 ##
#################################################################################################

#!/usr/local/bin/python

from File import *
from MotifCollection import *
import sys

#################################################################################################

TOMTOMFile = './dmel_development/stage_' + str(sys.argv[1]) + '/motif_prediction/tomtom/tomtom.txt'

NFMatrixFile = './dmel_development/stage_' + str(sys.argv[1]) + '/motif_prediction/pfmatrices.info'

IContentFile = './dmel_development/stage_' + str(sys.argv[1]) + '/motif_prediction/icontent.info'

BestMotifFile = './dmel_development/stage_' + str(sys.argv[1]) + '/motif_prediction/remaining_motifs.txt'

#################################################################################################

FileObject = File ()
ComparisonList = FileObject.FileReader(TOMTOMFile)
NFMatrices = FileObject.RetrieveNFM(NFMatrixFile)
IContentDict = FileObject.RetrieveNFM(IContentFile)

MotifSetObject = MotifCollection ()
PoorMotifs = MotifSetObject.SelectPoorMotifs(0.001, ComparisonList, IContentDict)

NewNPMatrices = MotifSetObject.GetBestMotifs(NFMatrices, PoorMotifs)

FileObject.WriterOfAll(BestMotifFile, NewNPMatrices)

################################################################################################
