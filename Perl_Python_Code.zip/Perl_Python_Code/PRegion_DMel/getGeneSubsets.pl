##########################################################################################
## Laboratory of Functional Analysis in silico                                          ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo           ##
## Programmed by Yosvany Lopez Alvarez                                   January, 2014  ##
##########################################################################################

#!/usr/local/bin/perl

use warnings;
use strict;
use File;

##########################################################################################

my $geneNameFile = ""; ## all the genes in initial set

my $motifPredictionFile = ""; ## file to save genes of the motif prediction set

my $featureGenerationFile = ""; ## file to save genes of the feature generation set

my $modelBuildFile = ""; ## file to save genes of the model build set

##########################################################################################

my $fileObject = new File (); 
my @geneList = $fileObject -> geneFileReader($geneNameFile); 

sub getGeneSubset {

    my ($geneNumber, @geneList) = @_;

    my @geneSubset = ();

    for (my $i = 1; $i <= $geneNumber; $i++) {
	
	my $randomNumber = int(rand(scalar(@geneList)));
	push(@geneSubset, $geneList[$randomNumber]);

	splice(@geneList, $randomNumber, 1);
    }
    
    return (\@geneSubset, @geneList)
}

my $geneNumber_40Percent = int((scalar(@geneList) * 0.40) + 0.5); 
my $geneNumber_20Percent = int((scalar(@geneList) * 0.20) + 0.5);

my ($ref_motifPredictionSet, @remainingGenes) = getGeneSubset($geneNumber_40Percent, @geneList);
my ($ref_featureGenerationSet, @modelBuildSet) = getGeneSubset($geneNumber_20Percent, @remainingGenes); 

my @motifPredictionSet = @{$ref_motifPredictionSet};
my @featureGenerationSet = @{$ref_featureGenerationSet};

$fileObject -> geneNameWriter($motifPredictionFile, @motifPredictionSet);
$fileObject -> geneNameWriter($featureGenerationFile, @featureGenerationSet);  
$fileObject -> geneNameWriter($modelBuildFile, @modelBuildSet);

##########################################################################################
