########################################################################################
## This package contains the "Chromosome" class which groups all the functions        ##
## directed to handling the information of each chromosome.                           ##
##                                                                                    ##
## Laboratory of Functional Analysis in silico                                        ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo         ##
## Programmed by Yosvany Lopez Alvarez                                 February, 2011 ##
########################################################################################

package chromosome;

use strict;
use warnings;


## This function stands for this class' constructor. Each chromosome contains four  
## attributes: (1) and (2) initial and final positions, (3) the DNA sequence; and
## (4) a list composed of the genes within the chromosome.

sub constructor {

    my $self  = {};

    $self -> {INITIAL_POSITION} = undef;
    $self -> {FINAL_POSITION} = undef;
    $self -> {SEQUENCE} = undef;
    %{$self -> {GENES}} = ();
    bless($self);
       
    return ($self);
}


## This function receives the initial position of the chromosome, and sets this value into
## the "INITIAL_POSITION" attribute.

sub setInitialPosition {

    my ($self, $aValue) = @_;

    $self -> {INITIAL_POSITION} = $aValue;
}


## This function returns the value stored in the "INITIAL_POSITION" attribute.

sub getInitialPosition {

    my $self = shift;

    return ($self -> {INITIAL_POSITION});
}


## This function receives the final position of the chromosome, and sets this value into
## the "FINAL_POSITION" attribute. 

sub setFinalPosition {

    my ($self, $aValue) = @_;

    $self -> {FINAL_POSITION} = $aValue;
}


## This function returns the value stored in the "FINAL_POSITION" attribute.

sub getFinalPosition {

    my $self = shift;
    
    return ($self -> {FINAL_POSITION});
}


## This function receives the DNA sequence of the chromosome, and sets this one into 
## the "SEQUENCE" attribute.

sub setSequence {

    my ($self, $aSequence) = @_;

    $self -> {SEQUENCE} = $aSequence;
}


## This function returns the DNA sequence stored in the "SEQUENCE" attribute.

sub getSequence {

    my $self = shift;

    return ($self -> {SEQUENCE});
}


## This function receives two parameters: (1) a gene identifier, and (2) the "Gene" instance. 
## Thereafter the attribute "GENES" is updated.

sub updateGeneHash {

    my ($self, $gene_id, $gene_object) = @_;

    ${$self -> {GENES}}{$gene_id} = $gene_object
}

## This function returns all the "Gene" instances within the attribute "GENES".

sub getGeneHash {

    my ($self) = @_;

    return (%{$self -> {GENES}});
}


1;
