#########################################################################################
## This package contains the "PromoterRegion" class which groups all the functions     ##
## directed to working on the promoter regions of each gene.                           ##
##                                                                                     ##
## Laboratory of Functional Analysis in silico                                         ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo          ##
## Programmed by Yosvany Lopez Alvarez                                  February, 2011 ##
#########################################################################################

package promoter;

use strict;
use warnings;
use Utils;
use gene;
use chromosome;

## This function stands for this class' constructor.

sub new {

    my $self = {};

    bless($self);
       
    return ($self);
}

## This function receives four parameters: (1) the gene identifier, (2) and (3) the lengths of 
## the upstream and downstream regions to be extracted, and (4) a hash containing the karyotype
## whose "keys" and "values" are the chromosome identifier and instances of the "Chromosome" 
## class, respectively. Thereafter, two values: (1) a line with the gene information and 
## (2) the desired promoter region are returned.

sub getPromoterRegions {

    my ($self, $GeneID, $Upstream, $Downstream, %Karyotype) = @_;

    my $GeneDescription = '';
    my $PromoterRegion = '';

    my @Information = $self -> getGeneInfo($GeneID, %Karyotype);

    if (scalar(@Information) != 0) {

	my $Chromosome = $Information[0];
	my $InitialPos = $Information[2];
	my $FinalPos = $Information[3];
	my $Orientation = $Information[4];

	my $DNASequence = $Karyotype{$Chromosome} -> getSequence ();

	my ($UpstreamR, $DownstreamR, $NewInitial, $NewFinal); 
	
	if ($Orientation eq "+") {
	    $UpstreamR = substr ($DNASequence, ($InitialPos - $Upstream), $Upstream);
	    $DownstreamR = substr($DNASequence, $InitialPos, $Downstream);
	    $PromoterRegion = $UpstreamR . $DownstreamR;

	    $NewInitial = $InitialPos - $Upstream + 1;
	    $NewFinal = $InitialPos + $Downstream

	} elsif ($Orientation eq "-") {

	    $DNASequence = Utils::GetComplementSequence($DNASequence);
	    
	    $UpstreamR = substr ($DNASequence, $FinalPos - 1, $Upstream);
	    $DownstreamR = substr ($DNASequence, ($FinalPos - $Downstream) - 1, $Downstream);
	    $PromoterRegion = $DownstreamR . $UpstreamR;

	    $PromoterRegion = reverse($PromoterRegion);

	    $NewInitial = $FinalPos - $Downstream;
	    $NewFinal = $FinalPos + $Upstream - 1;
	}

	$Information[2] = $NewInitial;
	$Information[3] = $NewFinal;

	$GeneDescription = Utils::ListToSequence("|", @Information);
        $GeneDescription = '>' . $GeneDescription	
    } else {
	print $GeneID;
	print "\n";
}
    
    return ($GeneDescription, $PromoterRegion)
}

## This function ....

sub getGeneInfo {

    my ($self, $GeneID, %Karyotype) = @_;

    my @Chromosomes = keys(%Karyotype);

    my @Information = ();    

    foreach my $Chr (@Chromosomes) {

	my %Genes = $Karyotype{$Chr} -> getGeneHash();
	
	if (exists $Genes{$GeneID}) {

	    push(@Information, $Chr);
	    push(@Information, $GeneID);
		
	    my $InitialPos = $Genes{$GeneID} -> getInitialPosition();
	    push(@Information, $InitialPos);
	    my $FinalPos = $Genes{$GeneID} -> getFinalPosition();
	    push(@Information, $FinalPos);
	    my $Direction = $Genes{$GeneID} -> getDirection();
	    push(@Information, $Direction)
	}
    }
    
    return (@Information)
}

## This function receives four parameters: (1) and (2) the lengths of the upstream and 
## downstream regions, (3) the reference to a gene list, and (4) a hash containing the
## karyotype whose "keys" and "values" are the chromosome identifier and the instances
## of the "Chromosome" class. Thereafter, two values: (1) the reference to a hash whose
## "keys" and "values" are the identifier and the information of each gene, and (2) a 
## hash whose "keys" and "values" are the gene identifiers and the respective promoter 
## regions are returned.

sub getGenePromoterRegion {

    my ($self, $Upstream, $Downstream, $ref_Genes, %Karyotype) = @_;

    my @Genes = @{$ref_Genes};

    my %GeneDescriptions = ();
    my %PromoterRegions = ();
    
    my $i = 0;
    while ($i <= scalar(@Genes) - 1) {

	my ($GeneDescription, $PromoterRegion) = $self -> getPromoterRegions 
	    ($Genes[$i], $Upstream, $Downstream, %Karyotype);

	if ($PromoterRegion ne '') {
	    $GeneDescriptions{$Genes[$i]} = $GeneDescription;
	    $PromoterRegions{$Genes[$i]} = $PromoterRegion;
	}

	$i++;
    }
    
    return (\%GeneDescriptions, %PromoterRegions);
}

1;
