#########################################################################################
## This package contains the "NonPromoterRegion" class which groups all the functions  ##
## directed to working on the promoter regions of each gene.                           ##
##                                                                                     ##
## Laboratory of Functional Analysis in silico                                         ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo          ##
## Programmed by Yosvany Lopez Alvarez                                  February, 2011 ##
#########################################################################################

package nonpromoter;

use strict;
use warnings;
use Utils;
use gene;
use chromosome;

## This function stands for this class' constructor.

sub new {

    my $self = {};

    bless($self);
       
    return ($self)
}

## This function receives four parameters: (1) the gene identifier, ... (4) a hash containing the karyotype
## whose "keys" and "values" are the chromosome identifier and instances of the "Chromosome" 
## class, respectively. Thereafter, two values: (1) a line with the gene information and 
## (2) the desired promoter region are returned.

sub getNonPromoterRegion {

    my ($self, $geneID, $lowerLimit, $upperLimit, %karyotype) = @_;

    my ($nonPromoterRegion, $newInitial, $newFinal);

    my @information = $self -> getGeneInfo($geneID, %karyotype);

    my $chromosome = $information[0];
    my $initialPos = $information[2];
    my $finalPos = $information[3];
    my $orientation = $information[4];
    
    my $DNASequence = $karyotype{$chromosome} -> getSequence();

    if ($orientation eq "+") {
	    
	$nonPromoterRegion = substr($DNASequence, ($initialPos + $lowerLimit - 1), ($upperLimit - $lowerLimit));
	
	$newInitial = $initialPos + $lowerLimit;
	$newFinal = $initialPos + $upperLimit - 1;   
	    
    } elsif ($orientation eq "-") {

	$nonPromoterRegion = substr($DNASequence, ($finalPos - $upperLimit), ($upperLimit - $lowerLimit));
	
	$nonPromoterRegion = reverse(Utils::GetComplementSequence($nonPromoterRegion));
	
	$newInitial = $finalPos - ($upperLimit - 1);
	$newFinal = $finalPos - $lowerLimit;
    }

    $information[2] = $newInitial;
    $information[3] = $newFinal;

    my $sequenceDescription = '>' . Utils::ListToSequence("|", @information);
      
    return ($sequenceDescription, $nonPromoterRegion)
}

## This function ....

sub getGeneInfo {

    my ($self, $geneID, %karyotype) = @_;

    my @chromosomes = keys(%karyotype);

    my @information = ();    

    foreach my $chr (@chromosomes) {

	my %genes = $karyotype{$chr} -> getGeneHash();

	if (exists $genes{$geneID}) {

	    push(@information, $chr);
	    push(@information, $geneID);
		
	    my $initialPos = $genes{$geneID} -> getInitialPosition();
	    push(@information, $initialPos);
	    my $finalPos = $genes{$geneID} -> getFinalPosition();
	    push(@information, $finalPos);
	    my $direction = $genes{$geneID} -> getDirection();
	    push(@information, $direction)
	}
    }
    
    return (@information)
}

## This function receives four parameters: (1) and (2) the lengths of the upstream and 
## downstream regions, (3) the reference to a gene list, and (4) a hash containing the
## karyotype whose "keys" and "values" are the chromosome identifier and the instances
## of the "Chromosome" class. Thereafter, two values: (1) the reference to a hash whose
## "keys" and "values" are the identifier and the information of each gene, and (2) a 
## hash whose "keys" and "values" are the gene identifiers and the respective promoter 
## regions are returned.

sub getNonPromoterRegions {

    my ($self, $lowerLimit, $upperLimit, $ref_genes, %karyotype) = @_;

    my @genes = @{$ref_genes};

    my %descriptions = ();
    my %nonPromoters = ();
    
    my $i = 0;
    while ($i <= scalar(@genes) - 1) {

	my ($description, $nonPromoter) = $self -> getNonPromoterRegion($genes[$i], $lowerLimit, $upperLimit, %karyotype);

	if ($nonPromoter ne '') {
	    $descriptions{$genes[$i]} = $description;
	    $nonPromoters{$genes[$i]} = $nonPromoter;
	}

	$i++
    }
    
    return (\%descriptions, %nonPromoters)
}

1;
