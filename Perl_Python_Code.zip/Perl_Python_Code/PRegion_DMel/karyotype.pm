#########################################################################################
## This package contains the "Karyotype" class which groups all the functions directed ##
## to handling a set of chromosomes.                                                   ##
##                                                                                     ##
## Laboratory of Functional Analysis in silico                                         ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo          ##
## Programmed by Yosvany Lopez Alvarez                                  February, 2011 ##
#########################################################################################

package karyotype;

use strict;
use warnings;
use Utils;
use gene;
use chromosome;

## This function stands for this class' constructor. Each instance contains an attribute 
## dubbed "CHROMOSOMES". 

sub constructor {

    my $self  = {};

    $self -> {CHROMOSOMES} = ();
    bless($self);
       
    return ($self)
}

## This function ...

sub setChromosomes {

    my ($self, %chrData) = @_;

    my @chrIDs = keys(%chrData);

    foreach (@chrIDs) {

	my $chromosome = constructor chromosome();
	$chromosome -> setInitialPosition(1);
	$chromosome -> setFinalPosition(length($chrData{$_}));
	$chromosome -> setSequence($chrData{$_});
	
	
	${$self -> {CHROMOSOMES}}{$_} = $chromosome
    }
}

## This function ...

sub get_gene_info {

    my ($self, $gene_info) = @_;

    my @items = split(";", $gene_info);

    my $sequence = $items[1];

    my $index_equal = index($sequence, "=");
    my $index_two_points = index($sequence, ":");

    my $chromosome = Utils::trim(substr($sequence, $index_equal + 1, ($index_two_points - $index_equal) - 1));

    my $gene_id = Utils::trim(substr($items[7], index($items[7], "=") + 1, (length($items[7]) - index($items[7], "=")) - 1));

##  my $gene_id = Utils::trim(substr($items[9], index($items[9], "=") + 1, (length($items[9]) - index($items[9], "=")) - 1));

    my $coordinates = substr($sequence, $index_two_points + 1, (length($sequence) - $index_two_points));

    $coordinates =~ tr/complementjoin())/ /;
    $coordinates =~ tr/./,/;

    my @positions = split(",", $coordinates);

    my @removed_spaces = ();
    foreach (@positions) { if ($_ ne '') { push(@removed_spaces, $_) } }

    @removed_spaces = sort(@removed_spaces);

    my ($orientation, $initial_position, $final_position);

    if (index($sequence, "complement") != -1) { $orientation = "-" } 
    else { $orientation = "+" }
	
    $initial_position = $removed_spaces[0];
    $final_position = $removed_spaces[scalar(@removed_spaces) - 1];
	    
    return ($gene_id, $chromosome, $orientation, Utils::trim($initial_position), Utils::trim($final_position))
}

## This function receives a list of sequences (chromosome and gene information sequences)
## and updates the attribute "CHROMOSOMES" with the respective values.

sub update_chromosomes {

    my ($self, @sequences) = @_;

    ## my %chr_id = map { $_ => 1 } ('X', 'Y', '2L', '2R', '3L', '3R', '4', 'mt');
    
    foreach (@sequences) {

	my ($gene_id, $chromosome, $orientation, $initial_pos, $final_pos) = $self -> get_gene_info($_);
	
	if ($chromosome eq "dmel_mitochondrion_genome") { $chromosome = "mt" }

	my $gene_object = constructor gene();
	$gene_object -> setInitialPosition($initial_pos);
	$gene_object -> setFinalPosition($final_pos);
	$gene_object -> setDirection($orientation);

	print $chromosome,"\n";
	
	
	my %genes = ${$self -> {CHROMOSOMES}}{$chromosome} -> getGeneHash();
	$gene_id = Utils::upperCase($gene_id);

	if (exists $genes{$gene_id}) {

	    my $strand = $genes{$gene_id} -> getDirection();
	    my $iposition = $genes{$gene_id} -> getInitialPosition();
	    my $fposition = $genes{$gene_id} -> getFinalPosition();

	    if ($strand eq "+") { 
		if ($iposition < $initial_pos) { 
		    $gene_object -> setInitialPosition($iposition);
		    $gene_object -> setFinalPosition($fposition)
		}
	    } else { 
		if ($fposition > $final_pos) { 
		    $gene_object -> setFinalPosition($fposition);
		    $gene_object -> setInitialPosition($iposition)
		} 
	    }
	}
	    
	${$self -> {CHROMOSOMES}}{$chromosome} -> updateGeneHash($gene_id, $gene_object)	
    }
}

## This function returns all the information about chromosomes and gene locations, which is 
## stored in the attribute "CHROMOSOMES".

sub getChromosomes {

    my ($self) = @_;

    return (%{$self -> {CHROMOSOMES}})
}

## This function ....

sub getGeneList {

    my ($self, %karyotype) = @_;

    my @chromosomes = keys(%karyotype);

    my @geneList = ();

    foreach my $chrID (@chromosomes) {

	my %genes = $karyotype{$chrID} -> getGeneHash();
	@geneList = (@geneList, keys(%genes))
    }

    return (@geneList)
}

1;
