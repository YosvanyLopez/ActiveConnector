##########################################################################################
## Laboratory of Functional Analysis in silico                                          ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo           ##
## Programmed by Yosvany Lopez Alvarez                                   November, 2014 ##
##########################################################################################

#!/usr/local/bin/perl

use warnings;
use strict;
use File;
use karyotype;
use Utils;

##########################################################################################

my $chromosome_file = ""; ## all chromosome sequences in fasta format

my $transcript_file = ""; ## transcript information and sequence in fasta format 

my $karyotype_file = ""; ## file to save TSS coordinates

my $gene_file = ""; ## file to save all the gene names

#########################################################################################

my $file_object = new File ();
my %chromosomes = $file_object -> chromosome_file_reader($chromosome_file);
my @sequences = $file_object -> file_reader($transcript_file);

my $karyotype_object = constructor karyotype();
$karyotype_object -> setChromosomes(%chromosomes);
$karyotype_object -> update_chromosomes(@sequences);

my %karyotype = $karyotype_object -> getChromosomes(); 

$file_object -> Save($karyotype_file, %karyotype);

my @gene_list = $karyotype_object -> getGeneList(%karyotype);

open(INPUT, ">$gene_file");

my $gene_line = join("\t", @gene_list);

## $gene_line =~ tr/GN/gn/;

print INPUT $gene_line;

close(INPUT);

##########################################################################################
