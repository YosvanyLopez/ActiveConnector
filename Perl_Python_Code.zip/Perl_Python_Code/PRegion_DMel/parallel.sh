#$ -cwd -S /bin/bash
#$ -l s_vmem=4G -l mem_req=4G
    
set -xue

perl promoter_regions.pl

echo done
