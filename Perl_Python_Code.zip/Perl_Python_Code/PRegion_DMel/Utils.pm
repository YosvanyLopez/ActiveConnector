########################################################################################
## This package comprises all functions which will be small utilities to help us in   ##
## our complex code lines.                                                            ##              
##                                                                                    ##
## Laboratory of Functional Analysis in silico                                        ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo         ##
## Programmed by Yosvany Lopez Alvarez                               November, 2010   ##
########################################################################################

package Utils;

use warnings;
use strict;


## This function receives a sequence whose whitespaces are removed in both extremes, 
## thereafter it returns a new sequence.

sub trim {

    my ($Sequence) = @_;

    $Sequence =~ s/^\s+//;
    $Sequence =~ s/\s+$//;
   
    return ($Sequence);
}

## This function ....

sub Split {

    my ($Char, $Sequence) = @_;

    my @Items = split($Char, $Sequence);

    return (@Items)
}

## This function receives a DNA sequence (5'end ------------> 3'end) and returns its
## complement sequence (3'end ------------> 5'end).
                                                                                                                                                                    
sub GetComplementSequence {

    my ($Sequence) = @_;

    ($Sequence =~ tr/AGCTURYKMSWBVDHN/TCGAAYRMKSWVBHDN/);
    ($Sequence =~ tr/agcturykmswbvdhn/tcgaayrmkswvbhdn/);
    ($Sequence =~ tr/\-//);
    
   return ($Sequence)
}

## This function receives two arguments: a pattern (first parameter) that is used to split 
## a string (second parameter), and returns a list composed of small substrings.  

sub SplitwithPattern {

    my ($Pattern, $Sequence) = @_; 

    my @Splits = split(/$Pattern/, $Sequence);

    return (@Splits);   
}

## This function receives the fragments of a string splitted by the "SplitwithPattern"
## subroutine, and returns all of them grouped in one array. In addition, each substring
## is upper case.

sub FragmentsToList_UpperCase {

    my (@Fragments) = @_;

    my @List = ();

    my $i = 0;   
    while ($i <= scalar(@Fragments) - 1) {
	push (@List, upperCase(trim($Fragments[$i])));
	$i++;
    }
    return (@List);
}


## This function receives the fragments of a string splitted by the "SplitwithPattern"
## subroutine, and returns all of them grouped in one array.

sub FragmentsToList {

    my (@Fragments) = @_;

    my @List = ();

    my $i = 0;   
    while ($i <= scalar(@Fragments) - 1) {
	push (@List, trim($Fragments[$i]));
	$i++;
    }
    return (@List);
}


## This function receives two parameters: (1) a string being used as separator, and 
## (2) a list of values which are concatenated by using the previous separator.
## Thereafter, a new sequence with the corresponding separations is returned.

sub ListToSequence {

    my ($Separator, @ValueList) = @_;

    my $Sequence = '';

    my $i = 0;
    while ($i <= scalar(@ValueList) - 1) {
	$Sequence .= $ValueList[$i] . $Separator;     
	$i++;
    }
    return (trim($Sequence));  
}


## This function receives two parameters: (1) an item to be searched and (2) a list of
## items, thereafter it returns the value "1" (if the item is found within the list) or
## the value "0" (otherwise).

sub Search_Item {

    my ($Item, @Item_List) = @_;

    my $flag = 0;
    
    my $i = 0;
    while (($i <= scalar(@Item_List) - 1) && ($flag != 1)) {
	if ($Item eq $Item_List[$i]) {
	    $flag = 1;    
	}
	$i++;
    }
    return ($flag);
}


## This function receives a sequence as parameter and returns this one in upper case.

sub upperCase {

    my ($Sequence) = @_;

    $Sequence =~ tr/a-z/A-Z/;

    return ($Sequence);
}


## This function receives three parameters: (1) a string, (2) the number of characters to be
## removed, and (3) the number of characters to be taken; thereafter a substring substracting 
## the character number from the beginning of the initial string is returned.

sub getSubstring {
    
    my ($String, $Offset, $Length) = @_;

    my $Substring = substr($String, $Offset, $Length);

    return ($Substring);
}


## This function receives three parameters: (1) a character string, (2) and (3) the initial and
## final positions of the substring to be extracted. After, the desired substring is returned.

sub getExactSubstring {
    
    my ($String, $InitialPos, $FinalPos) = @_;
    
    my $Substring = reverse ($String);
    $Substring = getSubstring($Substring, length($Substring) - $FinalPos);
    $Substring = reverse ($Substring);
    $Substring = getSubstring($Substring, $InitialPos);
    $Substring = trim($Substring);

    return ($Substring);
}


## This function receives a sequence and returns another sequence with a new line every 50 characters.

sub convertToFASTAFormat {
    
    my ($Sequence) = @_;

    $Sequence =~ s/([\w ]{1,60})/$1\n/g;

    return($Sequence);
}


## This function ....

sub GetRandomGenes {

    my ($Amount, @GeneList) = @_;

    my %GeneHash = ();

    my $Length = 0;

    do {
        my $Random_Number = int(rand(scalar(@GeneList)));

	$GeneHash{$GeneList[$Random_Number]} = 1;

        $Length = scalar(keys(%GeneHash));
    }
    until($Length == $Amount);

    my @RandomGeneList = keys(%GeneHash);

    return (@RandomGeneList)
}


## This function ....                                                                                                                                

sub GetNonSpecificGenes {

    my ($Amount, $ref_SpecificGenes, @GeneList) = @_;

    my %SpecificGenes = %{$ref_SpecificGenes};

    my %GeneHash = ();

    my $Length = 0;

    do {
        my $Random_Number = int(rand(scalar(@GeneList)));

        my $GeneName = $GeneList[$Random_Number];

        if (not exists $SpecificGenes{$GeneName}) { $GeneHash{$GeneName} = 1 }

        $Length = scalar(keys(%GeneHash))
    }
    until($Length == $Amount);

    my @NonSpecificGenes = keys(%GeneHash);

    return (@NonSpecificGenes)
}


1;
