#########################################################################################
## This package contains the "File" class which groups all the functions directed to   ##
## realizing operations of writing and reading into and from files.                    ##
##                                                                                     ##
## Laboratory of Functional Analysis in silico                                         ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo          ##
## Programmed by Yosvany Lopez Alvarez                                  February, 2011 ##
#########################################################################################

package File;

use strict;
use warnings;
use File::Basename;
use Utils;
use Storable;


## This is the constructor of the class.

sub new {

    my $self = {};

    bless($self);
       
    return ($self);
}


## This function receives the name of a file ...

sub TabSeparatedGeneReader {

    my ($self, $FileName) = @_;

    open(IN, $FileName);
    my @Sequences = <IN>;
    close(IN);

    my @Genes = Utils::Split("\t", $Sequences[0]);

    my %GeneHash = map {$_ => 1} @Genes;

    return (%GeneHash)
}


## This function receives the name of a file from which all the lines related to 
## chromosome or gene information are inserted into an output sequence list.

sub file_reader {

    my ($self, $file_name) = @_;

    my @sequences = ();
    
    open(IN, $file_name);
    
    while (my $line = <IN>) {
        if ($line =~ m/^>/) { push(@sequences, $line) }
    }

    close (IN);

    return (@sequences)
}

## This function receives the name of a file containing one chromosomal sequence, and
## returns this DNA sequence.

sub chromosome_file_reader {

    my ($self, $fileName) = @_;
  
    open (FILE, $fileName) or die "This file cannot be opened !!!";
    
    my $sequence = '';
    my $chromosome = '';

    my %chromosomes = ();

    while (my $line = <FILE>) {
        if ($line =~ /^>/) {
            if ($chromosome ne '') {

                $sequence = Utils::upperCase(Utils::trim($sequence));
                $chromosomes{Utils::trim($chromosome)} = $sequence
            }

	    $chromosome = $line;
	    $chromosome = $1 if ($chromosome =~ /(\w+\s{1})/);    
	    
	    $sequence = '';

        } else {
            $sequence .= Utils::trim($line)
        }
    }

    $sequence = Utils::upperCase(Utils::trim($sequence));
    $chromosomes{Utils::trim($chromosome)} = $sequence;

    close (FILE);

    return (%chromosomes) ##(%updated_chromosomes)
}

## This function receives the name of the file containing all of the genes (separated by the
## tab character) whose promoter regions will be analyzed. Thereafter a list composed of the
## previously mentioned genes is returned.

sub geneFileReader {

    my ($self, $fileName) = @_;

    open(IN, $fileName);
    my @lines = <IN>;
    my @genes = split("\t", Utils::trim(Utils::upperCase($lines[0])));

    return (@genes)
}

## This function receives three parameters: (1) an output file, (2) the reference to a hash whose
## "keys" and "values" are the identifier and the information of each gene, and (3) a hash whose 
## "keys" and "values" are the identifier of each gene within the promoter file and its promoter 
## region. Thereafter all the promoter regions are written into the output file.

sub promoterFileWriter {

    my ($self, $outputFile, $ref_descriptions, %promoters) = @_;

    my %descriptions = %{$ref_descriptions};

    my @genes = keys(%promoters);
    
    open (OUT, ">$outputFile");
    
    foreach (@genes) {
	
	print OUT $descriptions{$_} . "\n";
	
	my $promoter = Utils::convertToFASTAFormat($promoters{$_});
	
	print OUT $promoter;
	print OUT "\n";
	
    }

    close(OUT)
}

## This function receives three parameters: (1) an output file, .... , and (3) a list of genes. Thereafter all the 
## genes are tab-separated and written into the external file.

sub geneNameWriter {

    my ($self, $outputFile, @randomGenes) = @_;

    my $geneString = Utils::ListToSequence("\t", @randomGenes);

    open(OUTPUT, ">$outputFile");
    print OUTPUT $geneString;
    
    close(OUTPUT)
}

## This function receives two parameters: (1) a file name, and (2) a hash whose "keys" and "values" 
## are the chromosome identifier and instances of the "Chromosome" class, respectively. Afterwards,
## the hash is saved into the file to be recovered later.

sub Save {

    my ($self, $fileName, %Chromosomes) = @_;

    store(\%Chromosomes, $fileName);
}


## This function receives a file name and returns the hash saved within the file.

sub Recover {

    my ($self, $fileName) = @_;

    my  %Chromosomes = %{retrieve($fileName)};

    return (%Chromosomes);
}


1;
