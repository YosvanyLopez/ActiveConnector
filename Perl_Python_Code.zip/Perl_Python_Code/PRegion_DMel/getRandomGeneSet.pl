##########################################################################################
## Laboratory of Functional Analysis in silico                                          ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo           ##
## Programmed by Yosvany Lopez Alvarez                                   February, 2011 ##
##########################################################################################

#!/usr/local/bin/perl

use warnings;
use strict;
use File;
use karyotype;

##########################################################################################
## This script receives the desired amount of random genes to be attained               ##
##########################################################################################

my $KaryotypeInfo = ''; ## TSS coordinates

my $RandomGeneFile = ''; ## file to copy the gene names

##########################################################################################

my $file_object = new File ();
my %Karyotype = $file_object -> Recover($KaryotypeInfo);

my $karyotype_object = constructor karyotype ();
my @gene_list = $karyotype_object -> getGeneList(%Karyotype);

my @random_genes = Utils::GetRandomGenes(1000, @gene_list); ## $ARGV[0] - number of random genes 

$file_object -> geneNameWriter($RandomGeneFile, @random_genes);

##########################################################################################
