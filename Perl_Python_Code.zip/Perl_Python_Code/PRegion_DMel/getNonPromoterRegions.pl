##########################################################################################
## Laboratory of Functional Analysis in silico                                          ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo           ##
## Programmed by Yosvany Lopez Alvarez                                   February, 2011 ##
##########################################################################################

#!/usr/local/bin/perl

use warnings;
use strict;
use File;
use nonpromoter;

##########################################################################################

my $karyotypeFile = ""; ## TSS coordinates

my $geneNameFile = ""; ## all the gene names

my $promoterFile = ""; ## file to save all non-promoter regions

##########################################################################################

my $fileObject = new File (); 
my %karyotype = $fileObject -> Recover($karyotypeFile);
my @genes = $fileObject -> geneFileReader($geneNameFile); 

my $nonpromoterObject = new nonpromoter();
my ($ref_descriptions, %sequences) = $nonpromoterObject -> getNonPromoterRegions(2000, 4000, \@genes, %karyotype);

print scalar(keys(%sequences));
print "\n";

$fileObject -> promoterFileWriter($promoterFile, $ref_descriptions, %sequences);

##########################################################################################

