##########################################################################################
## Laboratory of Functional Analysis in silico                                          ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo           ##
## Programmed by Yosvany Lopez Alvarez                                   November, 2014 ##
##########################################################################################

#!/usr/local/bin/perl

use warnings;
use strict;
use Storable;

##########################################################################################

my $karyotype_dir = ''; ## directory of each species' TSS coordinates

my @species = ('d_ananassae', 'd_erecta', 'd_grimshawi', 'd_melanogaster', 'd_mojavensis', 'd_persimilis', 'd_pseudoobscura', 'd_sechellia', 'd_simulans', 'd_virilis', 'd_willistoni', 'd_yakuba');

my $gene_info_file = ""; ## file to save the karyotype of all the species

#########################################################################################

sub get_gene_info {

    my ($karyotype_file) = @_;

    my $ref_karyotype = retrieve($karyotype_file);
    my %karyotype = %{$ref_karyotype};

    my %gene_list = ();

    foreach my $chr (keys(%karyotype)) {

	my %genes = %{${$karyotype{$chr}}{'GENES'}};

	foreach (keys(%genes)) {
	    my $iposition = ${$genes{$_}}{'INITIAL_POSITION'};
	    my $fposition = ${$genes{$_}}{'FINAL_POSITION'};
	    my $strand = ${$genes{$_}}{'DIRECTION'};

	    my $info = $chr . "\t" . $strand . "\t";

	    if ($strand eq "+") { $info = $info . $iposition }
	    else { $info = $info . $fposition }
	    
	    $gene_list{$_} = $info
	}
    }

    return (%gene_list)
}

my %karyotypes = ();

foreach (@species) {

    my $tss_file = $karyotype_dir . $_ . '/tss_coordinates.info';

    my %gene_list = get_gene_info($tss_file);
    
    $karyotypes{$_} = \%gene_list
}

store \%karyotypes, $gene_info_file

##########################################################################################
