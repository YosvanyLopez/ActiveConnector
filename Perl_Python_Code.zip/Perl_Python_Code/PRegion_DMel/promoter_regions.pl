##########################################################################################
## Laboratory of Functional Analysis in silico                                          ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo           ##
## Programmed by Yosvany Lopez Alvarez                                   November, 2014 ##
##########################################################################################

#!/usr/local/bin/perl

use warnings;
use strict;
use File;
use promoter;

##########################################################################################

my $karyotype_file = ""; ## TSS coordinates

my $promoter_file = ""; ## genes whose promoters will be extracted 

my $fasta_file = ""; ## file to save the promoter regions

##########################################################################################

my $file_object = new File (); 
my %karyotype = $file_object -> Recover($karyotype_file);

my @genes = $file_object -> geneFileReader($promoter_file); 

my $promoter_object = new promoter ();
my ($ref_descriptions, %sequences) = $promoter_object -> getGenePromoterRegion (1500, 500, \@genes, %karyotype);

$file_object -> promoterFileWriter($fasta_file, $ref_descriptions, %sequences);

##########################################################################################
