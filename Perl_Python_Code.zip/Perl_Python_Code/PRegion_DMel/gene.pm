########################################################################################
## This package contains the "Gene" class whose attributes are the accurate positions ##
## (initial and final coordinates) as well as the direction of each gene in the       ##
## Arabidopsis thaliana genome.                                                       ##
##                                                                                    ##
## Laboratory of Functional Analysis in silico                                        ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo         ##
## Programmed by Yosvany Lopez Alvarez                                 February, 2011 ##
########################################################################################

package gene;

use strict;
use warnings;


## This function stands for this class' constructor. Each gene contains three attributes:
## the initial and final coordinates as well as its direction within the Arabidopsis
## thaliana chromosomes.

sub constructor {

    my $self  = {};

    $self -> {INITIAL_POSITION} = undef;
    $self -> {FINAL_POSITION}  = undef;
    $self -> {DIRECTION} = undef;
    bless($self);
       
    return ($self);
}


## This function receives the initial position of the gene, and sets this value into
## the "INITIAL_POSITION" attribute.

sub setInitialPosition {

    my ($self, $aValue) = @_;

    $self -> {INITIAL_POSITION} = $aValue;
}


## This function returns the value stored in the "INITIAL_POSITION" attribute.

sub getInitialPosition {

    my $self = shift;

    return ($self -> {INITIAL_POSITION}); 
}


## This function receives the final position of the gene, and sets this value into
## the "FINAL_POSITION" attribute.

sub setFinalPosition {

    my ($self, $aValue) = @_;

    $self -> {FINAL_POSITION} = $aValue;
}


## This function returns the value stored in the "FINAL_POSITION" attribute.

sub getFinalPosition {

    my $self = shift;
    
    return ($self -> {FINAL_POSITION});
}


## This function receives the direction of the gene, and sets this value into 
## the "DIRECTION" attribute.

sub setDirection {
    
    my ($self, $aValue) = @_;

    $self -> {DIRECTION} = $aValue;
}


## This function returns the value stored in the "DIRECTION" attribute.

sub getDirection {

    my $self = shift;
    
    return ($self -> {DIRECTION});
}


1;
