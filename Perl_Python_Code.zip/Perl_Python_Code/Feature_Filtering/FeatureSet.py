##############################################################################################
## Laboratory of Functional Analysis in silico                                              ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo               ##
## Programmed by Yosvany Lopez Alvarez                                           June, 2011 ##
##############################################################################################

from Utils import *
from Feature import *
import numpy
import math

class FeatureSet:

    ## This function represents the constructor of this class. 
    
    def __init__(self):

        self.FEATURESET = dict ()
        self.CLASS = None
        
        
    ## This function .....
        
    def setFeatureInstance (self, Identifier, FeatureObject):

        self.FEATURESET[Identifier] = FeatureObject

    ## This function ....

    def getFeatureInfo (self):
        
        return (self.FEATURESET)

    ## This function ....

    def getClassVector (self):

        return (self.CLASS)


    ## This function ....

    def ValuePerFeature (self, StringList):
        
        Rules = dict()

        i = 0
        while (i <= len(StringList) - 1):
            (Rule, Items) = SplitString ("\t", StringList[i])
            
            Values = StringToInteger(Items)
            Rules[Rule.strip()] = Values
            
            i += 1

        return (Rules)
   
    ## This function ......

    def CreateClassIndices (self, ClassIdx, Times):

        ClassIndices = [ClassIdx] * Times
        
        return (ClassIndices)
    
    ## This function ....

    def CreateFeatureMatrix (self, SpecificSet_String, NonSpecificSet_String):

        SpecificSetRules = self.ValuePerFeature (SpecificSet_String)
        NonSpecificSetRules = self.ValuePerFeature(NonSpecificSet_String)

        Instance_Class1 = 0
        Instance_Class2 = 0

        Rules = SpecificSetRules.keys()

        for Rule in Rules:
            
            Instance_Class1 = len(SpecificSetRules[Rule])
            Instance_Class2 = len(NonSpecificSetRules[Rule])
            CompleteValueList = SpecificSetRules[Rule] + NonSpecificSetRules[Rule]
            
            CompleteValueList = Normalization(CompleteValueList)

            ZeroAmount = SpecificSetRules[Rule].count(0)

            if (ZeroAmount != len(SpecificSetRules[Rule])):
                FeatureObject = Feature ()
                FeatureObject.setValues(CompleteValueList) 
                self.setFeatureInstance(Rule, FeatureObject)

        ClassVector1 = self.CreateClassIndices(1, Instance_Class1)
        ClassVector2 = self.CreateClassIndices(0, Instance_Class2)
        ClassVector = ClassVector1 + ClassVector2

        ClassObject = Feature ()
        ClassObject.setValues(ClassVector)
        self.CLASS = ClassObject


    ## This function ...

    def getDefinedLikelihood (self, ClassIdx, FeatureVector, ClassVector):

        ValueDict = CountValues(FeatureVector)
        Values = ValueDict.keys()

        IntersectionDict = dict ()

        Amount = 0

        for Value in Values:
            Counter = 0
            for i in range(len(FeatureVector)):
                if ((ClassVector[i] == ClassIdx) & (FeatureVector[i] == Value)):
                    Counter += 1
                    
            Amount += Counter
            IntersectionDict[Value] = Counter

        return (Amount, IntersectionDict)

    ## This function .....

    def ComputeLikelihood (self, Amount, IntersectionDict):

        Values = IntersectionDict.keys()
        
        PartialEntropy = 0.0

        for Value in Values:
            InternalLikelihood = (IntersectionDict[Value] + 1)/(float(Amount) + len(Values))
            InternalEntropy = InternalLikelihood * Log2(InternalLikelihood)
            PartialEntropy += InternalEntropy

        return (PartialEntropy)

    
    ## This function receives two "Feature" instances ....

    def ComputeEntropyTwoFeatures (self, FeatureInstance1, FeatureInstance2):

        Likelihoods = FeatureInstance2.ComputeLikelihoods()

        ClassIndices = Likelihoods.keys()

        Entropy = 0.0

        for ClassIdx in ClassIndices:
            (Amount, Intersection) = self.getDefinedLikelihood(ClassIdx, FeatureInstance1.getValues(), FeatureInstance2.getValues())
            PartialEntropy = self.ComputeLikelihood(Amount, Intersection)
            Entropy += Likelihoods[ClassIdx] * PartialEntropy

        Entropy *= (-1) 

        return (Entropy)

    
    ## This function computes the symmetrical uncertainty between two features .....

    def ComputeSUncertainty (self, FeatureInstance1, FeatureInstance2):

        Entropy_1 = FeatureInstance1.ComputeEntropy()
        Entropy_2 = FeatureInstance2.ComputeEntropy()
        JoinEntropy = self.ComputeEntropyTwoFeatures(FeatureInstance1, FeatureInstance2)

        InformationGain = Entropy_1 - JoinEntropy
        Entropies = Entropy_1 + Entropy_2
        
        SUncertainty = 2 * (InformationGain/float(Entropies))

        return (SUncertainty)


    ## This function ....
    
    def ComputeAllUncertainties (self):

        FeatureDict = self.getFeatureInfo()
        ClassInstance = self.getClassVector()

        Features = FeatureDict.keys()

        SUDictionary = dict()

        for Feature in Features:

            SU = self.ComputeSUncertainty(FeatureDict[Feature], ClassInstance)
            SUDictionary[Feature] = SU

        return (SUDictionary)

    
    ## This function ....
    
    def FilterFeaturesBySUValue (self, Threshold, SUDictionary):

        Features = SUDictionary.keys()

        for Feature in Features:
            if (SUDictionary[Feature] < Threshold):
                del SUDictionary[Feature]
        
        return (SUDictionary)

    
    ## This function ....

    def FastCorrelationBasedFilter (self):

        ## First Phase .......

        SUDictionary = self.ComputeAllUncertainties()

        Threshold = numpy.mean(SUDictionary.values())

        FilteredSUDictionary = self.FilterFeaturesBySUValue(Threshold, SUDictionary)

        FeatureCollection = SortDictionaryByValues(FilteredSUDictionary)
       
        FeatureDict = self.getFeatureInfo()

        ## Second Phase ....

        i = 0
        while (i <= len(FeatureCollection) - 1):
           
            PredominantInstance = FeatureDict[FeatureCollection[i]]

            j = i + 1
            while (j <= len(FeatureCollection) - 1):
            
                SUpq = self.ComputeSUncertainty(PredominantInstance, FeatureDict[FeatureCollection[j]])
                SUqc = FilteredSUDictionary[FeatureCollection[j]]

                if (SUpq >= SUqc):   
                    FeatureCollection.remove(FeatureCollection[j])

                j += 1
        
            i += 1

        return (FeatureCollection)

    
    ## This function ....
 
    def KullbackLeiblerOneValue (self, Number, ClassVector, Instance, Likelihoods):

        (Amount, IntersectionDict) = self.getDefinedLikelihood(Number, ClassVector.getValues(), Instance.getValues())

        Values = IntersectionDict.keys()
        
        KullbackLeibler = 0.0

        for Value in Values:
            InternalLikelihood = (IntersectionDict[Value] + 1)/(float(Amount) + len(Values))
            KullbackLeibler += InternalLikelihood * math.log10(InternalLikelihood/float(Likelihoods[Value]))
                        
        return (KullbackLeibler)
    
    
    ## This function ....

    def ComputeKullbackLeiblerWeight (self, Instance):

        ClassVector = self.getClassVector()

        ClassLikelihoods = ClassVector.ComputeLikelihoods()
        InstanceLikelihoods = Instance.ComputeLikelihoods()

        SplitInfo = self.ComputeSplitInfo(InstanceLikelihoods)        
        
        Values = InstanceLikelihoods.keys()

        KLWeight = 0.0

        for Value in Values:
            
            KL = self.KullbackLeiblerOneValue(Value, ClassVector, Instance, ClassLikelihoods)
            KLWeight += InstanceLikelihoods[Value] * KL
            
        KLWeight = KLWeight/float(SplitInfo)

        return (KLWeight)

    
    ## This function ....

    def ComputeSplitInfo (self, Likelihoods):

        Values = Likelihoods.keys()

        SplitInfo = 0.0

        for Value in Values:
            SplitInfo += Likelihoods[Value] * math.log10(Likelihoods[Value])

        SplitInfo *= -1

        return (SplitInfo) 


    ## This function ....

    def GetKLWeights (self, FeatureCollection):

        FeatureInstances = self.getFeatureInfo()

        Weights = dict ()

        for Feature in FeatureCollection:

            Instance = FeatureInstances[Feature]
            KLWeight = self.ComputeKullbackLeiblerWeight(Instance)

            Weights[Feature] = KLWeight
                        
        return (Weights)
