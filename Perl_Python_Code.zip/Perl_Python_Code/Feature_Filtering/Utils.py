########################################################################################
## Laboratory of Functional Analysis in silico                                        ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo         ##
## Programmed by Yosvany Lopez Alvarez                                     June, 2011 ##
########################################################################################

from math import *

## This function receives two parameters: (1) a character to be used as splitter, and 
## (2) a string. Thereafter, the string is cut into small substrings from which the first 
## one is returned.

def SplitString (p_Character, p_String):

    List = []
    List = p_String.rsplit(p_Character)
    GeneName = List.pop(0)

    return (GeneName, List)


## This function receives two parameters: (1) a character to be considered as separator, 
## and (2) a list of strings. Thereafter, the items within the list are concatenated 
## by using the separator character and returned as a single sequence.

def ListToSequence (p_Character, p_List):

    Sequence = ''

    i = 0
    while (i <= len(p_List) - 2):
        Sequence += p_List[i] + p_Character
        i += 1

    Sequence += p_List[len(p_List) - 1]

    return (Sequence)


## This function receives a list of string values and returns a new list composed of 
## their respective integer values.

def StringToInteger (list):

    newList = map(int, list)

    return (newList)


## This function ....

def Normalization (List):

    List = [x if (x<1) else 1 for x in List]

    return (List)


## This function .....

def Log2 (Number):

   Logarithm = log(Number)/log(2)

   return (Logarithm)


## This function ....

def CountValues (List):

    Counter = [(x, List.count(x)) for x in set(List)]
    Counter = dict(Counter)

    return (Counter)


## This function ....

def MergeDictionary (Dictionary):
    
    ValueList = Dictionary.keys()

    MergedList = []
    
    for Value in ValueList:

            MergedList = MergedList + Dictionary[Value]

    return (ValueList, MergedList)

## This function ....

def SortDictionaryByValues (Dictionary):

    SortedKeys = sorted(Dictionary, key=Dictionary.get, reverse=True)

    return (SortedKeys)
