##############################################################################################
## Laboratory of Functional Analysis in silico                                              ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo               ##
## Programmed by Yosvany Lopez Alvarez                                           June, 2011 ##
##############################################################################################

from Utils import ListToSequence 
import pickle

class File:

    ## This function receives the name of a file comprising gene expressions. Thereafter, it 
    ## returns a list composed only of gene expressions.

    def FileReader (self, p_FileName):

        Input = open (p_FileName, "r")

        List = Input.readlines()

        GeneNameString = List.pop(0)

        Input.close()

        return (List)


    ## This function receives a list of file names and each file is composed of gene expressions. 
    ## Thereafter, a dictionary whose "keys" and "values" are integer indices and the respective 
    ## gene expressions within each file is returned.

    def FileListReader(self, p_FileList):

        FileDictionary = dict ()
        
        Count = 0

        for Item in p_FileList:

            FileDictionary[Count] = self.FileReader(Item)
            
            Count += 1

        return (FileDictionary)


    ## This function receives two parameters: (1) an output file, and (2) a list composed of 
    ## gene names. Thereafter, a sequence containing each gene name separated by tab characters 
    ## is copied into the output file.
    
    def GeneNameWriter (self, p_OutputFile, p_GeneNameList):

        Output = file (p_OutputFile, "w")

        Output.write(ListToSequence('\t', p_GeneNameList))


    ## This function ....

    def SaveRules (self, FileName, Dictionary):

        file = open(FileName, 'w')

        pickle.dump(Dictionary, file)
        
        file.close()

    ## This function ....
        
    def FeatureWriter (self, FileName, FeatureCollection):

        Input = open(FileName, 'w')

        for Feature in FeatureCollection:
            Input.write(Feature)
            Input.write('\n')

        Input.close()


    ## This function ....                                                                                                                                                                                                                                                     
    def feature_weight_writer (self, file_name, feature_weight):

        Input = open(file_name, 'w')

        for feature in (feature_weight.keys()):
            Input.write(feature + "\t" + str(feature_weight[feature]))
            Input.write('\n')

        Input.close()

