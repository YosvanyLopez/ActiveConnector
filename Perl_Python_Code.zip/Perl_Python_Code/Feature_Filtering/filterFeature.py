#################################################################################################
## Laboratory of Functional Analysis in silico                                                 ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo                  ##
## Programmed by Yosvany Lopez Alvarez                                              June, 2011 ##
#################################################################################################

#!/usr/local/bin/python

from File import *
from FeatureSet import *
import sys

#################################################################################################

RuleFile_1 = './dmel_development/stage_' + str(sys.argv[1]) + '/feature_generation/fgeneration_matrix.txt'

RuleFile_2 = './dmel_development/stage_' + str(sys.argv[1]) + '/feature_generation/cfgeneration_matrix.txt'

feature_file = './dmel_development/stage_' + str(sys.argv[1]) + '/feature_generation/FC_features.txt'

weight_file = './dmel_development/stage_' + str(sys.argv[1]) + '/feature_generation/feature_weights.python'

#################################################################################################

FileObject = File()
SpecificSet_String = FileObject.FileReader(RuleFile_1)
NonSpecificSet_String = FileObject.FileReader(RuleFile_2)

FeatureSetObject = FeatureSet ()
FeatureSetObject.CreateFeatureMatrix (SpecificSet_String, NonSpecificSet_String)
FeatureCollection = FeatureSetObject.FastCorrelationBasedFilter()

FeatureWeights = FeatureSetObject.GetKLWeights(FeatureCollection)

FileObject.FeatureWriter(feature_file, FeatureCollection)
FileObject.SaveRules(weight_file, FeatureWeights)

#################################################################################################
