##############################################################################################
## Laboratory of Functional Analysis in silico                                              ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo               ##
## Programmed by Yosvany Lopez Alvarez                                           June, 2011 ##
##############################################################################################

from Utils import *

class Feature:
        
    ## This function represents the constructor of this class.                                                                                                            
          
    def __init__(self):

        self.VALUEPERCLASS = []


    ## This function .....
                                                                                                                                                        
    def setValues (self, Values):

	self.VALUEPERCLASS = Values


    ## This function ....                                                                                                                                                  
       
    def getValues (self):

        return (self.VALUEPERCLASS)
    

    ## This function ....
    
    def ComputeLikelihoods (self):
        
        ValueList = self.getValues()
        Counter = CountValues(ValueList)

        InstanceAmount = len(ValueList)
        
        DifferentValues = Counter.keys()
  
        LikelihoodSet = dict()

        for OneValue in DifferentValues:
            Likelihood = (Counter[OneValue] + 1)/(float(InstanceAmount) + len(DifferentValues));
            LikelihoodSet[OneValue] = Likelihood
                 
        return (LikelihoodSet)


    ## This function ....   
                                                                                                                                                       
    def ComputeEntropy (self):

        Likelihoods = self.ComputeLikelihoods()
        
        DifferentValues = Likelihoods.keys()

        Entropy = 0.0

        for OneValue in DifferentValues:
            Entropy += Likelihoods[OneValue] * Log2(Likelihoods[OneValue])

        Entropy *= -1

        return (Entropy)
