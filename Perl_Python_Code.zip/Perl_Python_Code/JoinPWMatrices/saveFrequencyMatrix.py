#################################################################################################
## Laboratory of Functional Analysis in silico                                                 ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo                  ##
## Programmed by Yosvany Lopez Alvarez                                          November, 2011 ##
#################################################################################################

#!/usr/local/bin/python

from File import *
from MatrixDictionary import *
import sys

#################################################################################################

PWMatrixFile = './dmel_development/stage_01/motif_prediction/pfmatrices.info' ## the stage number is changed manually

IContentFile = './dmel_development/stage_01/motif_prediction/icontent.info' ## the stage number is changed manually

################################################################################################

FileObject = File()
PWMDictionaries = FileObject.RetrievePWMatrices(PWMatrixFile)
 
MatrixDictionaryObject = MatrixDictionary()
MatrixDictionaryObject.UpdateFrequencyMatrices(PWMDictionaries)
MatrixDictionary = MatrixDictionaryObject.GetFrequencyMatrices()
IContent = MatrixDictionaryObject.GetInformationContent()

FileObject.SaveDictionary(IContentFile, IContent)

#################################################################################################
