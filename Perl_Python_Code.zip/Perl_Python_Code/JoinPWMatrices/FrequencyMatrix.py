#########################################################################################
## Laboratory of Functional Analysis in silico                                         ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo          ##
## Programmed by Yosvany Lopez Alvarez                                  November, 2011 ##
#########################################################################################

from Utils import *
from Math import *
from Conversion import *
import math

class FrequencyMatrix:

    def __init__(self):

        self.POSITIONNUMBER = 0
        self.SITENUMBER = 0
        self.MATRIX = []
        self.LETTERPROBABILITYMATRIX = []

    def ComputePositionNumber (self):

        self.POSITIONNUMBER = len(self.MATRIX)

    def GetPositionNumber (self):

        return (self.POSITIONNUMBER)

    def ComputeSiteNumber (self):

        self.SITENUMBER = sum(self.MATRIX[0])

    def GetSiteNumber (self):
        
        return (self.SITENUMBER)

    def SetMatrix (self, Matrix):

        self.MATRIX = Matrix

    def GetMatrix (self):
        
        return (self.MATRIX)

    def ComputeProbabilityMatrix (self):

        i = 0
        while (i <= len(self.MATRIX) - 1):
            
            self.LETTERPROBABILITYMATRIX.append(ComputeLikelihood(self.MATRIX[i]))
           
            i += 1

    def GetProbabilityMatrix (self):

        return (self.LETTERPROBABILITYMATRIX)

    def ComputeCorrectedLikelihood (self, Value, List): 
    
        CorrectedProbabilities = []

        for Item in List:
            Numerator = Item + pow(Value, 0.5)
            Denominator = pow((Value + 4 * pow(Value, 0.5)), -1)
            CorrectedProbability = round((Numerator * Denominator), 3)

            CorrectedProbabilities.append(CorrectedProbability)
    
        return (CorrectedProbabilities)

    def ComputeCorrectedLikelihoods (self):

        FrequencyMatrix = self.MATRIX

        Transpose = zip(*FrequencyMatrix)
        FrequencyMatrix = list(Transpose)

        WeightMatrix = dict ()

        Nucleotides = ['A', 'C', 'G', 'T']
    
        SiteNumber = self.GetSiteNumber()
        
        for i in range(0,4): 
            WeightMatrix[Nucleotides[i]] = self.ComputeCorrectedLikelihood(SiteNumber, FrequencyMatrix[i])
    
        return (WeightMatrix)

    def ComputeICOnePosition (self, Position, Matrix):
    
        Nucleotides = Matrix.keys()
    
        IC = 0.0
        for Nucleotide in Nucleotides:
            Likelihood = Matrix[Nucleotide][Position]
            ICBase = Likelihood * math.log(Likelihood, 2)

            IC = IC + ICBase
        
        ICPosition = round((2 + IC), 3)

        return (ICPosition)

    def ComputeInformationContent (self, Matrix):

        IContent = 0.0

        PositionNumber = self.GetPositionNumber()

        i = 0
        while (i <= PositionNumber  - 1):
            ICPosition = self.ComputeICOnePosition(i, Matrix)
            IContent += ICPosition

            i += 1
    
        return (IContent)
