#########################################################################################
## Laboratory of Functional Analysis in silico                                         ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo          ##
## Programmed by Yosvany Lopez Alvarez                                  November, 2011 ##
#########################################################################################

from FrequencyMatrix import *

class MatrixDictionary:

    def __init__(self):
        
        self.FREQUENCYMATRICES = dict ()
        self.LETTERFREQUENCY = dict ()

    def UpdateFrequencyMatrices (self, FrequencyMatrices):

        NFMKeys = FrequencyMatrices.keys() 
        
        for matrix_index in NFMKeys:

            frequencyMatrixObject = FrequencyMatrix()
            frequencyMatrixObject.SetMatrix(FrequencyMatrices[matrix_index])
            frequencyMatrixObject.ComputePositionNumber()
            frequencyMatrixObject.ComputeSiteNumber()
            frequencyMatrixObject.ComputeProbabilityMatrix()

            self.FREQUENCYMATRICES[matrix_index] = frequencyMatrixObject
            
    def GetFrequencyMatrices (self):

        return (self.FREQUENCYMATRICES)

    def InitializeLetterFrequency (self, DNAString):

        i = 0
        while (i <= len(DNAString) - 1):
            
            self.LETTERFREQUENCY[DNAString[i]] = 0

            i += 1

    def UpdateLetterFrequency (self, DNAString):

        FrequencyMatrixKeys = self.FREQUENCYMATRICES.keys()

        for FrequencyMatrixKey in FrequencyMatrixKeys:

            Transpose = ComputeTranspose(self.FREQUENCYMATRICES[FrequencyMatrixKey].GetMatrix())
            
            i = 0
            while (i <= len(DNAString) - 1):

                self.LETTERFREQUENCY[DNAString[i]] += sum(Transpose[i])

                i += 1

    def ComputeLetterFrequency (self, DNAString):

        self.InitializeLetterFrequency(DNAString)  
        self.UpdateLetterFrequency(DNAString)

        LetterFrequencyKeys = self.LETTERFREQUENCY.keys()
        
        Sum = 0
        for LetterFrequencyKey in LetterFrequencyKeys:
            Sum += self.LETTERFREQUENCY[LetterFrequencyKey]

        for LetterFrequencyKey in LetterFrequencyKeys:
            self.LETTERFREQUENCY[LetterFrequencyKey] = round(self.LETTERFREQUENCY[LetterFrequencyKey] * pow(Sum, -1), 3)

    def GetLetterFrequency (self):
        
        return (self.LETTERFREQUENCY)

    def GetInformationContent(self):

        MatrixDictionary = self.GetFrequencyMatrices()

        MotifNames = MatrixDictionary.keys()

        IContentData = dict()

        for MotifName in MotifNames:

            Likelihoods = MatrixDictionary[MotifName].ComputeCorrectedLikelihoods()
            IContent = MatrixDictionary[MotifName].ComputeInformationContent(Likelihoods)
            
            IContentData[MotifName] = IContent

        return (IContentData)
