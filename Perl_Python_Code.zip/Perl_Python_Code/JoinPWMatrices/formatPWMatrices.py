#################################################################################################
## Laboratory of Functional Analysis in silico                                                 ##
## Human Genome Center, Institute of Medical Science, The University of Tokyo                  ##
## Programmed by Yosvany Lopez Alvarez                                          November, 2011 ##
#################################################################################################

#!/usr/local/bin/python

from File import *
from MatrixDictionary import *
import sys

#################################################################################################
## This script receives from the console two arguments: (1) a strict nucleotide alphabet (for  ##
## instance, "ACGT"), and (2) the direction of the strands (+/-) being considered.             ##
#################################################################################################

PWMatrixFile = './dmel_development/stage_01/motif_prediction/pfmatrices.info' ## the stage number is changed manually

DataName = 'DME_MOTIFS'

MEMEFileName = './dmel_development/stage_01/motif_prediction/tomtom/dmel_motif_set.meme' ## the stage number is changed manually

################################################################################################

FileObject = File()
PWMDictionaries = FileObject.RetrievePWMatrices(PWMatrixFile)

MatrixDictionaryObject = MatrixDictionary()
MatrixDictionaryObject.UpdateFrequencyMatrices(PWMDictionaries)
MatrixDictionary = MatrixDictionaryObject.GetFrequencyMatrices()
MatrixDictionaryObject.ComputeLetterFrequency(sys.argv[1])
LetterFrequency = MatrixDictionaryObject.GetLetterFrequency()

FileObject.FrequencyMatrixWriter(MatrixDictionary, LetterFrequency, sys.argv[1], sys.argv[2], DataName, 'Motif', MEMEFileName)

################################################################################################
