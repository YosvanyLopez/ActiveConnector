########################################################################################
## Laboratory of Functional Analysis in silico                                        ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo         ##
## Programmed by Yosvany Lopez Alvarez                                 November, 2011 ##
########################################################################################     

def SplitString (Character, String):

    String = String.strip()
    
    List = String.rsplit(Character)
   
    return (List)

def ListToSequence (Character, List):

    Sequence = ''
   
    for Item in List:
        Sequence += Item + Character

    Sequence += "\n"

    return (Sequence)

def RemoveCharacters (List, Characters):

    NewList = [Item.strip(Characters) for Item in List]

    return (NewList)

def FilterString (String):

    return (String != '')

def FilterStringList (List):

    return (filter(FilterString, List))

def RemoveItems (Index, List):

    NewList = []

    i = Index
    while (i <= len(List) - 1):

        NewList.append(List[i])
        i += 1
        
    return (NewList)
