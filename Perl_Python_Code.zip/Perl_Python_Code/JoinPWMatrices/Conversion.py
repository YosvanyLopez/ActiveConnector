########################################################################################
## Laboratory of Functional Analysis in silico                                        ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo         ##
## Programmed by Yosvany Lopez Alvarez                                November, 2010  ##
########################################################################################

class Conversion:

    def StringToFloat (self, p_List):

        NewList = map(float, p_List)

        return (NewList)

    def FloatToString (self, p_List):

        NewList = map(str, p_List)

        return (NewList)

    def StringToInteger (self, p_List):

        NewList = map(int, p_List)

        return (NewList)

    def IntegerToString (self, p_List):

        NewList = map(str, p_List)

        return (NewList)
