##############################################################################################
## Laboratory of Functional Analysis in silico                                              ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo               ##
## Programmed by Yosvany Lopez Alvarez                                       November, 2011 ##
##############################################################################################

from FrequencyMatrix import *
from Conversion import *
from Utils import *
import pickle

class File:

    def FrequencyMatrixWriter (self, FrequencyMatrices, LetterFrequency, Alphabet, Strands, DataFile, Tissue, OutputFile):

        Output = file(OutputFile, "w")

        Output.write('MEME version 4' + "\n")
        Output.write("\n")

        Output.write('ALPHABET= ' + Alphabet + "\n")
        Output.write("\n")

        if (Strands == "-"):
            Output.write('strands: ' + '+ -' + "\n")
        else:
            Output.write('strands: ' + '+' + "\n")

        Output.write("\n")

        LetterFrequencies = ''

        Output.write('Background letter frequencies (from ' + DataFile + '):' + "\n")        
        
        i = 0
        while (i <= len(Alphabet) - 1):
            LetterFrequencies +=  Alphabet[i] + ' ' + str(LetterFrequency[Alphabet[i]]) + ' '
            i += 1

        Output.write(LetterFrequencies + "\n")
        Output.write("\n")

        FrequencyMatrixKeys = FrequencyMatrices.keys()
        FrequencyMatrixKeys.sort()
       
        for FrequencyMatrixKey in FrequencyMatrixKeys:

            PositionNumber = FrequencyMatrices[FrequencyMatrixKey].GetPositionNumber()
            SiteNumber = FrequencyMatrices[FrequencyMatrixKey].GetSiteNumber()

            MotifName = 'MOTIF '
            
            Output.write(MotifName + str(FrequencyMatrixKey) + "\n")
            LetterProbabilityDetails = 'letter-probability matrix: alength= ' + str(len(Alphabet)) + ' w= ' + str(PositionNumber) + ' nsites= ' + str(SiteNumber) + ' E= 0'
            Output.write(LetterProbabilityDetails + "\n")

            LetterProbabilityMatrix = FrequencyMatrices[FrequencyMatrixKey].GetProbabilityMatrix()

            conversionObject = Conversion()

            j = 0
            while (j <= len(LetterProbabilityMatrix) - 1):
                Output.write(ListToSequence("\t", conversionObject.FloatToString(LetterProbabilityMatrix[j])))
                j += 1

            Output.write("\n")
            Output.write("\n")

        Output.close()

    def RetrievePWMatrices (self, ExternalFile):

        ref_PWMatrices = open(ExternalFile, 'rb')
        PWMGroup = pickle.load(ref_PWMatrices)
        ref_PWMatrices.close()

        return (PWMGroup)

    def RetrieveAllPWMatrices (self, FileNameList):

        PWMatrices = {}

        i = 0
        while (i <= len(FileNameList) - 1):

            PWMatrices[i] = self.RetrievePWMatrices(FileNameList[i])

            i += 1

        return (PWMatrices)

    def IntegrateDictionary (self, PWMatrices):

        PWMGroups = PWMatrices.keys()

        NewHashPWM = {}

        Count = 1

        for PWMGroup in PWMGroups:

            PWMatrixSet = PWMatrices[PWMGroup]
            PWMIDs = PWMatrixSet.keys()

            for PWMID in PWMIDs:
                NewHashPWM[Count] = PWMatrixSet[PWMID]
                Count += 1

        return (NewHashPWM)
    
    def SaveFrequencyMatrices (self, Tissue, FrequencyMatrices, ExternalFile):

        NFMDictionary = dict ()

        NFMKeys = FrequencyMatrices.keys()
        NFMKeys.sort()

        for NFMKey in NFMKeys:

            NFMDictionary[Tissue + '_' + str(NFMKey)] = FrequencyMatrices[NFMKey].GetMatrix()

        self.SaveDictionary(ExternalFile, NFMDictionary)

    def SaveDictionary(self, OutputFile, Dictionary):

        FileHandler = open(OutputFile, 'w')
        pickle.dump(Dictionary, FileHandler)

    def pfmatrix_reader (self, stage, file_name):

        lines = [line.strip() for line in open(file_name)]

        motif_id = ''
        pfmatrices = dict()
        conversion_object = Conversion()

        for i in range(0, len(lines)):
            if (lines[i].startswith(">")):
                motif_id = lines[i]
                motif_id = motif_id[1:]
                pfmatrices[motif_id] = []
            else:
                chr_list = lines[i].split(" ")
                chr_list.pop(0)
                chr_list.pop(0)
                chr_list.pop()
                int_list = conversion_object.StringToInteger(chr_list)
                pfmatrices[motif_id].append(int_list)
                
        for pfmatrix in pfmatrices:
            pfmatrices[pfmatrix] = [list(x) for x in zip(*pfmatrices[pfmatrix])]

        return (pfmatrices)
