########################################################################################
## Laboratory of Functional Analysis in silico                                        ##
## Human Genome Center, Institute of Medical Science, the University of Tokyo         ##
## Programmed by Yosvany Lopez Alvarez                                    April, 2011 ##
########################################################################################  

def ComputeLikelihood (List):

    LikelihoodList = [round(Item * pow(sum(List), -1), 6) for Item in List]

    return (LikelihoodList)

def ComputeTranspose (Matrix):

    return (zip(*Matrix))
